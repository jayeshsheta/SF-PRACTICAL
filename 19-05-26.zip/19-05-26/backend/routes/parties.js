const express = require('express');
const { pool } = require('../db');
const router = express.Router();

// GET distinct cities for filter
router.get('/cities', async (req, res) => {
  try {
    const [rows] = await pool.query(
      "SELECT DISTINCT city FROM parties WHERE is_active = 1 AND city IS NOT NULL AND city != '' ORDER BY city"
    );
    res.json(rows.map(r => r.city));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET all parties with search, sort, pagination
router.get('/', async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = [10, 20, 50, 100, 1000].includes(parseInt(req.query.limit)) ? parseInt(req.query.limit) : 1000;
    const offset = (page - 1) * limit;
    const search = (req.query.search || '').trim();
    const sortBy = req.query.sortBy || 'name';
    const sortDir = (req.query.sortDir || 'ASC').toUpperCase() === 'DESC' ? 'DESC' : 'ASC';

    const allowedSorts = { name: 'name', contact: 'contact', city: 'city', broker: 'broker', created_at: 'created_at' };
    const sortCol = allowedSorts[sortBy] || 'name';

    let where = 'WHERE is_active = 1';
    const params = [];
    if (search) {
      where += ' AND (name LIKE ? OR address LIKE ? OR contact LIKE ? OR city LIKE ? OR broker LIKE ?)';
      params.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
    }

    const [countRows] = await pool.query(`SELECT COUNT(*) as total FROM parties ${where}`, params);
    const total = countRows[0].total;

    const [rows] = await pool.query(
      `SELECT * FROM parties ${where} ORDER BY ${sortCol} ${sortDir} LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );

    res.json({ data: rows, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET single party
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM parties WHERE id = ?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST create party
router.post('/', async (req, res) => {
  try {
    const { name, address, contact, city, broker } = req.body;
    if (!name) return res.status(400).json({ error: 'Name is required' });
    const [result] = await pool.query(
      'INSERT INTO parties (name, address, contact, city, broker) VALUES (?, ?, ?, ?, ?)',
      [name, address || null, contact || null, city || null, broker || null]
    );
    res.status(201).json({ id: result.insertId, message: 'Party created' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT update party
router.put('/:id', async (req, res) => {
  try {
    const { name, address, contact, city, broker, is_active } = req.body;
    await pool.query(
      'UPDATE parties SET name = ?, address = ?, contact = ?, city = ?, broker = ?, is_active = ? WHERE id = ?',
      [name, address || null, contact || null, city || null, broker || null, is_active !== undefined ? is_active : 1, req.params.id]
    );
    res.json({ message: 'Party updated' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE party (soft delete)
router.delete('/:id', async (req, res) => {
  try {
    await pool.query('UPDATE parties SET is_active = 0 WHERE id = ?', [req.params.id]);
    res.json({ message: 'Party deactivated' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
