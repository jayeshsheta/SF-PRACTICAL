const express = require('express');
const { pool } = require('../db');
const router = express.Router();

// GET all categories with search, sort, pagination
router.get('/', async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = [10, 20, 50, 100, 1000].includes(parseInt(req.query.limit)) ? parseInt(req.query.limit) : 1000;
    const offset = (page - 1) * limit;
    const search = (req.query.search || '').trim();
    const sortBy = req.query.sortBy || 'category_name';
    const sortDir = (req.query.sortDir || 'ASC').toUpperCase() === 'DESC' ? 'DESC' : 'ASC';

    const allowedSorts = { category_name: 'category_name', created_at: 'created_at' };
    const sortCol = allowedSorts[sortBy] || 'category_name';

    let where = 'WHERE is_active = 1';
    const params = [];
    if (search) {
      where += ' AND category_name LIKE ?';
      params.push(`%${search}%`);
    }

    const [countRows] = await pool.query(`SELECT COUNT(*) as total FROM categories ${where}`, params);
    const total = countRows[0].total;

    const [rows] = await pool.query(
      `SELECT * FROM categories ${where} ORDER BY ${sortCol} ${sortDir} LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );

    res.json({ data: rows, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET single category
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM categories WHERE id = ?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST create category
router.post('/', async (req, res) => {
  try {
    const { category_name } = req.body;
    if (!category_name || !category_name.trim()) return res.status(400).json({ error: 'Category name is required' });
    const [result] = await pool.query(
      'INSERT INTO categories (category_name) VALUES (?)',
      [category_name.trim()]
    );
    res.status(201).json({ id: result.insertId, message: 'Category created' });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Category already exists' });
    res.status(500).json({ error: err.message });
  }
});

// PUT update category
router.put('/:id', async (req, res) => {
  try {
    const { category_name, is_active } = req.body;
    if (!category_name || !category_name.trim()) return res.status(400).json({ error: 'Category name is required' });
    await pool.query(
      'UPDATE categories SET category_name = ?, is_active = ? WHERE id = ?',
      [category_name.trim(), is_active !== undefined ? is_active : 1, req.params.id]
    );
    res.json({ message: 'Category updated' });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Category already exists' });
    res.status(500).json({ error: err.message });
  }
});

// DELETE category (only if not used in any order)
router.delete('/:id', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM categories WHERE id = ?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Not found' });

    const catName = rows[0].category_name;
    const [refs] = await pool.query(
      'SELECT COUNT(*) as cnt FROM order_design_categories WHERE category_name = ?',
      [catName]
    );
    if (refs[0].cnt > 0) {
      return res.status(409).json({ error: `Cannot delete: category "${catName}" is used in ${refs[0].cnt} order(s)` });
    }

    await pool.query('UPDATE categories SET is_active = 0 WHERE id = ?', [req.params.id]);
    res.json({ message: 'Category deactivated' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
