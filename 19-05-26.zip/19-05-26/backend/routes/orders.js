const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const { pool } = require('../db');

const router = express.Router();

// Multer config
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = path.join(__dirname, '..', 'uploads');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${uuidv4()}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|gif|webp|bmp|pdf/;
    const ext = allowed.test(path.extname(file.originalname).toLowerCase());
    const mime = file.mimetype === 'application/pdf' || /image\/(jpeg|jpg|png|gif|webp|bmp)/.test(file.mimetype);
    cb(null, ext || mime);
  },
});


router.get('/', async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = [10, 20, 50, 100, 1000].includes(parseInt(req.query.limit)) ? parseInt(req.query.limit) : 1000;
    const offset = (page - 1) * limit;
    const search = (req.query.search || '').trim();
    const sortBy = req.query.sortBy || 'created_at';
    const sortDir = (req.query.sortDir || 'DESC').toUpperCase() === 'ASC' ? 'ASC' : 'DESC';

    // Allowed sort columns — use last_item_at (max created_at from order_items) for created_at
    const allowedSorts = {
      party_name: 'o.party_name',
      order_date: 'o.order_date',
      created_at: 'last_item_at', // order by last item created_at
      item_count: 'item_count',
    };
    const sortCol = allowedSorts[sortBy] || 'last_item_at';

    let whereClause = '';
    const params = [];

    if (search) {
      whereClause = `WHERE (
        o.party_name LIKE ? OR
        oi.item_name LIKE ? OR
        oi.design_number LIKE ? OR
        CAST(oi.rate_bhav AS CHAR) LIKE ? OR
        CAST(oi.fabric_rate AS CHAR) LIKE ?
      )`;
      const like = `%${search}%`;
      params.push(like, like, like, like, like);
    }

    // Count query
    const countSql = `
      SELECT COUNT(DISTINCT o.id) as total
      FROM orders o
      LEFT JOIN order_items oi ON oi.order_id = o.id
      ${whereClause}
    `;
    const [countRows] = await pool.query(countSql, params);
    const total = countRows[0].total;

    // Data query: include last_item_at (max oi.created_at) and use COALESCE to fallback to order created_at
    const dataSql = `
      SELECT o.*,
        COUNT(oi.id) AS item_count,
        COALESCE(SUM(CASE WHEN oi.ok_status = 1 THEN 1 ELSE 0 END), 0) AS ok_count,
        (COUNT(oi.id) - COALESCE(SUM(CASE WHEN oi.ok_status = 1 THEN 1 ELSE 0 END), 0)) AS remaining,
        COALESCE(MAX(oi.created_at), o.created_at) AS last_item_at,
        COUNT(oi.id) AS total_items
      FROM orders o
      LEFT JOIN order_items oi ON oi.order_id = o.id
      ${whereClause}
      GROUP BY o.id
      ORDER BY ${sortCol} ${sortDir}
      LIMIT ? OFFSET ?
    `;
    const [orders] = await pool.query(dataSql, [...params, limit, offset]);

    res.json({
      data: orders,
      pagination: {
        page,
        limit,
        total,
        totalItems: orders.reduce((sum, order) => sum + order.total_items, 0),
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET single order with items and images
router.get('/:id', async (req, res) => {
  try {
    const [orders] = await pool.query('SELECT * FROM orders WHERE id = ?', [req.params.id]);
    if (!orders.length) return res.status(404).json({ error: 'Order not found' });

    const [items] = await pool.query(
      'SELECT * FROM order_items WHERE order_id = ? ORDER BY row_num',
      [req.params.id]
    );

    for (const item of items) {
      const [images] = await pool.query(
        'SELECT * FROM order_images WHERE order_item_id = ? ORDER BY slot',
        [item.id]
      );
      item.images = images;

      // Convert boolean fields (mysql2 may return DECIMAL/TINYINT as strings)
      item.sleeve = !!Number(item.sleeve);
      item.collar = !!Number(item.collar);
      item.back_fabric = !!Number(item.back_fabric);
      item.front = !!Number(item.front);
      item.kohinoor = !!Number(item.kohinoor);
      item.lachka = !!Number(item.lachka);
      item.net = !!Number(item.net);
      item.velvet = !!Number(item.velvet);
      item.less =  !!Number(item.less);
      item.color = item.color == null ? null : item.color;
      item.ok_status = !!Number(item.ok_status);
      item.stitch = item.stitch !== null ? Number(item.stitch) : null;
      item.kapda = item.kapda == null ? null : item.kapda;
      item.piece = item.piece == null ? null : Number(item.piece);
      item.remark = item.remark == null ? null : item.remark;
      item.isForMen = item.isForMen ? !!Number(item.isForMen) : false;
      item.isForKids = item.isForKids ? !!Number(item.isForKids) : false;
    }

    res.json({ ...orders[0], items });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST create order
router.post('/', async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const { party_name, order_date, items } = req.body;

    if (!party_name || !order_date) {
      return res.status(400).json({ error: 'Party name and date are required' });
    }

    const [orderResult] = await conn.query(
      'INSERT INTO orders (party_name, order_date) VALUES (?, ?)',
      [party_name, order_date]
    );
    const orderId = orderResult.insertId;

    if (items && items.length) {
      for (const item of items) {
        const [itemResult] = await conn.query(
          `INSERT INTO order_items
            (order_id, row_num, item_name, design_number, sudharo, stitch,
             rate_bhav, sleeve, collar, back_fabric, front, kohinoor, lachka,
             net, velvet, fabric_rate, ok_status, kapda, piece, remark, less, color, isForMen, isForKids)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            orderId, item.row_num || 0, item.item_name || null,
            item.design_number || null, item.sudharo || null,
            item.stitch || null, item.rate_bhav || null,
            item.sleeve ? 1 : 0, item.collar ? 1 : 0,
            item.back_fabric ? 1 : 0, item.front ? 1 : 0,
            item.kohinoor ? 1 : 0, item.lachka ? 1 : 0,
            item.net ? 1 : 0, item.velvet ? 1 : 0,
            item.fabric_rate || null, item.ok_status ? 1 : 0,
            item.kapda || null,
            item.piece || null,
            item.remark || null,
            item.less || null,
            item.color || null
          ]
        );
        item._insertedId = itemResult.insertId;
      }
    }

    await conn.commit();
    res.status(201).json({ id: orderId, message: 'Order created' });
  } catch (err) {
    await conn.rollback();
    res.status(500).json({ error: err.message });
  } finally {
    conn.release();
  }
});

router.put('/:id', async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const { party_name, order_date, items } = req.body;

    await conn.query(
      'UPDATE orders SET party_name = ?, order_date = ? WHERE id = ?',
      [party_name, order_date, req.params.id]
    );

    // Get existing items with their images before deleting
    const [existingItems] = await conn.query(
      'SELECT * FROM order_items WHERE order_id = ? ORDER BY row_num',
      [req.params.id]
    );

    // Build a map of old item images: oldItemId -> images[]
    const imageMap = {};
    for (const oldItem of existingItems) {
      const [imgs] = await conn.query(
        'SELECT * FROM order_images WHERE order_item_id = ?',
        [oldItem.id]
      );
      imageMap[oldItem.id] = imgs;
    }

    // Delete old items (cascade deletes image records)
    await conn.query('DELETE FROM order_items WHERE order_id = ?', [req.params.id]);

    // Re-insert items and re-associate images
    if (items && items.length) {
      for (let idx = 0; idx < items.length; idx++) {
        const item = items[idx];
        const [itemResult] = await conn.query(
          `INSERT INTO order_items
            (order_id, row_num, item_name, design_number, sudharo, stitch,
             rate_bhav, sleeve, collar, back_fabric, front, kohinoor, lachka,
             net, velvet, fabric_rate, ok_status, kapda, piece, remark, less, color, isForMen, isForKids)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            req.params.id, item.row_num || 0, item.item_name || null,
            item.design_number || null, item.sudharo || null,
            item.stitch || null, item.rate_bhav || null,
            item.sleeve ? 1 : 0, item.collar ? 1 : 0,
            item.back_fabric ? 1 : 0, item.front ? 1 : 0,
            item.kohinoor ? 1 : 0, item.lachka ? 1 : 0,
            item.net ? 1 : 0, item.velvet ? 1 : 0,
            item.fabric_rate || null, item.ok_status ? 1 : 0,
            item.kapda || null,
            item.piece || null,
            item.remark || null,
            item.less || null,
            item.color || null
          ]
        );
        const newItemId = itemResult.insertId;

        // Re-associate images from the old item at the same position
        if (idx < existingItems.length) {
          const oldImages = imageMap[existingItems[idx].id] || [];
          for (const img of oldImages) {
            await conn.query(
              'INSERT INTO order_images (order_item_id, slot, file_path, original_name) VALUES (?, ?, ?, ?)',
              [newItemId, img.slot, img.file_path, img.original_name]
            );
          }
        }
      }
    }

    await conn.commit();
    res.json({ message: 'Order updated' });
  } catch (err) {
    await conn.rollback();
    res.status(500).json({ error: err.message });
  } finally {
    conn.release();
  }
});

// DELETE order
router.delete('/:id', async (req, res) => {
  try {
    // Get image files to clean up
    const [images] = await pool.query(
      `SELECT oi.file_path FROM order_images oi
       JOIN order_items it ON oi.order_item_id = it.id
       WHERE it.order_id = ?`,
      [req.params.id]
    );
    images.forEach((img) => {
      const filePath = path.join(__dirname, '..', 'uploads', img.file_path);
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    });

    await pool.query('DELETE FROM orders WHERE id = ?', [req.params.id]);
    res.json({ message: 'Order deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST upload images for an order item
router.post(
  '/:orderId/items/:itemId/images',
  upload.array('images', 4),
  async (req, res) => {
    try {
      const { itemId } = req.params;
      const slot = parseInt(req.body.slot || '0', 10);
      const results = [];

      for (let i = 0; i < req.files.length; i++) {
        const file = req.files[i];
        const currentSlot = slot + i;
        if (currentSlot > 3) break;

        // Remove existing image at this slot
        const [existing] = await pool.query(
          'SELECT * FROM order_images WHERE order_item_id = ? AND slot = ?',
          [itemId, currentSlot]
        );
        if (existing.length) {
          const oldPath = path.join(__dirname, '..', 'uploads', existing[0].file_path);
          if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
          await pool.query('DELETE FROM order_images WHERE id = ?', [existing[0].id]);
        }

        await pool.query(
          'INSERT INTO order_images (order_item_id, slot, file_path, original_name) VALUES (?, ?, ?, ?)',
          [itemId, currentSlot, file.filename, file.originalname]
        );
        results.push({ slot: currentSlot, file_path: file.filename });
      }

      res.json({ uploaded: results });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
);

// DELETE image
router.delete('/images/:imageId', async (req, res) => {
  try {
    const [images] = await pool.query('SELECT * FROM order_images WHERE id = ?', [req.params.imageId]);
    if (images.length) {
      const filePath = path.join(__dirname, '..', 'uploads', images[0].file_path);
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
      await pool.query('DELETE FROM order_images WHERE id = ?', [req.params.imageId]);
    }
    res.json({ message: 'Image deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
