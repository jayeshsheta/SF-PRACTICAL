const express = require('express');
const { pool } = require('../db');
const router = express.Router();

// GET all items with search, sort, pagination
router.get('/', async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = [10, 20, 50, 100, 1000].includes(parseInt(req.query.limit)) ? parseInt(req.query.limit) : 1000;
    const offset = (page - 1) * limit;
    const search = (req.query.search || '').trim();
    const sortBy = req.query.sortBy || 'item_name';
    const sortDir = (req.query.sortDir || 'ASC').toUpperCase() === 'DESC' ? 'DESC' : 'ASC';

    const allowedSorts = { item_name: 'item_name', created_at: 'created_at' };
    const sortCol = allowedSorts[sortBy] || 'item_name';

    let where = 'WHERE is_active = 1';
    const params = [];
    if (search) {
      where += ' AND item_name LIKE ?';
      params.push(`%${search}%`);
    }

    const [countRows] = await pool.query(`SELECT COUNT(*) as total FROM items ${where}`, params);
    const total = countRows[0].total;

    const [rows] = await pool.query(
      `SELECT * FROM items ${where} ORDER BY ${sortCol} ${sortDir} LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );

    res.json({ data: rows, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET single item
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM items WHERE id = ?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST create item
router.post('/', async (req, res) => {
  try {
    const { item_name } = req.body;
    if (!item_name) return res.status(400).json({ error: 'Item name is required' });
    const [result] = await pool.query('INSERT INTO items (item_name) VALUES (?)', [item_name]);
    res.status(201).json({ id: result.insertId, message: 'Item created' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT update item
router.put('/:id', async (req, res) => {
  try {
    const { item_name, is_active } = req.body;
    await pool.query(
      'UPDATE items SET item_name = ?, is_active = ? WHERE id = ?',
      [item_name, is_active !== undefined ? is_active : 1, req.params.id]
    );
    res.json({ message: 'Item updated' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE item (soft delete)
router.delete('/:id', async (req, res) => {
  try {
    await pool.query('UPDATE items SET is_active = 0 WHERE id = ?', [req.params.id]);
    res.json({ message: 'Item deactivated' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
