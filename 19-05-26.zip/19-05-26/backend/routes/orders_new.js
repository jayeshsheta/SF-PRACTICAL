const express = require('express');
const { pool } = require('../db');
const router = express.Router();

// GET all orders with search, sort, pagination
router.get('/', async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = [10, 20, 50, 100, 1000].includes(parseInt(req.query.limit)) ? parseInt(req.query.limit) : 1000;
    const offset = (page - 1) * limit;
    const search = (req.query.search || '').trim();
    const sortBy = req.query.sortBy || 'created_at';
    const sortDir = (req.query.sortDir || 'DESC').toUpperCase() === 'ASC' ? 'ASC' : 'DESC';

    const allowedSorts = {
      party_name: 'p.name',
      order_date: 'o.order_date',
      created_at: 'o.created_at',
      updated_at: 'o.updated_at',
      item_count: 'item_count',
    };
    const sortCol = allowedSorts[sortBy] || 'o.updated_at';

    let whereClause = '';
    const params = [];
    if (search) {
      whereClause = `WHERE (p.name LIKE ? OR d.design_number LIKE ? OR i.item_name LIKE ?)`;
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    const city = (req.query.city || '').trim();
    if (city) {
      whereClause += (whereClause ? ' AND' : 'WHERE') + ' p.city = ?';
      params.push(city);
    }

    const countSql = `
      SELECT COUNT(DISTINCT o.id) as total
      FROM orders o
      JOIN parties p ON o.party_id = p.id
      LEFT JOIN order_designs od ON od.order_id = o.id
      LEFT JOIN designs d ON od.design_id = d.id
      LEFT JOIN items i ON d.item_id = i.id
      ${whereClause}
    `;
    const [countRows] = await pool.query(countSql, params);
    const total = countRows[0].total;

    const dataSql = `
      SELECT o.*, p.name as party_name,
        COUNT(od.id) AS item_count,
        COALESCE(SUM(CASE WHEN od.ok_status = 1 THEN 1 ELSE 0 END), 0) AS ok_count,
        (COUNT(od.id) - COALESCE(SUM(CASE WHEN od.ok_status = 1 THEN 1 ELSE 0 END), 0)) AS remaining
      FROM orders o
      JOIN parties p ON o.party_id = p.id
      LEFT JOIN order_designs od ON od.order_id = o.id
      LEFT JOIN designs d ON od.design_id = d.id
      LEFT JOIN items i ON d.item_id = i.id
      ${whereClause}
      GROUP BY o.id
      ORDER BY ${sortCol} ${sortDir}
      LIMIT ? OFFSET ?
    `;
    const [orders] = await pool.query(dataSql, [...params, limit, offset]);

    const totalDesigns = orders.reduce((sum, o) => sum + (o.item_count || 0), 0);

    res.json({
      data: orders,
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit), totalDesigns },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET single order with designs
router.get('/:id', async (req, res) => {
  try {
    const [orders] = await pool.query(
      `SELECT o.*, p.name as party_name, p.address as party_address, p.contact as party_contact
       FROM orders o JOIN parties p ON o.party_id = p.id WHERE o.id = ?`,
      [req.params.id]
    );
    if (!orders.length) return res.status(404).json({ error: 'Not found' });

    const [designs] = await pool.query(
      `SELECT od.id as order_design_id, od.order_id, od.design_id, od.row_num,
        od.ok_status as od_ok_status,
        d.design_number, d.sudharo, d.stitch, d.rate_bhav,
        d.sleeve, d.collar, d.back_fabric, d.front, d.kohinoor, d.lachka,
        d.net, d.velvet, d.less, d.fabric_rate, d.kapda, d.piece, d.color,
        d.remark,
        i.item_name
       FROM order_designs od
       JOIN designs d ON od.design_id = d.id
       JOIN items i ON d.item_id = i.id
       WHERE od.order_id = ?
       ORDER BY od.row_num`,
      [req.params.id]
    );

    // Attach files and sizes and categories to each design
    for (const design of designs) {
      const [files] = await pool.query('SELECT * FROM design_files WHERE design_id = ? ORDER BY slot', [design.design_id]);
      design.files = files;
      design.ok_status = design.od_ok_status;
      const [sizes] = await pool.query('SELECT * FROM order_design_sizes WHERE order_design_id = ?', [design.order_design_id]);
      design.sizes = sizes;
      const [categories] = await pool.query('SELECT * FROM order_design_categories WHERE order_design_id = ?', [design.order_design_id]);
      design.categories = categories;
      // Custom values
      const [customRows] = await pool.query('SELECT * FROM order_design_custom_values WHERE order_design_id = ?', [design.order_design_id]);
      design.custom_values = customRows.length ? customRows[0] : null;
      design.is_custom = !!customRows.length;
      // Order-specific files
      const [odFiles] = await pool.query('SELECT * FROM order_design_files WHERE order_design_id = ?', [design.order_design_id]);
      design.order_files = odFiles;
    }

    res.json({ ...orders[0], designs });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST create order
router.post('/', async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const { party_id, order_date, designs } = req.body;

    if (!party_id || !order_date) {
      return res.status(400).json({ error: 'Party and date are required' });
    }

    const [orderResult] = await conn.query(
      'INSERT INTO orders (party_id, order_date) VALUES (?, ?)',
      [party_id, order_date]
    );
    const orderId = orderResult.insertId;

    if (designs && designs.length) {
      for (const item of designs) {
        const [odResult] = await conn.query(
          'INSERT INTO order_designs (order_id, design_id, row_num, ok_status) VALUES (?, ?, ?, ?)',
          [orderId, item.design_id, item.row_num || 0, item.ok_status ? 1 : 0]
        );
        const odId = odResult.insertId;
        // Insert sizes
        if (item.sizes && item.sizes.length) {
          for (const s of item.sizes) {
            if (s.size_label && s.quantity > 0) {
              await conn.query(
                'INSERT INTO order_design_sizes (order_design_id, size_label, quantity) VALUES (?, ?, ?)',
                [odId, s.size_label, s.quantity]
              );
            }
          }
        }
        // Insert categories
        if (item.categories && item.categories.length) {
          for (const c of item.categories) {
            if (c.category_name && c.quantity > 0) {
              await conn.query(
                'INSERT INTO order_design_categories (order_design_id, category_name, quantity) VALUES (?, ?, ?)',
                [odId, c.category_name, c.quantity]
              );
            }
          }
        }
        // Insert custom values if present
        if (item.is_custom && item.custom_values) {
          const cv = item.custom_values;
          await conn.query(
            `INSERT INTO order_design_custom_values (order_design_id, item_name, sudharo, stitch, rate_bhav,
              sleeve, collar, back_fabric, front, kohinoor, lachka, net, velvet, less_val,
              fabric_rate, kapda, piece, color, remark) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
            [odId, cv.item_name, cv.sudharo, cv.stitch, cv.rate_bhav,
              cv.sleeve?1:0, cv.collar?1:0, cv.back_fabric?1:0, cv.front?1:0,
              cv.kohinoor?1:0, cv.lachka?1:0, cv.net?1:0, cv.velvet?1:0, cv.less?1:0,
              cv.fabric_rate, cv.kapda, cv.piece, cv.color, cv.remark]
          );
        }
      }
    }

    await conn.commit();
    res.status(201).json({ id: orderId, message: 'Order created' });
  } catch (err) {
    await conn.rollback();
    res.status(500).json({ error: err.message });
  } finally {
    conn.release();
  }
});

// PUT update order
router.put('/:id', async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const { party_id, order_date, designs } = req.body;

    await conn.query('UPDATE orders SET party_id = ?, order_date = ?, updated_at = NOW() WHERE id = ?',
      [party_id, order_date, req.params.id]);

    // Remove existing order_designs (cascade deletes sizes) and re-insert
    await conn.query('DELETE FROM order_designs WHERE order_id = ?', [req.params.id]);

    if (designs && designs.length) {
      for (const item of designs) {
        const [odResult] = await conn.query(
          'INSERT INTO order_designs (order_id, design_id, row_num, ok_status) VALUES (?, ?, ?, ?)',
          [req.params.id, item.design_id, item.row_num || 0, item.ok_status ? 1 : 0]
        );
        const odId = odResult.insertId;
        if (item.sizes && item.sizes.length) {
          for (const s of item.sizes) {
            if (s.size_label && s.quantity > 0) {
              await conn.query(
                'INSERT INTO order_design_sizes (order_design_id, size_label, quantity) VALUES (?, ?, ?)',
                [odId, s.size_label, s.quantity]
              );
            }
          }
        }
        if (item.categories && item.categories.length) {
          for (const c of item.categories) {
            if (c.category_name && c.quantity > 0) {
              await conn.query(
                'INSERT INTO order_design_categories (order_design_id, category_name, quantity) VALUES (?, ?, ?)',
                [odId, c.category_name, c.quantity]
              );
            }
          }
        }
        if (item.is_custom && item.custom_values) {
          const cv = item.custom_values;
          await conn.query(
            `INSERT INTO order_design_custom_values (order_design_id, item_name, sudharo, stitch, rate_bhav,
              sleeve, collar, back_fabric, front, kohinoor, lachka, net, velvet, less_val,
              fabric_rate, kapda, piece, color, remark) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
            [odId, cv.item_name, cv.sudharo, cv.stitch, cv.rate_bhav,
              cv.sleeve?1:0, cv.collar?1:0, cv.back_fabric?1:0, cv.front?1:0,
              cv.kohinoor?1:0, cv.lachka?1:0, cv.net?1:0, cv.velvet?1:0, cv.less?1:0,
              cv.fabric_rate, cv.kapda, cv.piece, cv.color, cv.remark]
          );
        }
      }
    }

    await conn.commit();
    res.json({ message: 'Order updated' });
  } catch (err) {
    await conn.rollback();
    res.status(500).json({ error: err.message });
  } finally {
    conn.release();
  }
});

// DELETE order
router.delete('/:id', async (req, res) => {
  try {
    await pool.query('DELETE FROM orders WHERE id = ?', [req.params.id]);
    res.json({ message: 'Order deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
