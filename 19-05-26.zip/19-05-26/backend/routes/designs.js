const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const { pool } = require('../db');
const router = express.Router();

// Multer config
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = path.join(__dirname, '..', 'uploads');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${uuidv4()}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|gif|webp|bmp|pdf/;
    const ext = allowed.test(path.extname(file.originalname).toLowerCase());
    const mime = file.mimetype === 'application/pdf' || /image\/(jpeg|jpg|png|gif|webp|bmp)/.test(file.mimetype);
    cb(null, ext || mime);
  },
});

// GET all designs with search, sort, pagination
router.get('/', async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = [10, 20, 50, 100, 1000].includes(parseInt(req.query.limit)) ? parseInt(req.query.limit) : 1000;
    const offset = (page - 1) * limit;
    const search = (req.query.search || '').trim();
    const sortBy = req.query.sortBy || 'created_at';
    const sortDir = (req.query.sortDir || 'DESC').toUpperCase() === 'ASC' ? 'ASC' : 'DESC';
    const itemId = req.query.item_id;

    const allowedSorts = {
      design_number: 'd.design_number',
      item_name: 'i.item_name',
      created_at: 'd.created_at',
      rate_bhav: 'd.rate_bhav',
      fabric_rate: 'd.fabric_rate',
    };
    const sortCol = allowedSorts[sortBy] || 'd.created_at';

    let where = 'WHERE d.is_active = 1';
    const params = [];

    if (itemId) {
      where += ' AND d.item_id = ?';
      params.push(itemId);
    }
    if (search) {
      where += ' AND (d.design_number LIKE ? OR i.item_name LIKE ? OR d.sudharo LIKE ? OR d.kapda LIKE ? OR d.color LIKE ?)';
      params.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
    }
    const orderFilter = req.query.order_filter;
    if (orderFilter === 'in_order') {
      where += ' AND (SELECT COUNT(*) FROM order_designs od WHERE od.design_id = d.id) > 0';
    } else if (orderFilter === 'not_in_order') {
      where += ' AND (SELECT COUNT(*) FROM order_designs od WHERE od.design_id = d.id) = 0';
    }

    const [countRows] = await pool.query(
      `SELECT COUNT(*) as total FROM designs d JOIN items i ON d.item_id = i.id ${where}`, params
    );
    const total = countRows[0].total;

    const [rows] = await pool.query(
      `SELECT d.*, i.item_name,
        (SELECT COUNT(*) FROM order_designs od WHERE od.design_id = d.id) AS order_count
       FROM designs d
       JOIN items i ON d.item_id = i.id
       ${where}
       ORDER BY ${sortCol} ${sortDir} LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );

    // Attach files
    for (const row of rows) {
      const [files] = await pool.query('SELECT * FROM design_files WHERE design_id = ? ORDER BY slot', [row.id]);
      row.files = files;
      row.in_order = row.order_count > 0;
    }

    res.json({ data: rows, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET single design
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT d.*, i.item_name FROM designs d JOIN items i ON d.item_id = i.id WHERE d.id = ?`,
      [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Not found' });
    const [files] = await pool.query('SELECT * FROM design_files WHERE design_id = ? ORDER BY slot', [req.params.id]);
    res.json({ ...rows[0], files });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST create design
router.post('/', async (req, res) => {
  try {
    const { item_id, design_number, sudharo, stitch, rate_bhav, sleeve, collar, back_fabric, front,
      kohinoor, lachka, net, velvet, less, fabric_rate, kapda, piece, color, category, remark } = req.body;

    if (!item_id || !design_number) return res.status(400).json({ error: 'Item and design number required' });

    const [result] = await pool.query(
      `INSERT INTO designs (item_id, design_number, sudharo, stitch, rate_bhav, sleeve, collar,
        back_fabric, front, kohinoor, lachka, net, velvet, less, fabric_rate, kapda, piece, color, category, remark)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [item_id, design_number, sudharo || null, stitch || null, rate_bhav || null,
        sleeve ? 1 : 0, collar ? 1 : 0, back_fabric ? 1 : 0, front ? 1 : 0,
        kohinoor ? 1 : 0, lachka ? 1 : 0, net ? 1 : 0, velvet ? 1 : 0, less ? 1 : 0,
        fabric_rate || null, kapda || null, piece || null, color || null, category || 'none', remark || null]
    );
    res.status(201).json({ id: result.insertId, message: 'Design created' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT update design
router.put('/:id', async (req, res) => {
  try {
    const { item_id, design_number, sudharo, stitch, rate_bhav, sleeve, collar, back_fabric, front,
      kohinoor, lachka, net, velvet, less, fabric_rate, kapda, piece, color, category, remark, is_active } = req.body;

    await pool.query(
      `UPDATE designs SET item_id=?, design_number=?, sudharo=?, stitch=?, rate_bhav=?, sleeve=?, collar=?,
        back_fabric=?, front=?, kohinoor=?, lachka=?, net=?, velvet=?, less=?, fabric_rate=?, kapda=?,
        piece=?, color=?, category=?, remark=?, is_active=? WHERE id=?`,
      [item_id, design_number, sudharo || null, stitch || null, rate_bhav || null,
        sleeve ? 1 : 0, collar ? 1 : 0, back_fabric ? 1 : 0, front ? 1 : 0,
        kohinoor ? 1 : 0, lachka ? 1 : 0, net ? 1 : 0, velvet ? 1 : 0, less ? 1 : 0,
        fabric_rate || null, kapda || null, piece || null, color || null, category || 'none', remark || null,
        is_active !== undefined ? is_active : 1, req.params.id]
    );
    res.json({ message: 'Design updated' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE design (soft)
router.delete('/:id', async (req, res) => {
  try {
    await pool.query('UPDATE designs SET is_active = 0 WHERE id = ?', [req.params.id]);
    res.json({ message: 'Design deactivated' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST upload files for a design
router.post('/:id/files', upload.array('files', 4), async (req, res) => {
  try {
    const designId = req.params.id;
    const [design] = await pool.query('SELECT id FROM designs WHERE id = ?', [designId]);
    if (!design.length) return res.status(404).json({ error: 'Design not found' });

    const slot = parseInt(req.body.slot) || 0;
    const results = [];

    for (let i = 0; i < req.files.length; i++) {
      const file = req.files[i];
      const fileSlot = slot + i;
      if (fileSlot > 3) break;

      // Remove existing file at this slot
      const [existing] = await pool.query('SELECT * FROM design_files WHERE design_id = ? AND slot = ?', [designId, fileSlot]);
      if (existing.length) {
        const oldPath = path.join(__dirname, '..', 'uploads', path.basename(existing[0].file_path));
        if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
        await pool.query('DELETE FROM design_files WHERE id = ?', [existing[0].id]);
      }

      const filePath = `/uploads/${file.filename}`;
      const [result] = await pool.query(
        'INSERT INTO design_files (design_id, slot, file_path, original_name) VALUES (?, ?, ?, ?)',
        [designId, fileSlot, filePath, file.originalname]
      );
      results.push({ id: result.insertId, slot: fileSlot, file_path: filePath, original_name: file.originalname });
    }

    res.json({ files: results });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE design file
router.delete('/files/:fileId', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM design_files WHERE id = ?', [req.params.fileId]);
    if (rows.length) {
      const filePath = path.join(__dirname, '..', 'uploads', path.basename(rows[0].file_path));
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
      await pool.query('DELETE FROM design_files WHERE id = ?', [req.params.fileId]);
    }
    res.json({ message: 'File deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
