const express = require('express');
const { pool } = require('../db');
const router = express.Router();

// Design-wise orders report
router.get('/design-wise', async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT d.id as design_id, d.design_number, i.item_name, d.color, d.kapda,
        COUNT(DISTINCT o.id) as order_count,
        GROUP_CONCAT(DISTINCT p.name ORDER BY p.name SEPARATOR ', ') as party_names
      FROM designs d
      JOIN items i ON d.item_id = i.id
      JOIN order_designs od ON od.design_id = d.id
      JOIN orders o ON od.order_id = o.id
      JOIN parties p ON o.party_id = p.id
      WHERE d.is_active = 1
      GROUP BY d.id
      ORDER BY order_count DESC, d.design_number
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Party-wise orders report
router.get('/party-wise', async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT p.id as party_id, p.name as party_name, p.city, p.broker,
        COUNT(DISTINCT o.id) as order_count,
        COUNT(od.id) as total_designs,
        SUM(CASE WHEN od.ok_status = 1 THEN 1 ELSE 0 END) as completed
      FROM parties p
      JOIN orders o ON o.party_id = p.id
      JOIN order_designs od ON od.order_id = o.id
      WHERE p.is_active = 1
      GROUP BY p.id
      ORDER BY order_count DESC, p.name
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Dashboard stats
router.get('/dashboard', async (req, res) => {
  try {
    const [[{ totalOrders }]] = await pool.query('SELECT COUNT(*) as totalOrders FROM orders');
    const [[{ totalParties }]] = await pool.query('SELECT COUNT(*) as totalParties FROM parties WHERE is_active = 1');
    const [[{ totalDesigns }]] = await pool.query('SELECT COUNT(*) as totalDesigns FROM designs WHERE is_active = 1');
    const [[{ totalItems }]] = await pool.query('SELECT COUNT(*) as totalItems FROM items WHERE is_active = 1');
    const [[{ completedDesigns }]] = await pool.query('SELECT COUNT(*) as completedDesigns FROM order_designs WHERE ok_status = 1');
    const [[{ pendingDesigns }]] = await pool.query('SELECT COUNT(*) as pendingDesigns FROM order_designs WHERE ok_status = 0');
    const [recentOrders] = await pool.query(`
      SELECT o.id, o.order_date, p.name as party_name, COUNT(od.id) as design_count
      FROM orders o JOIN parties p ON o.party_id = p.id
      LEFT JOIN order_designs od ON od.order_id = o.id
      GROUP BY o.id ORDER BY o.created_at DESC LIMIT 5
    `);
    const [topDesigns] = await pool.query(`
      SELECT d.design_number, i.item_name, COUNT(od.id) as usage_count
      FROM designs d JOIN items i ON d.item_id = i.id
      JOIN order_designs od ON od.design_id = d.id
      GROUP BY d.id ORDER BY usage_count DESC LIMIT 5
    `);
    res.json({
      totalOrders, totalParties, totalDesigns, totalItems,
      completedDesigns, pendingDesigns, recentOrders, topDesigns
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Design detail - which orders/parties use this design
router.get('/design/:id/orders', async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT o.id as order_id, o.order_date, p.name as party_name, p.city,
        od.ok_status
      FROM order_designs od
      JOIN orders o ON od.order_id = o.id
      JOIN parties p ON o.party_id = p.id
      WHERE od.design_id = ?
      ORDER BY o.order_date DESC
    `, [req.params.id]);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
