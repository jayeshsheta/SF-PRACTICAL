const express = require('express');
const { pool } = require('../db');
const router = express.Router();

// GET all sizes with search, sort, pagination
router.get('/', async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = [10, 20, 50, 100, 1000].includes(parseInt(req.query.limit)) ? parseInt(req.query.limit) : 1000;
    const offset = (page - 1) * limit;
    const search = (req.query.search || '').trim();
    const sortBy = req.query.sortBy || 'size_label';
    const sortDir = (req.query.sortDir || 'ASC').toUpperCase() === 'DESC' ? 'DESC' : 'ASC';

    const allowedSorts = { size_label: 'size_label', created_at: 'created_at' };
    const sortCol = allowedSorts[sortBy] || 'size_label';

    let where = 'WHERE is_active = 1';
    const params = [];
    if (search) {
      where += ' AND size_label LIKE ?';
      params.push(`%${search}%`);
    }

    const [countRows] = await pool.query(`SELECT COUNT(*) as total FROM sizes ${where}`, params);
    const total = countRows[0].total;

    const [rows] = await pool.query(
      `SELECT * FROM sizes ${where} ORDER BY ${sortCol} ${sortDir} LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );

    res.json({ data: rows, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET single size
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM sizes WHERE id = ?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST create size
router.post('/', async (req, res) => {
  try {
    const { size_label } = req.body;
    if (!size_label || !size_label.trim()) return res.status(400).json({ error: 'Size label is required' });
    const [result] = await pool.query(
      'INSERT INTO sizes (size_label) VALUES (?)',
      [size_label.trim()]
    );
    res.status(201).json({ id: result.insertId, message: 'Size created' });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Size already exists' });
    res.status(500).json({ error: err.message });
  }
});

// PUT update size
router.put('/:id', async (req, res) => {
  try {
    const { size_label, is_active } = req.body;
    if (!size_label || !size_label.trim()) return res.status(400).json({ error: 'Size label is required' });
    await pool.query(
      'UPDATE sizes SET size_label = ?, is_active = ? WHERE id = ?',
      [size_label.trim(), is_active !== undefined ? is_active : 1, req.params.id]
    );
    res.json({ message: 'Size updated' });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Size already exists' });
    res.status(500).json({ error: err.message });
  }
});

// DELETE size (only if not used in any active order)
router.delete('/:id', async (req, res) => {
  try {
    // Check if this size is referenced in any order_design_sizes
    const [rows] = await pool.query('SELECT * FROM sizes WHERE id = ?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Not found' });

    const sizeLabel = rows[0].size_label;
    const [refs] = await pool.query(
      'SELECT COUNT(*) as cnt FROM order_design_sizes WHERE size_label = ?',
      [sizeLabel]
    );
    if (refs[0].cnt > 0) {
      return res.status(409).json({ error: `Cannot delete: size "${sizeLabel}" is used in ${refs[0].cnt} order(s)` });
    }

    await pool.query('UPDATE sizes SET is_active = 0 WHERE id = ?', [req.params.id]);
    res.json({ message: 'Size deactivated' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
