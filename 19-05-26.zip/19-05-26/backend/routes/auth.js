const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { pool } = require('../db');
const authMiddleware = require('../middleware/auth');

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'sempal-default-secret';
const TOKEN_EXPIRY = '7d';

// Admin check middleware
function adminOnly(req, res, next) {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required.' });
  }
  next();
}

// POST /api/auth/register
router.post('/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email and password are required.' });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters.' });
    }

    const [existing] = await pool.query('SELECT id FROM users WHERE email = ?', [email.toLowerCase()]);
    if (existing.length) {
      return res.status(409).json({ error: 'Email already registered.' });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // First user becomes admin + auto-approved
    const [allUsers] = await pool.query('SELECT COUNT(*) as count FROM users');
    const isFirstUser = allUsers[0].count === 0;

    const [result] = await pool.query(
      'INSERT INTO users (name, email, password, role, is_approved) VALUES (?, ?, ?, ?, ?)',
      [name.trim(), email.toLowerCase().trim(), hashedPassword, isFirstUser ? 'admin' : 'user', isFirstUser ? 1 : 0]
    );

    if (isFirstUser) {
      const token = jwt.sign(
        { id: result.insertId, name: name.trim(), email: email.toLowerCase().trim(), role: 'admin' },
        JWT_SECRET,
        { expiresIn: TOKEN_EXPIRY }
      );
      return res.status(201).json({
        message: 'Admin account created successfully!',
        token,
        user: { id: result.insertId, name: name.trim(), email: email.toLowerCase().trim(), role: 'admin', is_approved: true },
      });
    }

    // Regular user — pending approval
    res.status(201).json({
      message: 'Registration successful! Your account is pending admin approval.',
      pending: true,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const [users] = await pool.query('SELECT * FROM users WHERE email = ?', [email.toLowerCase()]);
    if (!users.length) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const user = users[0];

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    // Check approval
    if (!user.is_approved) {
      return res.status(403).json({ error: 'Your account is pending admin approval. Please contact the administrator.' });
    }

    const token = jwt.sign(
      { id: user.id, name: user.name, email: user.email, role: user.role },
      JWT_SECRET,
      { expiresIn: TOKEN_EXPIRY }
    );

    res.json({
      message: 'Login successful',
      token,
      user: { id: user.id, name: user.name, email: user.email, role: user.role, is_approved: true },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/auth/me
router.get('/me', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'No token provided.' });
    }

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, JWT_SECRET);

    const [users] = await pool.query('SELECT id, name, email, role, is_approved, created_at FROM users WHERE id = ?', [decoded.id]);
    if (!users.length) return res.status(404).json({ error: 'User not found.' });

    res.json({ user: users[0] });
  } catch (err) {
    if (err.name === 'JsonWebTokenError' || err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Invalid or expired token.' });
    }
    res.status(500).json({ error: err.message });
  }
});

// ========== ADMIN ENDPOINTS ==========

// GET /api/auth/users — list all users (admin only)
router.get('/users', authMiddleware, adminOnly, async (req, res) => {
  try {
    const [users] = await pool.query(
      'SELECT id, name, email, role, is_approved, created_at FROM users ORDER BY created_at DESC'
    );
    res.json({ users });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/auth/users/:id/approve
router.put('/users/:id/approve', authMiddleware, adminOnly, async (req, res) => {
  try {
    const [users] = await pool.query('SELECT id, name FROM users WHERE id = ?', [req.params.id]);
    if (!users.length) return res.status(404).json({ error: 'User not found.' });

    await pool.query('UPDATE users SET is_approved = 1 WHERE id = ?', [req.params.id]);
    res.json({ message: `User "${users[0].name}" approved successfully.` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/auth/users/:id/reject
router.put('/users/:id/reject', authMiddleware, adminOnly, async (req, res) => {
  try {
    const [users] = await pool.query('SELECT id, name FROM users WHERE id = ?', [req.params.id]);
    if (!users.length) return res.status(404).json({ error: 'User not found.' });

    if (Number(req.params.id) === req.user.id) {
      return res.status(400).json({ error: 'Cannot reject your own account.' });
    }

    await pool.query('UPDATE users SET is_approved = 0 WHERE id = ?', [req.params.id]);
    res.json({ message: `User "${users[0].name}" access revoked.` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/auth/users/:id
router.delete('/users/:id', authMiddleware, adminOnly, async (req, res) => {
  try {
    if (Number(req.params.id) === req.user.id) {
      return res.status(400).json({ error: 'Cannot delete your own account.' });
    }
    await pool.query('DELETE FROM users WHERE id = ?', [req.params.id]);
    res.json({ message: 'User deleted.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
