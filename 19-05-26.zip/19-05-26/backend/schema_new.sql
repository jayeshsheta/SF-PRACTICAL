-- New Normalized Schema
CREATE DATABASE IF NOT EXISTS sempal_db;
USE sempal_db;

-- Party Master
CREATE TABLE IF NOT EXISTS parties (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  address VARCHAR(500) NULL,
  contact VARCHAR(100) NULL,
  is_active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Item Master
CREATE TABLE IF NOT EXISTS items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  item_name VARCHAR(255) NOT NULL,
  is_active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Design Master
CREATE TABLE IF NOT EXISTS designs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  item_id INT NOT NULL,
  design_number VARCHAR(100) NOT NULL,
  sudharo VARCHAR(255) NULL,
  stitch DECIMAL(10,2) NULL,
  rate_bhav DECIMAL(10,2) NULL,
  sleeve TINYINT(1) DEFAULT 0,
  collar TINYINT(1) DEFAULT 0,
  back_fabric TINYINT(1) DEFAULT 0,
  front TINYINT(1) DEFAULT 0,
  kohinoor TINYINT(1) DEFAULT 0,
  lachka TINYINT(1) DEFAULT 0,
  net TINYINT(1) DEFAULT 0,
  velvet TINYINT(1) DEFAULT 0,
  less TINYINT(1) DEFAULT 0,
  fabric_rate DECIMAL(10,2) NULL,
  kapda VARCHAR(255) NULL,
  piece INT NULL,
  color VARCHAR(255) NULL,
  category ENUM('none','men','kids','both') DEFAULT 'none',
  remark VARCHAR(500) NULL,
  is_active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (item_id) REFERENCES items(id)
);

-- Design Files (max 4 per design)
CREATE TABLE IF NOT EXISTS design_files (
  id INT AUTO_INCREMENT PRIMARY KEY,
  design_id INT NOT NULL,
  slot INT NOT NULL CHECK (slot BETWEEN 0 AND 3),
  file_path VARCHAR(500) NOT NULL,
  original_name VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (design_id) REFERENCES designs(id) ON DELETE CASCADE
);

-- Orders (references party)
CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  party_id INT NOT NULL,
  order_date DATE NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (party_id) REFERENCES parties(id)
);

-- Order-Design junction (order line items referencing designs)
CREATE TABLE IF NOT EXISTS order_designs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  design_id INT NOT NULL,
  row_num INT NOT NULL DEFAULT 0,
  ok_status TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (design_id) REFERENCES designs(id)
);
