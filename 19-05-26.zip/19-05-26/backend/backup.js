const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');
require('dotenv').config({ path: path.join(__dirname, '.env') });

const BACKUP_DIR = path.join(__dirname, 'backups');
const MAX_AGE_DAYS = 30;

// Ensure backup directory exists
if (!fs.existsSync(BACKUP_DIR)) {
  fs.mkdirSync(BACKUP_DIR, { recursive: true });
}

function getTimestamp() {
  return new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
}

function takeBackup() {
  const filename = `backup_${getTimestamp()}.sql`;
  const filepath = path.join(BACKUP_DIR, filename);

  const { DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME } = process.env;

  const cmd = `mysqldump -h ${DB_HOST} -P ${DB_PORT} -u ${DB_USER} -p"${DB_PASSWORD}" ${DB_NAME} > "${filepath}"`;

  console.log(`[${new Date().toISOString()}] Starting backup...`);

  exec(cmd, (error, stdout, stderr) => {
    if (error) {
      console.error(`Backup failed: ${error.message}`);
      // Remove empty/failed file
      if (fs.existsSync(filepath)) fs.unlinkSync(filepath);
      return;
    }

    const stats = fs.statSync(filepath);
    if (stats.size === 0) {
      console.error('Backup file is empty, removing...');
      fs.unlinkSync(filepath);
      return;
    }

    console.log(`Backup created: ${filename} (${(stats.size / 1024).toFixed(1)} KB)`);
    deleteOldBackups();
  });
}

function deleteOldBackups() {
  const files = fs.readdirSync(BACKUP_DIR)
    .filter(f => f.startsWith('backup_') && f.endsWith('.sql'))
    .map(f => ({
      name: f,
      path: path.join(BACKUP_DIR, f),
      time: fs.statSync(path.join(BACKUP_DIR, f)).mtime.getTime(),
    }))
    .sort((a, b) => b.time - a.time); // newest first

  if (files.length <= 1) {
    console.log('Only 1 backup exists, skipping cleanup.');
    return;
  }

  const cutoff = Date.now() - (MAX_AGE_DAYS * 24 * 60 * 60 * 1000);
  let deleted = 0;

  for (let i = 1; i < files.length; i++) { // skip index 0 (newest)
    if (files[i].time < cutoff) {
      fs.unlinkSync(files[i].path);
      console.log(`Deleted old backup: ${files[i].name}`);
      deleted++;
    }
  }

  console.log(`Cleanup done. Deleted ${deleted} old backups. ${files.length - deleted} remaining.`);
}

takeBackup();