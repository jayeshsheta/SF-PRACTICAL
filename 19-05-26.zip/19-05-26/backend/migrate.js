/**
 * Migration script: Migrate data from old schema to new normalized schema
 * Run: node migrate.js
 *
 * This assumes the NEW tables (parties, items, designs, design_files, order_designs)
 * have already been created by the app startup (initDB in db.js).
 * It reads from old tables (orders with party_name, order_items, order_images)
 * and populates the new tables.
 */
const { pool } = require('./db');

async function migrate() {
  const conn = await pool.getConnection();
  try {
    console.log('Starting migration...');

    // Check if old tables exist
    const [tables] = await conn.query(`SHOW TABLES LIKE 'order_items'`);
    if (!tables.length) {
      console.log('No order_items table found. Nothing to migrate.');
      return;
    }

    // Check if old orders table has party_name column
    const [cols] = await conn.query(`SHOW COLUMNS FROM orders LIKE 'party_name'`);
    if (!cols.length) {
      console.log('Old orders table does not have party_name. Already migrated or different schema.');
      return;
    }

    // 1. Migrate parties
    console.log('Migrating parties...');
    const [oldOrders] = await conn.query('SELECT DISTINCT party_name FROM orders WHERE party_name IS NOT NULL');
    for (const row of oldOrders) {
      const [existing] = await conn.query('SELECT id FROM parties WHERE name = ?', [row.party_name]);
      if (!existing.length) {
        await conn.query('INSERT INTO parties (name) VALUES (?)', [row.party_name]);
      }
    }

    // 2. Migrate items
    console.log('Migrating items...');
    const [oldItems] = await conn.query(`SELECT DISTINCT item_name FROM order_items WHERE item_name IS NOT NULL AND item_name != ''`);
    for (const row of oldItems) {
      const [existing] = await conn.query('SELECT id FROM items WHERE item_name = ?', [row.item_name]);
      if (!existing.length) {
        await conn.query('INSERT INTO items (item_name) VALUES (?)', [row.item_name]);
      }
    }

    // Ensure at least one item exists for items with NULL/empty item_name
    const [defaultItem] = await conn.query('SELECT id FROM items WHERE item_name = ?', ['Unknown']);
    let defaultItemId;
    if (!defaultItem.length) {
      const [r] = await conn.query('INSERT INTO items (item_name) VALUES (?)', ['Unknown']);
      defaultItemId = r.insertId;
    } else {
      defaultItemId = defaultItem[0].id;
    }

    // 3. Migrate designs from order_items
    console.log('Migrating designs...');
    const [allOrderItems] = await conn.query('SELECT * FROM order_items ORDER BY id');

    // Map old order_item id -> new design id
    const itemToDesignMap = {};

    for (const oi of allOrderItems) {
      // Find item_id
      let itemId = defaultItemId;
      if (oi.item_name) {
        const [found] = await conn.query('SELECT id FROM items WHERE item_name = ? LIMIT 1', [oi.item_name]);
        if (found.length) itemId = found[0].id;
      }

      // Determine category
      let category = 'none';
      if (oi.isForMen && oi.isForKids) category = 'both';
      else if (oi.isForMen) category = 'men';
      else if (oi.isForKids) category = 'kids';

      const [result] = await conn.query(
        `INSERT INTO designs (item_id, design_number, sudharo, stitch, rate_bhav, sleeve, collar,
          back_fabric, front, kohinoor, lachka, net, velvet, less, fabric_rate, kapda, piece, color, category, remark)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          itemId, oi.design_number || '', oi.sudharo || null, oi.stitch || null, oi.rate_bhav || null,
          oi.sleeve ? 1 : 0, oi.collar ? 1 : 0, oi.back_fabric ? 1 : 0, oi.front ? 1 : 0,
          oi.kohinoor ? 1 : 0, oi.lachka ? 1 : 0, oi.net ? 1 : 0, oi.velvet ? 1 : 0,
          oi.less ? 1 : 0, oi.fabric_rate || null, oi.kapda || null, oi.piece || null,
          oi.color || null, category, oi.remark || null
        ]
      );
      itemToDesignMap[oi.id] = result.insertId;
    }

    // 4. Migrate design_files from order_images
    console.log('Migrating design files...');
    const [allImages] = await conn.query('SELECT * FROM order_images');
    for (const img of allImages) {
      const designId = itemToDesignMap[img.order_item_id];
      if (designId) {
        await conn.query(
          'INSERT INTO design_files (design_id, slot, file_path, original_name) VALUES (?, ?, ?, ?)',
          [designId, img.slot, img.file_path, img.original_name]
        );
      }
    }

    // 5. Migrate orders (create new order records with party_id)
    console.log('Migrating orders...');
    const [oldOrdersFull] = await conn.query('SELECT * FROM orders');

    // We need to re-create orders with party_id. But the orders table already has party_id column now.
    // Strategy: create a temp mapping
    for (const oldOrder of oldOrdersFull) {
      // Find party_id
      const [party] = await conn.query('SELECT id FROM parties WHERE name = ? LIMIT 1', [oldOrder.party_name]);
      if (!party.length) continue;

      // Update existing order to set party_id (if column exists)
      try {
        await conn.query('UPDATE orders SET party_id = ? WHERE id = ?', [party[0].id, oldOrder.id]);
      } catch (e) {
        // If orders table doesn't have party_id yet, skip
      }
    }

    // 6. Migrate order_designs
    console.log('Migrating order_designs...');
    for (const oi of allOrderItems) {
      const designId = itemToDesignMap[oi.id];
      if (designId) {
        await conn.query(
          'INSERT INTO order_designs (order_id, design_id, row_num, ok_status) VALUES (?, ?, ?, ?)',
          [oi.order_id, designId, oi.row_num || 0, oi.ok_status ? 1 : 0]
        );
      }
    }

    console.log('Migration complete!');
    console.log(`Migrated: ${oldOrders.length} parties, ${oldItems.length} items, ${allOrderItems.length} designs, ${allImages.length} files`);
  } catch (err) {
    console.error('Migration error:', err);
  } finally {
    conn.release();
    process.exit(0);
  }
}

migrate();
