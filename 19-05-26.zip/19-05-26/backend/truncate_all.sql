-- Truncate all tables (order matters due to foreign keys)
SET FOREIGN_KEY_CHECKS = 0;

TRUNCATE TABLE order_design_custom_values;
TRUNCATE TABLE order_design_files;
TRUNCATE TABLE order_design_sizes;
TRUNCATE TABLE order_design_categories;
TRUNCATE TABLE order_designs;
TRUNCATE TABLE orders;
TRUNCATE TABLE design_files;
TRUNCATE TABLE designs;
TRUNCATE TABLE items;
TRUNCATE TABLE parties;
TRUNCATE TABLE sizes;
TRUNCATE TABLE categories;

SET FOREIGN_KEY_CHECKS = 1;

-- Note: This does NOT truncate the 'users' table to preserve login credentials.
