/**
 * Deduplication script: Remove duplicate records from master tables
 * while preserving referential integrity.
 * 
 * Run: node deduplicate.js
 * 
 * Logic:
 * - For each master table, find duplicates by name/key
 * - Keep the one with the lowest ID (oldest)
 * - Update all FK references to point to the kept record
 * - Delete the duplicate records
 */
const { pool } = require('./db');

async function deduplicate() {
  const conn = await pool.getConnection();
  try {
    console.log('=== Deduplication Script ===\n');

    // 1. Deduplicate PARTIES (by name)
    console.log('--- Deduplicating parties ---');
    const [dupParties] = await conn.query(`
      SELECT name, MIN(id) as keep_id, GROUP_CONCAT(id) as all_ids, COUNT(*) as cnt
      FROM parties WHERE is_active = 1
      GROUP BY name HAVING cnt > 1
    `);
    for (const dup of dupParties) {
      const allIds = dup.all_ids.split(',').map(Number);
      const keepId = dup.keep_id;
      const removeIds = allIds.filter(id => id !== keepId);
      console.log(`  Party "${dup.name}": keeping ID ${keepId}, removing [${removeIds}]`);

      // Update orders referencing duplicate party IDs
      for (const removeId of removeIds) {
        await conn.query('UPDATE orders SET party_id = ? WHERE party_id = ?', [keepId, removeId]);
      }
      // Now safe to delete
      await conn.query(`DELETE FROM parties WHERE id IN (${removeIds.join(',')})`);
    }
    console.log(`  Removed ${dupParties.reduce((s, d) => s + d.cnt - 1, 0)} duplicate parties\n`);

    // 2. Deduplicate ITEMS (by item_name)
    console.log('--- Deduplicating items ---');
    const [dupItems] = await conn.query(`
      SELECT item_name, MIN(id) as keep_id, GROUP_CONCAT(id) as all_ids, COUNT(*) as cnt
      FROM items WHERE is_active = 1
      GROUP BY item_name HAVING cnt > 1
    `);
    for (const dup of dupItems) {
      const allIds = dup.all_ids.split(',').map(Number);
      const keepId = dup.keep_id;
      const removeIds = allIds.filter(id => id !== keepId);
      console.log(`  Item "${dup.item_name}": keeping ID ${keepId}, removing [${removeIds}]`);

      // Update designs referencing duplicate item IDs
      for (const removeId of removeIds) {
        await conn.query('UPDATE designs SET item_id = ? WHERE item_id = ?', [keepId, removeId]);
      }
      await conn.query(`DELETE FROM items WHERE id IN (${removeIds.join(',')})`);
    }
    console.log(`  Removed ${dupItems.reduce((s, d) => s + d.cnt - 1, 0)} duplicate items\n`);

    // 3. Deduplicate DESIGNS (by item_id + design_number)
    console.log('--- Deduplicating designs ---');
    const [dupDesigns] = await conn.query(`
      SELECT item_id, design_number, MIN(id) as keep_id, GROUP_CONCAT(id) as all_ids, COUNT(*) as cnt
      FROM designs WHERE is_active = 1
      GROUP BY item_id, design_number HAVING cnt > 1
    `);
    for (const dup of dupDesigns) {
      const allIds = dup.all_ids.split(',').map(Number);
      const keepId = dup.keep_id;
      const removeIds = allIds.filter(id => id !== keepId);
      console.log(`  Design "${dup.design_number}" (item_id=${dup.item_id}): keeping ID ${keepId}, removing [${removeIds}]`);

      // Update order_designs referencing duplicate design IDs
      for (const removeId of removeIds) {
        await conn.query('UPDATE order_designs SET design_id = ? WHERE design_id = ?', [keepId, removeId]);
      }

      // Move design_files from duplicates to kept record (avoid slot conflicts)
      for (const removeId of removeIds) {
        // Get files from duplicate
        const [files] = await conn.query('SELECT * FROM design_files WHERE design_id = ?', [removeId]);
        for (const file of files) {
          // Check if kept design already has file at this slot
          const [existing] = await conn.query(
            'SELECT id FROM design_files WHERE design_id = ? AND slot = ?',
            [keepId, file.slot]
          );
          if (!existing.length) {
            // Move file to kept design
            await conn.query('UPDATE design_files SET design_id = ? WHERE id = ?', [keepId, file.id]);
          } else {
            // Delete duplicate file record (physical file stays)
            await conn.query('DELETE FROM design_files WHERE id = ?', [file.id]);
          }
        }
      }

      // Now safe to delete duplicate designs
      await conn.query(`DELETE FROM designs WHERE id IN (${removeIds.join(',')})`);
    }
    console.log(`  Removed ${dupDesigns.reduce((s, d) => s + d.cnt - 1, 0)} duplicate designs\n`);

    console.log('=== Deduplication complete ===');
  } catch (err) {
    console.error('Deduplication error:', err);
  } finally {
    conn.release();
    process.exit(0);
  }
}

deduplicate();
