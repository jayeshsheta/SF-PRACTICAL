const mysql = require('mysql2/promise');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });

let pool;

if (process.env.MYSQL_URL) {
  // Use connection string (Railway provides this)
  pool = mysql.createPool({
    uri: process.env.MYSQL_URL,
    waitForConnections: true,
    connectionLimit: 10,
    connectTimeout: 60000,
    queueLimit: 0,
    enableKeepAlive: true,
    keepAliveInitialDelay: 10000,
  });
} else {
  pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '3306', 10),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'sempal_db',
    waitForConnections: true,
    connectionLimit: 10,
    connectTimeout: 60000,
    queueLimit: 0,
    enableKeepAlive: true,
    keepAliveInitialDelay: 10000,
  });
}

async function initDB() {
  const conn = await pool.getConnection();
  try {
    // Users table
    await conn.query(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        role ENUM('admin', 'user') DEFAULT 'user',
        is_approved TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    try { await conn.query(`ALTER TABLE users ADD COLUMN role ENUM('admin', 'user') DEFAULT 'user'`); } catch (e) {}
    try { await conn.query(`ALTER TABLE users ADD COLUMN is_approved TINYINT(1) DEFAULT 0`); } catch (e) {}

    // Party Master
    await conn.query(`
      CREATE TABLE IF NOT EXISTS parties (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        address VARCHAR(500) NULL,
        contact VARCHAR(100) NULL,
        city VARCHAR(255) NULL,
        broker VARCHAR(255) NULL,
        is_active TINYINT(1) DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);
    // Migration: add city, broker columns
    try { await conn.query(`ALTER TABLE parties ADD COLUMN city VARCHAR(255) NULL`); } catch(e) {}
    try { await conn.query(`ALTER TABLE parties ADD COLUMN broker VARCHAR(255) NULL`); } catch(e) {}

    // Item Master
    await conn.query(`
      CREATE TABLE IF NOT EXISTS items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        item_name VARCHAR(255) NOT NULL,
        is_active TINYINT(1) DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);

    // Design Master
    await conn.query(`
      CREATE TABLE IF NOT EXISTS designs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        item_id INT NOT NULL,
        design_number VARCHAR(100) NOT NULL,
        sudharo VARCHAR(255) NULL,
        stitch DECIMAL(10,2) NULL,
        rate_bhav DECIMAL(10,2) NULL,
        sleeve TINYINT(1) DEFAULT 0,
        collar TINYINT(1) DEFAULT 0,
        back_fabric TINYINT(1) DEFAULT 0,
        front TINYINT(1) DEFAULT 0,
        kohinoor TINYINT(1) DEFAULT 0,
        lachka TINYINT(1) DEFAULT 0,
        net TINYINT(1) DEFAULT 0,
        velvet TINYINT(1) DEFAULT 0,
        less TINYINT(1) DEFAULT 0,
        fabric_rate DECIMAL(10,2) NULL,
        kapda VARCHAR(255) NULL,
        piece INT NULL,
        color VARCHAR(255) NULL,
        category ENUM('none','men','kids','both') DEFAULT 'none',
        remark VARCHAR(500) NULL,
        is_active TINYINT(1) DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (item_id) REFERENCES items(id)
      )
    `);

    // Design Files
    await conn.query(`
      CREATE TABLE IF NOT EXISTS design_files (
        id INT AUTO_INCREMENT PRIMARY KEY,
        design_id INT NOT NULL,
        slot INT NOT NULL,
        file_path VARCHAR(500) NOT NULL,
        original_name VARCHAR(255) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (design_id) REFERENCES designs(id) ON DELETE CASCADE
      )
    `);

    // Orders
    await conn.query(`
      CREATE TABLE IF NOT EXISTS orders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        party_id INT NOT NULL,
        order_date DATE NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (party_id) REFERENCES parties(id)
      )
    `);

    // Migration: add party_id to existing orders table if party_name exists
    try { await conn.query(`ALTER TABLE orders ADD COLUMN party_id INT NULL`); } catch(e) {}
    try { await conn.query(`ALTER TABLE orders ADD FOREIGN KEY (party_id) REFERENCES parties(id)`); } catch(e) {}

    // Order-Design junction
    await conn.query(`
      CREATE TABLE IF NOT EXISTS order_designs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        order_id INT NOT NULL,
        design_id INT NOT NULL,
        row_num INT NOT NULL DEFAULT 0,
        ok_status TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
        FOREIGN KEY (design_id) REFERENCES designs(id)
      )
    `);

    // Order Design Sizes (size/quantity breakdown per order-design)
    await conn.query(`
      CREATE TABLE IF NOT EXISTS order_design_sizes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        order_design_id INT NOT NULL,
        size_label VARCHAR(50) NOT NULL,
        quantity INT NOT NULL DEFAULT 0,
        FOREIGN KEY (order_design_id) REFERENCES order_designs(id) ON DELETE CASCADE
      )
    `);

    // Size Master
    await conn.query(`
      CREATE TABLE IF NOT EXISTS sizes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        size_label VARCHAR(50) NOT NULL UNIQUE,
        is_active TINYINT(1) DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Category Master
    await conn.query(`
      CREATE TABLE IF NOT EXISTS categories (
        id INT AUTO_INCREMENT PRIMARY KEY,
        category_name VARCHAR(100) NOT NULL UNIQUE,
        is_active TINYINT(1) DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Order Design Categories (category breakdown per order-design)
    await conn.query(`
      CREATE TABLE IF NOT EXISTS order_design_categories (
        id INT AUTO_INCREMENT PRIMARY KEY,
        order_design_id INT NOT NULL,
        category_name VARCHAR(100) NOT NULL,
        quantity INT NOT NULL DEFAULT 0,
        FOREIGN KEY (order_design_id) REFERENCES order_designs(id) ON DELETE CASCADE
      )
    `);

    // Custom design values per order-design (when user chooses not to use defaults)
    await conn.query(`
      CREATE TABLE IF NOT EXISTS order_design_custom_values (
        id INT AUTO_INCREMENT PRIMARY KEY,
        order_design_id INT NOT NULL UNIQUE,
        item_name VARCHAR(255) NULL,
        sudharo VARCHAR(255) NULL,
        stitch DECIMAL(10,2) NULL,
        rate_bhav DECIMAL(10,2) NULL,
        sleeve TINYINT(1) DEFAULT 0,
        collar TINYINT(1) DEFAULT 0,
        back_fabric TINYINT(1) DEFAULT 0,
        front TINYINT(1) DEFAULT 0,
        kohinoor TINYINT(1) DEFAULT 0,
        lachka TINYINT(1) DEFAULT 0,
        net TINYINT(1) DEFAULT 0,
        velvet TINYINT(1) DEFAULT 0,
        less_val TINYINT(1) DEFAULT 0,
        fabric_rate DECIMAL(10,2) NULL,
        kapda VARCHAR(255) NULL,
        piece INT NULL,
        color VARCHAR(255) NULL,
        remark VARCHAR(500) NULL,
        FOREIGN KEY (order_design_id) REFERENCES order_designs(id) ON DELETE CASCADE
      )
    `);

    // Order design files (per-order file uploads for each design)
    await conn.query(`
      CREATE TABLE IF NOT EXISTS order_design_files (
        id INT AUTO_INCREMENT PRIMARY KEY,
        order_design_id INT NOT NULL,
        file_path VARCHAR(500) NOT NULL,
        original_name VARCHAR(255) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (order_design_id) REFERENCES order_designs(id) ON DELETE CASCADE
      )
    `);

    console.log('Database tables initialized');
  } finally {
    conn.release();
  }
}

module.exports = { pool, initDB };
