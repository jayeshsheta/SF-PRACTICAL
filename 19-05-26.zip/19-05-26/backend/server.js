const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });

const { initDB } = require('./db');
const authRoutes = require('./routes/auth');
const orderRoutes = require('./routes/orders_new');
const partyRoutes = require('./routes/parties');
const itemRoutes = require('./routes/items');
const designRoutes = require('./routes/designs');
const sizeRoutes = require('./routes/sizes');
const categoryRoutes = require('./routes/categories');
const reportRoutes = require('./routes/reports');
const authMiddleware = require('./middleware/auth');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors({
  origin: true,
  credentials: true,
}));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Public routes
app.use('/api/auth', authRoutes);

// Protected routes
app.use('/api/orders', authMiddleware, orderRoutes);
app.use('/api/parties', authMiddleware, partyRoutes);
app.use('/api/items', authMiddleware, itemRoutes);
app.use('/api/designs', authMiddleware, designRoutes);
app.use('/api/sizes', authMiddleware, sizeRoutes);
app.use('/api/categories', authMiddleware, categoryRoutes);
app.use('/api/reports', authMiddleware, reportRoutes);

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

async function start(retries = 5) {
  for (let i = 0; i < retries; i++) {
    try {
      await initDB();
      app.listen(PORT, () => {
        console.log(`Inventory API running on http://localhost:${PORT}`);
      });
      return;
    } catch (err) {
      console.error(`Attempt ${i + 1}/${retries} failed:`, err.message);
      if (i < retries - 1) {
        console.log(`Retrying in 5 seconds...`);
        await new Promise(r => setTimeout(r, 5000));
      } else {
        console.error('All retries exhausted. Exiting.');
        process.exit(1);
      }
    }
  }
}

start();
