-- Inventory Database Schema
CREATE DATABASE IF NOT EXISTS sempal_db;
USE sempal_db;

CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  party_name VARCHAR(255) NOT NULL,
  order_date DATE NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  row_number INT NOT NULL,
  item_name VARCHAR(255),
  design_number VARCHAR(100),
  sudharo VARCHAR(255),
  stitch VARCHAR(255),
  rate_bhav DECIMAL(10,2),
  sleeve DECIMAL(10,2),
  collar DECIMAL(10,2),
  back DECIMAL(10,2),
  front DECIMAL(10,2),
  kohinoor DECIMAL(10,2),
  lachka DECIMAL(10,2),
  net DECIMAL(10,2),
  velvet DECIMAL(10,2),
  fabric_rate DECIMAL(10,2),
  ok_status TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  kapda VARCHAR(255) NULL,
  piece INT NULL,
  remark VARCHAR(255) NULL,
  less TINYINT(1) DEFAULT 0,
  color VARCHAR(255) NULL,
isForMen TINYINT(1) DEFAULT 0,
isForKids TINYINT(1) DEFAULT 0,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS order_images (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_item_id INT NOT NULL,
  slot INT NOT NULL CHECK (slot BETWEEN 0 AND 3),
  file_path VARCHAR(500) NOT NULL,
  original_name VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_item_id) REFERENCES order_items(id) ON DELETE CASCADE
);
