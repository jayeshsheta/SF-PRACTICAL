-- Migration script: Migrate existing data from old schema to new normalized schema
-- Run this AFTER creating the new tables (schema_new.sql)

-- 1. Migrate parties from orders table
INSERT IGNORE INTO parties (name, address, contact, is_active, created_at)
SELECT DISTINCT party_name, NULL, NULL, 1, MIN(created_at)
FROM orders
GROUP BY party_name;

-- 2. Migrate items from order_items (unique item names)
INSERT IGNORE INTO items (item_name, is_active, created_at)
SELECT DISTINCT item_name, 1, MIN(created_at)
FROM order_items
WHERE item_name IS NOT NULL AND item_name != ''
GROUP BY item_name;

-- 3. Migrate designs from order_items
INSERT INTO designs (item_id, design_number, sudharo, stitch, rate_bhav,
  sleeve, collar, back_fabric, front, kohinoor, lachka, net, velvet,
  less, fabric_rate, kapda, piece, color, category, remark, is_active, created_at)
SELECT
  COALESCE((SELECT id FROM items WHERE item_name = oi.item_name LIMIT 1), 1),
  COALESCE(oi.design_number, ''),
  oi.sudharo,
  oi.stitch,
  oi.rate_bhav,
  COALESCE(oi.sleeve, 0),
  COALESCE(oi.collar, 0),
  COALESCE(oi.back_fabric, 0),
  COALESCE(oi.front, 0),
  COALESCE(oi.kohinoor, 0),
  COALESCE(oi.lachka, 0),
  COALESCE(oi.net, 0),
  COALESCE(oi.velvet, 0),
  COALESCE(oi.less, 0),
  oi.fabric_rate,
  oi.kapda,
  oi.piece,
  oi.color,
  CASE
    WHEN oi.isForMen = 1 AND oi.isForKids = 1 THEN 'both'
    WHEN oi.isForMen = 1 THEN 'men'
    WHEN oi.isForKids = 1 THEN 'kids'
    ELSE 'none'
  END,
  oi.remark,
  1,
  oi.created_at
FROM order_items oi;

-- 4. Migrate design files from order_images
INSERT INTO design_files (design_id, slot, file_path, original_name, created_at)
SELECT
  d.id,
  oi_img.slot,
  oi_img.file_path,
  oi_img.original_name,
  oi_img.created_at
FROM order_images oi_img
JOIN order_items oi ON oi_img.order_item_id = oi.id
JOIN designs d ON d.id = (
  SELECT dd.id FROM designs dd
  JOIN items i ON dd.item_id = i.id
  WHERE i.item_name = oi.item_name
    AND dd.design_number = COALESCE(oi.design_number, '')
  ORDER BY dd.created_at
  LIMIT 1
);

-- 5. Migrate orders (update to use party_id)
-- Create new orders referencing parties
INSERT INTO orders (id, party_id, order_date, created_at, updated_at)
SELECT o_old.id, p.id, o_old.order_date, o_old.created_at, o_old.updated_at
FROM orders_old o_old
JOIN parties p ON p.name = o_old.party_name;

-- NOTE: Before running step 5, rename old orders table:
-- RENAME TABLE orders TO orders_old;
-- Then create new orders table from schema_new.sql
-- Then run step 5

-- 6. Migrate order_designs (junction)
INSERT INTO order_designs (order_id, design_id, row_num, ok_status, created_at)
SELECT
  oi.order_id,
  (SELECT d.id FROM designs d JOIN items i ON d.item_id = i.id
   WHERE i.item_name = oi.item_name AND d.design_number = COALESCE(oi.design_number, '')
   ORDER BY d.created_at LIMIT 1),
  oi.row_num,
  oi.ok_status,
  oi.created_at
FROM order_items oi;
