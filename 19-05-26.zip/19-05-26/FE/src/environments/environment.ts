export const environment = {
  production: false,
  apiUrl: 'https://api.newgayatritextile.com'
};
