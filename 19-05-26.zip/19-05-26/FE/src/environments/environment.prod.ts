export const environment = {
  production: true,
  apiUrl: 'https://api.newgayatritextile.com'
};
