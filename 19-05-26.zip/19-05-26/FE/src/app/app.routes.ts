import { Routes } from '@angular/router';
import { OrderFormComponent } from './components/order-form-new/order-form-new.component';
import { OrderListComponent } from './components/order-list/order-list.component';
import { LoginComponent } from './components/login/login.component';
import { UserManagementComponent } from './components/user-management/user-management.component';
import { PartyMasterComponent } from './components/party-master/party-master.component';
import { ItemMasterComponent } from './components/item-master/item-master.component';
import { DesignMasterComponent } from './components/design-master/design-master.component';
import { SizeMasterComponent } from './components/size-master/size-master.component';
import { CategoryMasterComponent } from './components/category-master/category-master.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ReportsComponent } from './components/reports/reports.component';
import { authGuard, guestGuard, adminGuard } from './guards/auth.guard';

export const routes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'login', component: LoginComponent, canActivate: [guestGuard] },
  { path: 'dashboard', component: DashboardComponent, canActivate: [authGuard] },
  { path: 'orders', component: OrderListComponent, canActivate: [authGuard] },
  { path: 'orders/new', component: OrderFormComponent, canActivate: [authGuard] },
  { path: 'orders/:id/edit', component: OrderFormComponent, canActivate: [authGuard] },
  { path: 'parties', component: PartyMasterComponent, canActivate: [authGuard] },
  { path: 'items', component: ItemMasterComponent, canActivate: [authGuard] },
  { path: 'designs', component: DesignMasterComponent, canActivate: [authGuard] },
  { path: 'sizes', component: SizeMasterComponent, canActivate: [authGuard] },
  { path: 'categories', component: CategoryMasterComponent, canActivate: [authGuard] },
  { path: 'reports', component: ReportsComponent, canActivate: [authGuard] },
  { path: 'admin/users', component: UserManagementComponent, canActivate: [adminGuard] },
];
