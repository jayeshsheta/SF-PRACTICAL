import { CanDeactivate } from '@angular/router';
import { Injectable } from '@angular/core';
import { OrderFormComponent } from '../components/order-form/order-form.component';

@Injectable({ providedIn: 'root' })
export class UnsavedChangesGuard implements CanDeactivate<OrderFormComponent> {
  canDeactivate(component: OrderFormComponent): boolean {
    if (component.hasUnsavedChanges()) {
      return confirm('You have unsaved changes. Are you sure you want to leave?');
    }
    return true;
  }
}