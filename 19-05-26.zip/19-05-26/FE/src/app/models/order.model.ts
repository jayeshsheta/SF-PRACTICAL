export interface Party {
  id?: number;
  name: string;
  address: string;
  contact: string;
  city?: string;
  broker?: string;
  is_active?: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface Item {
  id?: number;
  item_name: string;
  is_active?: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface DesignFile {
  id?: number;
  slot: number;
  file_path: string;
  original_name: string;
}

export interface Design {
  id?: number;
  item_id: number;
  item_name?: string;
  design_number: string;
  sudharo: string;
  stitch: number | null;
  rate_bhav: number | null;
  sleeve: boolean;
  collar: boolean;
  back_fabric: boolean;
  front: boolean;
  kohinoor: boolean;
  lachka: boolean;
  net: boolean;
  velvet: boolean;
  less: boolean;
  fabric_rate: number | null;
  kapda: string;
  piece: number | null;
  color: string;
  remark: string;
  is_active?: boolean;
  files?: DesignFile[];
  in_order?: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface OrderDesignSize {
  id?: number;
  size_label: string;
  quantity: number;
}

export interface OrderDesignCategory {
  id?: number;
  category_name: string;
  quantity: number;
}

export interface OrderDesignCustomValues {
  item_name?: string;
  sudharo?: string;
  stitch?: number | null;
  rate_bhav?: number | null;
  sleeve?: boolean;
  collar?: boolean;
  back_fabric?: boolean;
  front?: boolean;
  kohinoor?: boolean;
  lachka?: boolean;
  net?: boolean;
  velvet?: boolean;
  less?: boolean;
  fabric_rate?: number | null;
  kapda?: string;
  piece?: number | null;
  color?: string;
  remark?: string;
}

export interface OrderDesignFile {
  id?: number;
  file_path: string;
  original_name: string;
}

export interface OrderDesign {
  id?: number;
  design_id: number;
  row_num: number;
  ok_status: boolean;
  sizes?: OrderDesignSize[];
  categories?: OrderDesignCategory[];
  is_custom?: boolean;
  custom_values?: OrderDesignCustomValues;
  order_files?: OrderDesignFile[];
  // Joined fields
  design_number?: string;
  item_name?: string;
  sudharo?: string;
  stitch?: number;
  rate_bhav?: number;
  sleeve?: boolean;
  collar?: boolean;
  back_fabric?: boolean;
  front?: boolean;
  kohinoor?: boolean;
  lachka?: boolean;
  net?: boolean;
  velvet?: boolean;
  less?: boolean;
  fabric_rate?: number;
  kapda?: string;
  piece?: number;
  color?: string;
  remark?: string;
  files?: DesignFile[];
}

export interface Order {
  id?: number;
  party_id: number;
  party_name?: string;
  party_address?: string;
  party_contact?: string;
  order_date: string;
  designs: OrderDesign[];
  item_count?: number;
  ok_count?: number;
  remaining?: number;
  created_at?: string;
  updated_at?: string;
}
