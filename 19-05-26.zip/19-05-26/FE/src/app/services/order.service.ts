import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Order } from '../models/order.model';
import { environment } from '../../environments/environment';

export interface PaginatedResponse {
  data: Order[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

@Injectable({ providedIn: 'root' })
export class OrderService {
  private apiUrl = `${environment.apiUrl}/api/orders`;

  constructor(private http: HttpClient) {}

  getAll(params?: { page?: number; limit?: number; search?: string; sortBy?: string; sortDir?: string; city?: string }): Observable<PaginatedResponse> {
    let httpParams = new HttpParams();
    if (params?.page) httpParams = httpParams.set('page', params.page.toString());
    if (params?.limit) httpParams = httpParams.set('limit', params.limit.toString());
    if (params?.search) httpParams = httpParams.set('search', params.search);
    if (params?.sortBy) httpParams = httpParams.set('sortBy', params.sortBy);
    if (params?.sortDir) httpParams = httpParams.set('sortDir', params.sortDir);
    if (params?.city) httpParams = httpParams.set('city', params.city);
    return this.http.get<PaginatedResponse>(this.apiUrl, { params: httpParams });
  }

  getById(id: number): Observable<Order> {
    return this.http.get<Order>(`${this.apiUrl}/${id}`);
  }

  create(order: { party_id: number; order_date: string; designs: any[] }): Observable<any> {
    return this.http.post(this.apiUrl, order);
  }

  update(id: number, order: { party_id: number; order_date: string; designs: any[] }): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}`, order);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
}
