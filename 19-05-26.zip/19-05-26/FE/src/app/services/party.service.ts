import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Party } from '../models/order.model';
import { environment } from '../../environments/environment';

export interface PaginatedResponse<T> {
  data: T[];
  pagination: { page: number; limit: number; total: number; totalPages: number; };
}

@Injectable({ providedIn: 'root' })
export class PartyService {
  private apiUrl = `${environment.apiUrl}/api/parties`;
  constructor(private http: HttpClient) {}

  getAll(params?: { page?: number; limit?: number; search?: string; sortBy?: string; sortDir?: string }): Observable<PaginatedResponse<Party>> {
    let httpParams = new HttpParams();
    if (params?.page) httpParams = httpParams.set('page', params.page.toString());
    if (params?.limit) httpParams = httpParams.set('limit', params.limit.toString());
    if (params?.search) httpParams = httpParams.set('search', params.search);
    if (params?.sortBy) httpParams = httpParams.set('sortBy', params.sortBy);
    if (params?.sortDir) httpParams = httpParams.set('sortDir', params.sortDir);
    return this.http.get<PaginatedResponse<Party>>(this.apiUrl, { params: httpParams });
  }

  getById(id: number): Observable<Party> {
    return this.http.get<Party>(`${this.apiUrl}/${id}`);
  }

  create(party: Partial<Party>): Observable<any> {
    return this.http.post(this.apiUrl, party);
  }

  update(id: number, party: Partial<Party>): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}`, party);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }

  getCities(): Observable<string[]> {
    return this.http.get<string[]>(`${this.apiUrl}/cities`);
  }
}
