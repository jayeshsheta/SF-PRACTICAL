import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface Size {
  id?: number;
  size_label: string;
  is_active?: number;
  created_at?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: { page: number; limit: number; total: number; totalPages: number; };
}

@Injectable({ providedIn: 'root' })
export class SizeService {
  private apiUrl = `${environment.apiUrl}/api/sizes`;
  constructor(private http: HttpClient) {}

  getAll(params?: { page?: number; limit?: number; search?: string; sortBy?: string; sortDir?: string }): Observable<PaginatedResponse<Size>> {
    let httpParams = new HttpParams();
    if (params?.page) httpParams = httpParams.set('page', params.page.toString());
    if (params?.limit) httpParams = httpParams.set('limit', params.limit.toString());
    if (params?.search) httpParams = httpParams.set('search', params.search);
    if (params?.sortBy) httpParams = httpParams.set('sortBy', params.sortBy);
    if (params?.sortDir) httpParams = httpParams.set('sortDir', params.sortDir);
    return this.http.get<PaginatedResponse<Size>>(this.apiUrl, { params: httpParams });
  }

  getById(id: number): Observable<Size> {
    return this.http.get<Size>(`${this.apiUrl}/${id}`);
  }

  create(size: Partial<Size>): Observable<any> {
    return this.http.post(this.apiUrl, size);
  }

  update(id: number, size: Partial<Size>): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}`, size);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
}
