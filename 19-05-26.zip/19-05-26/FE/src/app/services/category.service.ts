import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface Category {
  id?: number;
  category_name: string;
  is_active?: number;
  created_at?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: { page: number; limit: number; total: number; totalPages: number; };
}

@Injectable({ providedIn: 'root' })
export class CategoryService {
  private apiUrl = `${environment.apiUrl}/api/categories`;
  constructor(private http: HttpClient) {}

  getAll(params?: { page?: number; limit?: number; search?: string; sortBy?: string; sortDir?: string }): Observable<PaginatedResponse<Category>> {
    let httpParams = new HttpParams();
    if (params?.page) httpParams = httpParams.set('page', params.page.toString());
    if (params?.limit) httpParams = httpParams.set('limit', params.limit.toString());
    if (params?.search) httpParams = httpParams.set('search', params.search);
    if (params?.sortBy) httpParams = httpParams.set('sortBy', params.sortBy);
    if (params?.sortDir) httpParams = httpParams.set('sortDir', params.sortDir);
    return this.http.get<PaginatedResponse<Category>>(this.apiUrl, { params: httpParams });
  }

  getById(id: number): Observable<Category> {
    return this.http.get<Category>(`${this.apiUrl}/${id}`);
  }

  create(cat: Partial<Category>): Observable<any> {
    return this.http.post(this.apiUrl, cat);
  }

  update(id: number, cat: Partial<Category>): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}`, cat);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
}
