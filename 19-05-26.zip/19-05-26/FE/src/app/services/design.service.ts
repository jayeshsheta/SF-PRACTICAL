import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Design } from '../models/order.model';
import { environment } from '../../environments/environment';

export interface PaginatedResponse<T> {
  data: T[];
  pagination: { page: number; limit: number; total: number; totalPages: number; };
}

@Injectable({ providedIn: 'root' })
export class DesignService {
  private apiUrl = `${environment.apiUrl}/api/designs`;
  constructor(private http: HttpClient) {}

  getAll(params?: { page?: number; limit?: number; search?: string; sortBy?: string; sortDir?: string; item_id?: number; order_filter?: string }): Observable<PaginatedResponse<Design>> {
    let httpParams = new HttpParams();
    if (params?.page) httpParams = httpParams.set('page', params.page.toString());
    if (params?.limit) httpParams = httpParams.set('limit', params.limit.toString());
    if (params?.search) httpParams = httpParams.set('search', params.search);
    if (params?.sortBy) httpParams = httpParams.set('sortBy', params.sortBy);
    if (params?.sortDir) httpParams = httpParams.set('sortDir', params.sortDir);
    if (params?.item_id) httpParams = httpParams.set('item_id', params.item_id.toString());
    if (params?.order_filter) httpParams = httpParams.set('order_filter', params.order_filter);
    return this.http.get<PaginatedResponse<Design>>(this.apiUrl, { params: httpParams });
  }

  getById(id: number): Observable<Design> {
    return this.http.get<Design>(`${this.apiUrl}/${id}`);
  }

  create(design: Partial<Design>): Observable<any> {
    return this.http.post(this.apiUrl, design);
  }

  update(id: number, design: Partial<Design>): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}`, design);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }

  uploadFiles(designId: number, files: File[], slot: number): Observable<any> {
    const formData = new FormData();
    files.forEach(f => formData.append('files', f));
    formData.append('slot', slot.toString());
    return this.http.post(`${this.apiUrl}/${designId}/files`, formData);
  }

  deleteFile(fileId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/files/${fileId}`);
  }
}
