import { Component } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule, AsyncPipe } from '@angular/common';
import { ToastComponent } from './components/toast/toast.component';
import { AuthService } from './services/auth.service';
import { LoaderService } from './services/loader.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, AsyncPipe, RouterOutlet, RouterLink, RouterLinkActive, ToastComponent],
  template: `
    <app-toast></app-toast>
    <!-- Global Loader -->
    <div class="global-loader" *ngIf="loader.loading$ | async">
      <div class="global-loader-bar"></div>
    </div>
    <div class="container">
      <nav class="app-nav" *ngIf="auth.isLoggedIn">
        <a routerLink="/dashboard" class="nav-brand">📦 Gayatri Textile</a>
        <div class="nav-links">
          <div class="nav-group">
            <a routerLink="/dashboard" routerLinkActive="active">📊 Dashboard</a>
            <a routerLink="/orders" routerLinkActive="active" [routerLinkActiveOptions]="{exact:true}">📋 Orders</a>
            <a routerLink="/orders/new" class="nav-primary">+ New</a>
            <a routerLink="/reports" routerLinkActive="active">📄 Reports</a>
          </div>
          <div class="nav-divider"></div>
          <div class="nav-group">
            <a routerLink="/parties" routerLinkActive="active">👥 Parties</a>
            <a routerLink="/items" routerLinkActive="active">📦 Items</a>
            <a routerLink="/designs" routerLinkActive="active">🎨 Designs</a>
            <a routerLink="/sizes" routerLinkActive="active">📐 Sizes</a>
            <a routerLink="/categories" routerLinkActive="active">🏷️ Categories</a>
          </div>
          <div class="nav-divider" *ngIf="auth.isAdmin"></div>
          <div class="nav-group" *ngIf="auth.isAdmin">
            <a routerLink="/admin/users" routerLinkActive="active">👤 Users</a>
          </div>
          <div class="nav-divider"></div>
          <div class="user-menu">
            <span class="user-name">{{ auth.currentUser?.name }}</span>
            <button class="btn btn-danger btn-sm" (click)="auth.logout()">Logout</button>
          </div>
        </div>
      </nav>
      <router-outlet></router-outlet>
    </div>
  `,
  styles: [`
    .app-nav {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px 0;
      margin-bottom: 16px;
      border-bottom: 2px solid var(--border);
    }
    .nav-brand {
      font-family: 'IBM Plex Mono', monospace;
      font-size: 16px;
      font-weight: 700;
      color: var(--accent);
      text-decoration: none;
      letter-spacing: 1.5px;
      white-space: nowrap;
    }
    .nav-links { display: flex; gap: 4px; align-items: center; flex-wrap: wrap; }
    .nav-group { display: flex; gap: 2px; align-items: center; }
    .nav-group a {
      text-decoration: none;
      font-size: 12px;
      font-weight: 500;
      padding: 5px 10px;
      border-radius: 4px;
      color: var(--text);
      transition: background 0.15s, color 0.15s;
    }
    .nav-group a:hover { background: #eef5e6; color: var(--accent); }
    .nav-group a.active { background: var(--accent); color: #fff; }
    .nav-group a.nav-primary { background: var(--accent); color: #fff; font-weight: 600; }
    .nav-group a.nav-primary:hover { background: #1e3a0f; }
    .nav-divider { width: 1px; height: 20px; background: var(--border); margin: 0 6px; }
    .user-menu {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .user-name {
      font-size: 12px;
      font-weight: 600;
      color: var(--text-muted, #6b7280);
    }
    .global-loader {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      height: 3px;
      z-index: 9999;
      overflow: hidden;
    }
    .global-loader-bar {
      height: 100%;
      width: 40%;
      background: linear-gradient(90deg, var(--accent, #2d5016), var(--accent3, #4527a0));
      border-radius: 0 2px 2px 0;
      animation: loaderSlide 1.2s ease-in-out infinite;
    }
    @keyframes loaderSlide {
      0% { transform: translateX(-100%); }
      100% { transform: translateX(350%); }
    }
  `],
})
export class AppComponent {
  constructor(public auth: AuthService, public loader: LoaderService) {}
}
