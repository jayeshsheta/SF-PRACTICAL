import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService, User } from '../../services/auth.service';
import { ToastService } from '../../services/toast.service';

@Component({
  selector: 'app-user-management',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="header-card">
      <div class="header-title">👥 User Management</div>
    </div>

    <div class="loading-bar" *ngIf="loading">
      <div class="spinner-sm"></div> Loading users...
    </div>

    <div class="users-grid" *ngIf="!loading">
      <!-- Pending approvals -->
      <div class="section" *ngIf="pendingUsers.length">
        <h3 class="section-title">⏳ Pending Approval ({{ pendingUsers.length }})</h3>
        <div class="user-card pending" *ngFor="let user of pendingUsers">
          <div class="user-info">
            <div class="user-avatar">{{ user.name.charAt(0).toUpperCase() }}</div>
            <div>
              <div class="user-name">{{ user.name }}</div>
              <div class="user-email">{{ user.email }}</div>
              <div class="user-date">Registered: {{ user.created_at | date:'medium' }}</div>
            </div>
          </div>
          <div class="user-actions">
            <button class="btn btn-success btn-sm" (click)="approve(user)">✓ Approve</button>
            <button class="btn btn-danger btn-sm" (click)="deleteUser(user)">✕ Delete</button>
          </div>
        </div>
      </div>

      <!-- Approved users -->
      <div class="section">
        <h3 class="section-title">✅ Active Users ({{ approvedUsers.length }})</h3>
        <div class="user-card" *ngFor="let user of approvedUsers">
          <div class="user-info">
            <div class="user-avatar" [class.admin]="user.role === 'admin'">{{ user.name.charAt(0).toUpperCase() }}</div>
            <div>
              <div class="user-name">
                {{ user.name }}
                <span class="badge admin" *ngIf="user.role === 'admin'">Admin</span>
                <span class="badge user" *ngIf="user.role !== 'admin'">User</span>
              </div>
              <div class="user-email">{{ user.email }}</div>
              <div class="user-date">Joined: {{ user.created_at | date:'medium' }}</div>
            </div>
          </div>
          <div class="user-actions" *ngIf="user.id !== currentUserId">
            <button class="btn btn-warning btn-sm" (click)="revoke(user)">Revoke</button>
            <button class="btn btn-danger btn-sm" (click)="deleteUser(user)">Delete</button>
          </div>
          <div class="user-actions" *ngIf="user.id === currentUserId">
            <span class="badge you">You</span>
          </div>
        </div>
      </div>

      <div class="empty-state" *ngIf="!pendingUsers.length && approvedUsers.length <= 1">
        <p>No other users registered yet.</p>
      </div>
    </div>
  `,
  styles: [`
    .header-card {
      background: var(--surface, #fff);
      border: 2px solid var(--border-dark, #ccc);
      border-radius: 4px;
      padding: 20px 24px;
      margin-bottom: 16px;
      box-shadow: var(--shadow);
    }
    .header-title {
      font-family: 'IBM Plex Mono', monospace;
      font-size: 22px;
      font-weight: 700;
      letter-spacing: 1px;
    }
    .loading-bar {
      display: flex; align-items: center; gap: 10px;
      padding: 20px; color: var(--text-muted);
    }
    .spinner-sm {
      width: 20px; height: 20px;
      border: 3px solid #e5e7eb;
      border-top: 3px solid var(--accent, #2563eb);
      border-radius: 50%;
      animation: spin 0.7s linear infinite;
    }
    @keyframes spin { to { transform: rotate(360deg); } }
    .section { margin-bottom: 24px; }
    .section-title {
      font-size: 16px; font-weight: 600;
      margin: 0 0 12px; color: var(--text, #1f2937);
    }
    .user-card {
      display: flex;
      align-items: center;
      justify-content: space-between;
      background: var(--surface, #fff);
      border: 2px solid var(--border, #d1d5db);
      border-radius: 10px;
      padding: 16px 20px;
      margin-bottom: 10px;
      transition: border-color 0.2s;
    }
    .user-card.pending {
      border-color: #f59e0b;
      background: #fffbeb;
    }
    .user-info {
      display: flex; align-items: center; gap: 14px;
    }
    .user-avatar {
      width: 44px; height: 44px;
      border-radius: 50%;
      background: var(--accent, #2563eb);
      color: #fff;
      display: flex; align-items: center; justify-content: center;
      font-size: 20px; font-weight: 700;
    }
    .user-avatar.admin { background: #16a34a; }
    .user-name { font-weight: 600; font-size: 15px; display: flex; align-items: center; gap: 8px; }
    .user-email { font-size: 13px; color: var(--text-muted, #6b7280); }
    .user-date { font-size: 12px; color: var(--text-muted, #9ca3af); margin-top: 2px; }
    .user-actions { display: flex; gap: 8px; }
    .badge {
      font-size: 11px; padding: 2px 8px; border-radius: 20px; font-weight: 600;
    }
    .badge.admin { background: #dcfce7; color: #16a34a; }
    .badge.user { background: #dbeafe; color: #2563eb; }
    .badge.you { background: #f3f4f6; color: #6b7280; font-size: 12px; padding: 4px 12px; }
    .btn-success { background: #16a34a; color: #fff; border: none; }
    .btn-success:hover { background: #15803d; }
    .btn-warning { background: #f59e0b; color: #fff; border: none; }
    .btn-warning:hover { background: #d97706; }
    .empty-state {
      text-align: center; padding: 40px; color: var(--text-muted);
    }
    @media (max-width: 600px) {
      .user-card { flex-direction: column; align-items: flex-start; gap: 12px; }
    }
  `],
})
export class UserManagementComponent implements OnInit {
  users: User[] = [];
  loading = false;
  currentUserId: number;

  constructor(
    private authService: AuthService,
    private toast: ToastService
  ) {
    this.currentUserId = this.authService.currentUser?.id || 0;
  }

  get pendingUsers(): User[] {
    return this.users.filter(u => !u.is_approved);
  }

  get approvedUsers(): User[] {
    return this.users.filter(u => u.is_approved);
  }

  ngOnInit() {
    this.loadUsers();
  }

  loadUsers() {
    this.loading = true;
    this.authService.getUsers().subscribe({
      next: (res) => {
        this.users = res.users;
        this.loading = false;
      },
      error: (err) => {
        this.loading = false;
        this.toast.error(err.error?.error || 'Failed to load users');
      },
    });
  }

  approve(user: User) {
    this.authService.approveUser(user.id).subscribe({
      next: (res) => {
        this.toast.success(res.message);
        this.loadUsers();
      },
      error: (err) => this.toast.error(err.error?.error || 'Failed to approve'),
    });
  }

  revoke(user: User) {
    if (!confirm(`Revoke access for "${user.name}"?`)) return;
    this.authService.rejectUser(user.id).subscribe({
      next: (res) => {
        this.toast.success(res.message);
        this.loadUsers();
      },
      error: (err) => this.toast.error(err.error?.error || 'Failed to revoke'),
    });
  }

  deleteUser(user: User) {
    if (!confirm(`Delete user "${user.name}"? This cannot be undone.`)) return;
    this.authService.deleteUser(user.id).subscribe({
      next: () => {
        this.toast.success('User deleted');
        this.loadUsers();
      },
      error: (err) => this.toast.error(err.error?.error || 'Failed to delete'),
    });
  }
}
