import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-import-preview',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="overlay" (click)="cancel.emit()">
      <div class="modal" (click)="$event.stopPropagation()">
        <div class="modal-header">
          <h3>📥 Import Preview</h3>
          <span class="modal-close" (click)="cancel.emit()">×</span>
        </div>
        <p class="modal-info">{{ data.length }} row(s) found. Images are ignored during import. Review data before saving.</p>
        <div class="preview-table-wrap">
          <table *ngIf="data.length">
            <thead>
              <tr>
                <th>#</th>
                <th *ngFor="let col of columns">{{ col }}</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let row of data; let i = index">
                <td>{{ i + 1 }}</td>
                <td *ngFor="let col of columns">{{ row[col] }}</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="modal-actions">
          <button class="btn btn-secondary" (click)="cancel.emit()">Cancel</button>
          <button class="btn btn-primary" (click)="confirm.emit(data)">✅ Import {{ data.length }} Rows</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .overlay {
      position: fixed;
      inset: 0;
      background: rgba(0,0,0,0.6);
      z-index: 1000;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    .modal {
      background: white;
      border-radius: 6px;
      max-width: 95vw;
      max-height: 85vh;
      display: flex;
      flex-direction: column;
      box-shadow: 0 8px 40px rgba(0,0,0,0.3);
      width: 1100px;
    }
    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 16px 20px;
      border-bottom: 2px solid #e0e0e0;
    }
    .modal-header h3 {
      font-family: 'IBM Plex Mono', monospace;
      font-size: 16px;
      color: #2d5016;
    }
    .modal-close {
      font-size: 24px;
      cursor: pointer;
      color: #888;
    }
    .modal-info {
      padding: 10px 20px;
      font-size: 13px;
      color: #6b5a42;
    }
    .preview-table-wrap {
      flex: 1;
      overflow: auto;
      padding: 0 20px 16px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 12px;
    }
    th {
      background: #2d5016;
      color: white;
      padding: 8px 10px;
      font-family: 'IBM Plex Mono', monospace;
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      white-space: nowrap;
      position: sticky;
      top: 0;
    }
    td {
      padding: 6px 10px;
      border-bottom: 1px solid #e0e0e0;
      white-space: nowrap;
    }
    tr:nth-child(even) { background: #faf6ef; }
    tr:hover { background: #eef5e6; }
    .modal-actions {
      padding: 12px 20px;
      border-top: 2px solid #e0e0e0;
      display: flex;
      gap: 10px;
      justify-content: flex-end;
    }
  `],
})
export class ImportPreviewComponent {
  @Input() data: any[] = [];
  @Output() confirm = new EventEmitter<any[]>();
  @Output() cancel = new EventEmitter<void>();

  get columns(): string[] {
    if (!this.data.length) return [];
    return Object.keys(this.data[0]).filter(
      (k) => !k.toLowerCase().startsWith('img') && k !== '#'
    );
  }
}
