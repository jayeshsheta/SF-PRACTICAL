import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="dash-header">
      <div class="dash-title">📊 Dashboard</div>
    </div>

    <div class="stats-grid" *ngIf="stats">
      <div class="stat-card">
        <div class="stat-icon">📋</div>
        <div class="stat-value">{{ stats.totalOrders }}</div>
        <div class="stat-label">Total Orders</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon">👥</div>
        <div class="stat-value">{{ stats.totalParties }}</div>
        <div class="stat-label">Parties</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon">🎨</div>
        <div class="stat-value">{{ stats.totalDesigns }}</div>
        <div class="stat-label">Designs</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon">📦</div>
        <div class="stat-value">{{ stats.totalItems }}</div>
        <div class="stat-label">Items</div>
      </div>
      <div class="stat-card stat-success">
        <div class="stat-icon">✅</div>
        <div class="stat-value">{{ stats.completedDesigns }}</div>
        <div class="stat-label">Completed</div>
      </div>
      <div class="stat-card stat-warning">
        <div class="stat-icon">⏳</div>
        <div class="stat-value">{{ stats.pendingDesigns }}</div>
        <div class="stat-label">Pending</div>
      </div>
    </div>

    <div class="dash-sections" *ngIf="stats">
      <div class="dash-section">
        <h3>📋 Recent Orders</h3>
        <table class="dash-table">
          <thead>
            <tr><th>#</th><th>Party</th><th>Date</th><th>Designs</th></tr>
          </thead>
          <tbody>
            <tr *ngFor="let o of stats.recentOrders; let i = index">
              <td>{{ i+1 }}</td>
              <td><a [routerLink]="['/orders', o.id, 'edit']">{{ o.party_name }}</a></td>
              <td>{{ o.order_date | date:'dd/MM/yyyy' }}</td>
              <td>{{ o.design_count }}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="dash-section">
        <h3>🔥 Top Designs</h3>
        <table class="dash-table">
          <thead>
            <tr><th>#</th><th>Design</th><th>Item</th><th>Orders</th></tr>
          </thead>
          <tbody>
            <tr *ngFor="let d of stats.topDesigns; let i = index">
              <td>{{ i+1 }}</td>
              <td><strong>{{ d.design_number }}</strong></td>
              <td>{{ d.item_name }}</td>
              <td>{{ d.usage_count }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `,
  styles: [`
    .dash-header { background: var(--surface); border: 2px solid var(--border-dark); border-radius: 4px; padding: 16px 20px; margin-bottom: 16px; }
    .dash-title { font-family: 'IBM Plex Mono', monospace; font-size: 18px; font-weight: 600; color: var(--accent); letter-spacing: 2px; text-transform: uppercase; }
    .stats-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 14px; margin-bottom: 20px; }
    .stat-card { background: var(--surface); border: 2px solid var(--border-dark); border-radius: 6px; padding: 18px 14px; text-align: center; }
    .stat-card.stat-success { border-color: #16a34a; }
    .stat-card.stat-warning { border-color: #d97706; }
    .stat-icon { font-size: 28px; margin-bottom: 6px; }
    .stat-value { font-family: 'IBM Plex Mono', monospace; font-size: 28px; font-weight: 700; color: var(--accent); }
    .stat-label { font-size: 12px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px; margin-top: 4px; }
    .dash-sections { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    .dash-section { background: var(--surface); border: 2px solid var(--border-dark); border-radius: 4px; padding: 16px; }
    .dash-section h3 { font-family: 'IBM Plex Mono', monospace; font-size: 14px; color: var(--accent); margin-bottom: 10px; }
    .dash-table { width: 100%; border-collapse: collapse; font-size: 13px; }
    .dash-table thead th { background: var(--header-bg); color: var(--header-text); padding: 8px 10px; font-size: 11px; text-transform: uppercase; }
    .dash-table tbody td { padding: 7px 10px; border-bottom: 1px solid var(--border); }
    .dash-table a { color: var(--accent); text-decoration: none; }
    .dash-table a:hover { text-decoration: underline; }
    @media (max-width: 768px) { .dash-sections { grid-template-columns: 1fr; } .stats-grid { grid-template-columns: repeat(2, 1fr); } }
  `]
})
export class DashboardComponent implements OnInit {
  stats: any = null;

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.http.get(`${environment.apiUrl}/api/reports/dashboard`).subscribe((data: any) => {
      this.stats = data;
    });
  }
}
