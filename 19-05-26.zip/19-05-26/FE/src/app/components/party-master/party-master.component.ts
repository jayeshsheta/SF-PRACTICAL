import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { PartyService } from '../../services/party.service';
import { ToastService } from '../../services/toast.service';
import { Party } from '../../models/order.model';

@Component({
  selector: 'app-party-master',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="master-header">
      <div class="master-title">👥 Party Master</div>
    </div>

    <div class="master-toolbar">
      <div class="master-search">
        <input type="text" [(ngModel)]="searchText" (input)="loadParties()"
               placeholder="Search parties..." class="master-search-input">
      </div>
      <button class="btn btn-primary btn-sm" (click)="showForm = true; editParty = { name: '', address: '', contact: '' }">+ Add Party</button>
    </div>

    <!-- Form Modal -->
    <div class="modal-overlay" *ngIf="showForm" (click)="showForm = false">
      <div class="modal-box" (click)="$event.stopPropagation()">
        <div class="modal-head">
          <h3>{{ editParty.id ? 'Edit' : 'New' }} Party</h3>
          <span class="modal-close" (click)="showForm = false">×</span>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>Name *</label>
            <input type="text" [(ngModel)]="editParty.name" placeholder="Party name" class="form-input">
          </div>
          <div class="form-group">
            <label>Address</label>
            <input type="text" [(ngModel)]="editParty.address" placeholder="Address" class="form-input">
          </div>
          <div class="form-group">
            <label>Contact</label>
            <input type="text" [(ngModel)]="editParty.contact" placeholder="Phone / Email" class="form-input">
          </div>
          <div class="form-group">
            <label>City</label>
            <input type="text" [(ngModel)]="editParty.city" placeholder="City" class="form-input">
          </div>
          <div class="form-group">
            <label>Broker</label>
            <input type="text" [(ngModel)]="editParty.broker" placeholder="Broker name" class="form-input">
          </div>
        </div>
        <div class="modal-foot">
          <button class="btn btn-secondary btn-sm" (click)="showForm = false">Cancel</button>
          <button class="btn btn-primary btn-sm" (click)="saveParty()" [disabled]="!editParty.name?.trim()">
            {{ editParty.id ? 'Update' : 'Save' }}
          </button>
        </div>
      </div>
    </div>

    <!-- Pagination -->
    <div class="master-pagination">
      <select [(ngModel)]="limit" (change)="loadParties()" class="page-select">
        <option [value]="10">10</option>
        <option [value]="20">20</option>
        <option [value]="50">50</option>
        <option [value]="100">100</option>
        <option [value]="1000">1000</option>
      </select>
      <span class="page-info">Page {{ page }} of {{ totalPages }} ({{ total }} records)</span>
      <button class="btn btn-sm btn-secondary" [disabled]="page <= 1" (click)="page = page - 1; loadParties()">‹</button>
      <button class="btn btn-sm btn-secondary" [disabled]="page >= totalPages" (click)="page = page + 1; loadParties()">›</button>
    </div>

    <!-- Table -->
    <div class="master-table-wrap">
      <table class="master-table">
        <thead>
          <tr>
            <th style="width:50px">#</th>
            <th (click)="toggleSort('name')">Name <span *ngIf="sortBy==='name'">{{sortDir==='ASC'?'▲':'▼'}}</span></th>
            <th>Address</th>
            <th>Contact</th>
            <th>City</th>
            <th>Broker</th>
            <th style="width:150px">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let p of parties; let i = index">
            <td>{{ (page-1)*limit + i + 1 }}</td>
            <td><strong>{{ p.name }}</strong></td>
            <td>{{ p.address || '—' }}</td>
            <td>{{ p.contact || '—' }}</td>
            <td>{{ p.city || '—' }}</td>
            <td>{{ p.broker || '—' }}</td>
            <td>
              <button class="btn btn-secondary btn-sm" (click)="onEdit(p)">Edit</button>
              <button class="btn btn-danger btn-sm" (click)="onDelete(p)">Delete</button>
            </td>
          </tr>
          <tr *ngIf="!parties.length"><td colspan="7" class="empty-row">No parties found</td></tr>
        </tbody>
      </table>
    </div>
  `,
  styles: [`
    .master-header { background: var(--surface); border: 2px solid var(--border-dark); border-radius: 4px; padding: 16px 20px; margin-bottom: 12px; }
    .master-title { font-family: 'IBM Plex Mono', monospace; font-size: 18px; font-weight: 600; color: var(--accent); letter-spacing: 2px; text-transform: uppercase; }
    .master-toolbar { display: flex; gap: 12px; align-items: center; margin-bottom: 12px; flex-wrap: wrap; }
    .master-search-input { border: 1.5px solid var(--border); border-radius: 3px; padding: 7px 12px; font-size: 13px; width: 280px; background: var(--surface); }
    .master-search-input:focus { outline: none; border-color: var(--accent); }
    .master-pagination { display: flex; gap: 10px; align-items: center; margin-bottom: 10px; flex-wrap: wrap; }
    .page-select { border: 1.5px solid var(--border); border-radius: 3px; padding: 4px 8px; font-size: 12px; }
    .page-info { font-size: 12px; color: var(--text-muted); }
    .master-table-wrap { background: var(--surface); border: 2px solid var(--border-dark); border-radius: 4px; overflow-x: auto; }
    .master-table { width: 100%; border-collapse: collapse; font-size: 13px; }
    .master-table thead th { background: var(--header-bg); color: var(--header-text); padding: 10px 12px; font-family: 'IBM Plex Mono', monospace; font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; cursor: pointer; white-space: nowrap; }
    .master-table tbody td { padding: 8px 12px; border-bottom: 1px solid var(--border); }
    .master-table tbody tr:nth-child(even) { background: var(--row-alt); }
    .master-table tbody tr:hover { background: #eef5e6; }
    .empty-row { text-align: center; color: var(--text-muted); padding: 24px !important; }
    .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center; padding: 20px; }
    .modal-box { background: white; border-radius: 6px; width: 100%; max-width: 480px; box-shadow: 0 8px 40px rgba(0,0,0,0.3); }
    .modal-head { display: flex; justify-content: space-between; align-items: center; padding: 14px 20px; border-bottom: 2px solid var(--border); }
    .modal-head h3 { font-family: 'IBM Plex Mono', monospace; font-size: 15px; color: var(--accent); }
    .modal-close { font-size: 22px; cursor: pointer; color: #888; }
    .modal-body { padding: 16px 20px; }
    .form-group { margin-bottom: 12px; }
    .form-group label { display: block; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; color: var(--text-muted); margin-bottom: 4px; }
    .form-input { width: 100%; border: 1.5px solid var(--border); border-radius: 3px; padding: 8px 10px; font-size: 13px; }
    .form-input:focus { outline: none; border-color: var(--accent); }
    .modal-foot { display: flex; gap: 8px; justify-content: flex-end; padding: 12px 20px; border-top: 2px solid var(--border); }
    @media (max-width: 768px) {
      .master-search-input { width: 100%; }
      .master-toolbar { flex-direction: column; align-items: stretch; }
    }
  `]
})
export class PartyMasterComponent implements OnInit {
  parties: Party[] = [];
  searchText = '';
  page = 1;
  limit = 1000;
  total = 0;
  totalPages = 1;
  sortBy = 'name';
  sortDir = 'ASC';
  showForm = false;
  editParty: Partial<Party> = { name: '', address: '', contact: '', city: '', broker: '' };

  constructor(private partyService: PartyService, private toast: ToastService) {}

  ngOnInit() { this.loadParties(); }

  loadParties() {
    this.partyService.getAll({ page: this.page, limit: this.limit, search: this.searchText, sortBy: this.sortBy, sortDir: this.sortDir })
      .subscribe(res => {
        this.parties = res.data;
        this.total = res.pagination.total;
        this.totalPages = res.pagination.totalPages;
      });
  }

  toggleSort(col: string) {
    if (this.sortBy === col) this.sortDir = this.sortDir === 'ASC' ? 'DESC' : 'ASC';
    else { this.sortBy = col; this.sortDir = 'ASC'; }
    this.loadParties();
  }

  onEdit(p: Party) {
    this.editParty = { ...p };
    this.showForm = true;
  }

  saveParty() {
    if (!this.editParty.name?.trim()) return;
    const obs = this.editParty.id
      ? this.partyService.update(this.editParty.id, this.editParty)
      : this.partyService.create(this.editParty);
    obs.subscribe(() => {
      this.toast.show(this.editParty.id ? 'Party updated' : 'Party created', 'success');
      this.showForm = false;
      this.loadParties();
    });
  }

  onDelete(p: Party) {
    if (!confirm(`Deactivate party "${p.name}"?`)) return;
    this.partyService.delete(p.id!).subscribe(() => {
      this.toast.show('Party deactivated', 'success');
      this.loadParties();
    });
  }
}
