import { Component, OnInit, OnDestroy, ElementRef, Renderer2, ViewEncapsulation } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { Subject, debounceTime, distinctUntilChanged } from 'rxjs';
import { OrderService } from '../../services/order.service';
import { PartyService } from '../../services/party.service';
import { ToastService } from '../../services/toast.service';
import { Order } from '../../models/order.model';

@Component({
  selector: 'app-order-list',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  providers: [DatePipe],
  encapsulation: ViewEncapsulation.None,
  template: `
    <div class="ol-header-card">
      <div class="ol-header-title">📋 Orders List</div>
    </div>

    <div class="ol-toolbar">
      <div class="ol-search-box">
        <svg class="ol-search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
        </svg>
        <input type="text" [(ngModel)]="searchText" (ngModelChange)="onSearchChange(\$event)"
               placeholder="Search by party, item, D.No, rate, fabric rate..." class="ol-search-input">
        <button *ngIf="searchText" class="ol-search-clear" (click)="clearSearch()">✕</button>
      </div>
      <select [(ngModel)]="cityFilter" (change)="onCityFilterChange()" class="ol-city-filter">
        <option value="">All Cities</option>
        <option *ngFor="let c of cities" [value]="c">{{ c }}</option>
      </select>
      <a routerLink="/orders/new" class="btn btn-primary">+ New Order</a>
    </div>

    <div class="ol-loading" *ngIf="loading">
      <div class="ol-spinner"></div> Loading orders...
    </div>

    <div class="ol-table-wrap" *ngIf="orders.length; else empty">
      <table class="ol-table">
        <thead>
          <tr>
            <th style="width:50px">#</th>
            <th style="width:220px" (click)="onThClick('party_name')">
              Party Name
              <span class="ol-sort-arrow" *ngIf="sortBy === 'party_name'">{{ sortDir === 'ASC' ? '▲' : '▼' }}</span>
              <div class="ol-resize-handle" (mousedown)="startResize(\$event)"></div>
            </th>
            <th style="width:120px" (click)="onThClick('order_date')">
              Date
              <span class="ol-sort-arrow" *ngIf="sortBy === 'order_date'">{{ sortDir === 'ASC' ? '▲' : '▼' }}</span>
              <div class="ol-resize-handle" (mousedown)="startResize(\$event)"></div>
            </th>
            <th style="width:70px" (click)="onThClick('item_count')">
              Items
              <span class="ol-sort-arrow" *ngIf="sortBy === 'item_count'">{{ sortDir === 'ASC' ? '▲' : '▼' }}</span>
              <div class="ol-resize-handle" (mousedown)="startResize(\$event)"></div>
            </th>
            <th style="width:70px" (click)="onThClick('remaining')">
              Remaining
              <span class="ol-sort-arrow" *ngIf="sortBy === 'remaining'">{{ sortDir === 'ASC' ? '▲' : '▼' }}</span>
              <div class="ol-resize-handle" (mousedown)="startResize(\$event)"></div>
            </th>
            <th style="width:80px">
              Completed
              <div class="ol-resize-handle" (mousedown)="startResize(\$event)"></div>
            </th>
            <th style="width:170px" (click)="onThClick('updated_at')">
              Last Updated
              <span class="ol-sort-arrow" *ngIf="sortBy === 'updated_at'">{{ sortDir === 'ASC' ? '▲' : '▼' }}</span>
              <div class="ol-resize-handle" (mousedown)="startResize(\$event)"></div>
            </th>
            <th style="width:150px">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let o of orders; let i = index">
            <td class="ol-td-num">{{ (page - 1) * limit + i + 1 }}</td>
            <td [attr.title]="o.party_name"><strong>{{ o.party_name }}</strong></td>
            <td [attr.title]="formatDate(o.order_date)">{{ o.order_date | date:'dd/MM/yyyy' }}</td>
            <td [attr.title]="(o.item_count || o.items?.length || '—') + ''">{{ o.item_count || o.items?.length || '—' }}</td>
            <td [attr.title]="o.remaining != null ? o.remaining + '' : '—'">{{ o.remaining != null ? o.remaining : '—' }}</td>
            <td [attr.title]="o.ok_count != null ? o.ok_count + '' : '—'">{{ o.ok_count != null ? o.ok_count : '—' }}</td>
            <td [attr.title]="formatDateTime(o.updated_at || o.created_at)">{{ (o.updated_at || o.created_at) | date:'dd/MM/yyyy HH:mm' }}</td>
            <td class="ol-td-actions">
              <a [routerLink]="['/orders', o.id, 'edit']" class="btn btn-secondary btn-sm">Edit</a>
              <button class="btn btn-danger btn-sm" (click)="deleteOrder(o)">Delete</button>
            </td>
          </tr>
        </tbody>
        <tfoot>
          <tr class="ol-totals-row">
            <td colspan="3" class="ol-totals-label"><strong>📊 Page Totals</strong></td>
            <td><strong>{{ totalItemsSum }}</strong><span class="ol-totals-sub">items</span></td>
            <td><strong>{{ totalRemainingSum }}</strong><span class="ol-totals-sub">remaining</span></td>
            <td><strong>{{ totalCompletedSum }}</strong><span class="ol-totals-sub">completed</span></td>
            <td colspan="2"></td>
          </tr>
        </tfoot>
      </table>

      <div class="ol-pagination">
        <div class="ol-page-size">
          <label>Rows:</label>
          <select [(ngModel)]="limit" (ngModelChange)="onLimitChange()">
            <option [value]="10">10</option>
            <option [value]="20">20</option>
            <option [value]="50">50</option>
            <option [value]="100">100</option>
            <option [value]="1000">1000</option>
          </select>
        </div>
        <div class="ol-page-info">
          <span class="ol-stat">📋 {{ total }} orders</span>
          <span class="ol-stat">🎨 {{ totalDesigns }} designs</span>
        </div>
        <div class="ol-page-info">
          {{ (page - 1) * limit + 1 }}–{{ page * limit > total ? total : page * limit }} of {{ total }}
        </div>
        <div class="ol-page-nav">
          <button class="ol-page-btn" [disabled]="page <= 1" (click)="goToPage(1)" title="First">«</button>
          <button class="ol-page-btn" [disabled]="page <= 1" (click)="goToPage(page - 1)" title="Previous">‹</button>
          <span class="ol-page-current">Page {{ page }} / {{ totalPages }}</span>
          <button class="ol-page-btn" [disabled]="page >= totalPages" (click)="goToPage(page + 1)" title="Next">›</button>
          <button class="ol-page-btn" [disabled]="page >= totalPages" (click)="goToPage(totalPages)" title="Last">»</button>
        </div>
      </div>
    </div>

    <ng-template #empty>
      <div class="ol-empty" *ngIf="!loading">
        <p *ngIf="searchText">No orders matching "<strong>{{ searchText }}</strong>". <button class="ol-link-btn" (click)="clearSearch()">Clear search</button></p>
        <p *ngIf="!searchText">No orders yet. <a routerLink="/orders/new">Create your first order</a></p>
      </div>
    </ng-template>
  `,
  styles: [`
    .ol-header-card {
      background: var(--surface); border: 2px solid var(--border-dark);
      border-radius: 4px; padding: 16px 24px; margin-bottom: 16px; box-shadow: var(--shadow);
    }
    .ol-header-title {
      font-family: 'IBM Plex Mono', monospace; font-size: 18px; font-weight: 600;
      color: var(--accent); letter-spacing: 2px; text-transform: uppercase;
    }
    .ol-toolbar {
      display: flex; justify-content: space-between; align-items: center;
      margin-bottom: 12px; gap: 12px; flex-wrap: wrap;
    }
    .ol-toolbar a { text-decoration: none; }
    .ol-search-box { position: relative; flex: 1; max-width: 500px; min-width: 200px; }
    .ol-search-icon {
      position: absolute; left: 10px; top: 50%; transform: translateY(-50%);
      color: var(--text-muted); pointer-events: none;
    }
    .ol-search-input {
      width: 100%; padding: 9px 32px 9px 34px; border: 2px solid var(--border);
      border-radius: 4px; font-size: 13px; font-family: 'IBM Plex Sans', sans-serif;
      background: var(--surface); color: var(--text); transition: border-color 0.2s; box-sizing: border-box;
    }
    .ol-search-input:focus { outline: none; border-color: var(--accent); }
    .ol-search-input::placeholder { color: var(--text-muted); font-size: 12px; }
    .ol-search-clear {
      position: absolute; right: 8px; top: 50%; transform: translateY(-50%);
      background: none; border: none; cursor: pointer; color: var(--text-muted); font-size: 14px;
    }
    .ol-search-clear:hover { color: var(--text); }
    .ol-city-filter { padding: 8px 10px; border: 2px solid var(--border); border-radius: 4px; font-size: 13px; background: var(--surface); cursor: pointer; }
    .ol-city-filter:focus { outline: none; border-color: var(--accent); }
    .ol-table-wrap {
      background: var(--surface); border: 2px solid var(--border-dark);
      border-radius: 4px; overflow-x: auto; box-shadow: var(--shadow);
    }
    .ol-table { width: 100%; border-collapse: collapse; font-size: 13px; table-layout: fixed; }
    .ol-table thead th {
      font-family: 'IBM Plex Mono', monospace; font-size: 11px; font-weight: 600;
      letter-spacing: 0.8px; text-transform: uppercase;
      color: var(--header-text); background: var(--header-bg);
      padding: 10px 14px; text-align: left; white-space: nowrap;
      position: relative; cursor: pointer; user-select: none;
      border-right: 1px solid rgba(255,255,255,0.15);
    }
    .ol-table thead th:first-child { cursor: default; }
    .ol-table thead th:last-child { border-right: none; cursor: default; }
    .ol-table thead th:hover { background: #1e3810; }
    .ol-sort-arrow { font-size: 10px; margin-left: 4px; }
    .ol-resize-handle {
      position: absolute; top: 0; right: 0; width: 8px; height: 100%;
      cursor: col-resize; z-index: 5;
    }
    .ol-resize-handle::after {
      content: ''; position: absolute; top: 25%; right: 2px;
      width: 2px; height: 50%; background: rgba(255,255,255,0.3);
      border-radius: 1px; transition: background 0.15s;
    }
    .ol-resize-handle:hover::after { background: rgba(59,130,246,0.9); width: 3px; }
    body.ol-col-resizing, body.ol-col-resizing * {
      cursor: col-resize !important; user-select: none !important; -webkit-user-select: none !important;
    }
    .ol-table tbody tr { border-bottom: 1px solid var(--border); transition: background 0.15s; }
    .ol-table tbody tr:nth-child(even) { background: var(--row-alt); }
    .ol-table tbody tr:hover { background: #eef5e6 !important; }
    .ol-table td {
      padding: 10px 14px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    }
    .ol-td-num {
      text-align: center; color: var(--text-muted);
      font-family: 'IBM Plex Mono', monospace; font-size: 11px;
    }
    .ol-td-actions { display: flex; gap: 6px; white-space: nowrap; overflow: visible; }
    .ol-td-actions a { text-decoration: none; }
    .ol-pagination {
      display: flex; align-items: center; justify-content: space-between;
      padding: 10px 16px; border-top: 1.5px solid var(--border);
      background: #faf6ef; flex-wrap: wrap; gap: 10px; font-size: 12px;
    }
    .ol-page-size { display: flex; align-items: center; gap: 6px; }
    .ol-page-size label {
      font-family: 'IBM Plex Mono', monospace; font-size: 11px;
      text-transform: uppercase; letter-spacing: 0.5px; color: var(--text-muted);
    }
    .ol-page-size select {
      padding: 4px 8px; border: 1.5px solid var(--border); border-radius: 3px;
      font-family: 'IBM Plex Mono', monospace; font-size: 12px; background: white; cursor: pointer;
    }
    .ol-page-size select:focus { outline: none; border-color: var(--accent); }
    .ol-page-info { font-family: 'IBM Plex Mono', monospace; color: var(--text-muted); font-size: 12px; display: flex; gap: 12px; }
    .ol-stat { background: var(--surface); border: 1px solid var(--border); border-radius: 3px; padding: 2px 8px; font-weight: 600; }
    .ol-page-nav { display: flex; align-items: center; gap: 4px; }
    .ol-page-btn {
      width: 30px; height: 30px; display: flex; align-items: center; justify-content: center;
      border: 1.5px solid var(--border); border-radius: 3px; background: white;
      cursor: pointer; font-size: 14px; color: var(--text); transition: all 0.2s;
    }
    .ol-page-btn:hover:not(:disabled) { border-color: var(--accent); color: var(--accent); background: #eef5e6; }
    .ol-page-btn:disabled { opacity: 0.35; cursor: not-allowed; }
    .ol-page-current {
      font-family: 'IBM Plex Mono', monospace; font-size: 11px;
      color: var(--text-muted); margin: 0 6px; white-space: nowrap;
    }
    .ol-empty {
      text-align: center; padding: 60px 20px; color: var(--text-muted); font-size: 15px;
      background: var(--surface); border: 2px solid var(--border-dark); border-radius: 4px;
    }
    .ol-empty a { color: var(--accent); }
    .ol-totals-row td { background: #eef5e6; font-family: 'IBM Plex Mono', monospace; font-size: 13px; padding: 10px 14px; border-top: 2px solid var(--accent); }
    .ol-totals-label { font-size: 12px; letter-spacing: 1px; }
    .ol-totals-sub { display: block; font-size: 10px; font-weight: 400; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; }
    .ol-link-btn {
      background: none; border: none; color: var(--accent);
      cursor: pointer; text-decoration: underline; font-size: 15px;
    }
    .ol-loading {
      display: flex; align-items: center; gap: 10px;
      padding: 20px; justify-content: center; font-size: 15px; color: #6b7280;
    }
    .ol-spinner {
      width: 24px; height: 24px; border: 3px solid #e5e7eb;
      border-top: 3px solid var(--accent, #2563eb); border-radius: 50%;
      animation: olspin 0.8s linear infinite;
    }
    @keyframes olspin { to { transform: rotate(360deg); } }
    @media (max-width: 768px) {
      .ol-toolbar { flex-direction: column; align-items: stretch; }
      .ol-search-box { max-width: 100%; }
      .ol-pagination { justify-content: center; }
    }
  `],
})
export class OrderListComponent implements OnInit, OnDestroy {
  orders: any[] = [];
  loading = false;
  searchText = '';
  cityFilter = '';
  cities: string[] = [];
  sortBy = 'updated_at';
  sortDir = 'DESC';
  page = 1;
  limit = 1000;
  total = 0;
  totalPages = 0;
  totalDesigns = 0;

  private searchSubject = new Subject<string>();
  private resizingTh: HTMLElement | null = null;
  private startX = 0;
  private startW = 0;
  private didResize = false;
  private moveUnsub: (() => void) | null = null;
  private upUnsub: (() => void) | null = null;

  constructor(
    private orderService: OrderService,
    private partyService: PartyService,
    private toast: ToastService,
    private datePipe: DatePipe,
    private renderer: Renderer2,
    private el: ElementRef,
  ) {}

  ngOnInit() {
    this.searchSubject.pipe(
      debounceTime(400),
      distinctUntilChanged(),
    ).subscribe(() => {
      this.page = 1;
      this.loadOrders();
    });
    this.loadOrders();
    this.loadCities();
  }

  ngOnDestroy() {
    this.searchSubject.complete();
    this.stopResize();
  }

  formatDate(val: string): string {
    return this.datePipe.transform(val, 'dd/MM/yyyy') || '';
  }

  formatDateTime(val: string): string {
    return this.datePipe.transform(val, 'dd/MM/yyyy HH:mm') || '';
  }

  startResize(event: MouseEvent) {
    event.preventDefault();
    event.stopPropagation();
    const handle = event.target as HTMLElement;
    const th = handle.closest('th') as HTMLElement;
    if (!th) return;
    this.resizingTh = th;
    this.startX = event.pageX;
    this.startW = th.getBoundingClientRect().width;
    this.didResize = false;
    document.body.classList.add('ol-col-resizing');
    this.moveUnsub = this.renderer.listen('document', 'mousemove', (e: MouseEvent) => {
      if (!this.resizingTh) return;
      const dx = e.pageX - this.startX;
      if (Math.abs(dx) > 3) this.didResize = true;
      const newW = Math.max(40, this.startW + dx);
      this.renderer.setStyle(this.resizingTh, 'width', newW + 'px');
      this.renderer.setStyle(this.resizingTh, 'min-width', newW + 'px');
      this.renderer.setStyle(this.resizingTh, 'max-width', newW + 'px');
    });
    this.upUnsub = this.renderer.listen('document', 'mouseup', () => {
      this.stopResize();
    });
  }

  private stopResize() {
    this.resizingTh = null;
    document.body.classList.remove('ol-col-resizing');
    if (this.moveUnsub) { this.moveUnsub(); this.moveUnsub = null; }
    if (this.upUnsub) { this.upUnsub(); this.upUnsub = null; }
  }

  onThClick(column: string) {
    if (this.didResize) { this.didResize = false; return; }
    this.toggleSort(column);
  }

  loadOrders() {
    this.loading = true;
    this.orderService.getAll({
      page: this.page, limit: this.limit, search: this.searchText,
      sortBy: this.sortBy, sortDir: this.sortDir, city: this.cityFilter,
    }).subscribe({
      next: (res: any) => {
        this.orders = res?.data || [];
        this.total = res?.pagination?.total || 0;
        this.totalPages = res?.pagination?.totalPages || 0;
        this.page = res?.pagination?.page || 1;
        this.totalDesigns = res?.pagination?.totalDesigns || 0;
        this.loading = false;
      },
      error: (err) => {
        this.loading = false;
        this.toast.error('Failed to load orders');
        console.error('Failed to load orders', err);
      },
    });
  }

  onSearchChange(value: string) { this.searchSubject.next(value); }

  clearSearch() { this.searchText = ''; this.page = 1; this.loadOrders(); }

  toggleSort(column: string) {
    if (this.sortBy === column) {
      this.sortDir = this.sortDir === 'ASC' ? 'DESC' : 'ASC';
    } else {
      this.sortBy = column; this.sortDir = 'ASC';
    }
    this.page = 1; this.loadOrders();
  }

  onLimitChange() { this.limit = +this.limit; this.page = 1; this.loadOrders(); }

  goToPage(p: number) {
    if (p < 1 || p > this.totalPages) return;
    this.page = p; this.loadOrders();
  }

  deleteOrder(order: Order) {
    if (!confirm('Delete order for "' + order.party_name + '"?')) return;
    this.orderService.delete(order.id!).subscribe({
      next: () => { this.toast.success('Order deleted successfully'); this.loadOrders(); },
      error: (err) => { this.toast.error('Failed to delete order'); console.error('Failed to delete', err); },
    });
  }

  loadCities() {
    this.partyService.getCities().subscribe(cities => this.cities = cities);
  }

  onCityFilterChange() {
    this.page = 1;
    this.loadOrders();
  }

  get totalItemsSum(): number {
    return this.orders.reduce((s, o) => s + (parseInt(o.item_count) || 0), 0);
  }
  get totalRemainingSum(): number {
    return this.orders.reduce((s, o) => s + (parseInt(o.remaining) || 0), 0);
  }
  get totalCompletedSum(): number {
    return this.orders.reduce((s, o) => s + (parseInt(o.ok_count) || 0), 0);
  }
}
