import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SizeService, Size } from '../../services/size.service';
import { ToastService } from '../../services/toast.service';

@Component({
  selector: 'app-size-master',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="master-header">
      <div class="master-title">📐 Size Master</div>
    </div>

    <div class="master-toolbar">
      <input type="text" [(ngModel)]="searchText" (input)="loadSizes()"
             placeholder="Search sizes..." class="master-search-input">
      <button class="btn btn-primary btn-sm" (click)="showForm = true; editSize = { size_label: '' }">+ Add Size</button>
    </div>

    <!-- Form Modal -->
    <div class="modal-overlay" *ngIf="showForm" (click)="showForm = false">
      <div class="modal-box" (click)="$event.stopPropagation()">
        <div class="modal-head">
          <h3>{{ editSize.id ? 'Edit' : 'New' }} Size</h3>
          <span class="modal-close" (click)="showForm = false">×</span>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>Size Label *</label>
            <input type="text" [(ngModel)]="editSize.size_label" placeholder="e.g. S, M, L, 6, 18, 24" class="form-input">
          </div>
        </div>
        <div class="modal-foot">
          <button class="btn btn-secondary btn-sm" (click)="showForm = false">Cancel</button>
          <button class="btn btn-primary btn-sm" (click)="saveSize()" [disabled]="!editSize.size_label?.trim()">
            {{ editSize.id ? 'Update' : 'Save' }}
          </button>
        </div>
      </div>
    </div>

    <!-- Pagination -->
    <div class="master-pagination">
      <select [(ngModel)]="limit" (change)="loadSizes()" class="page-select">
        <option [value]="10">10</option><option [value]="20">20</option><option [value]="50">50</option>
        <option [value]="100">100</option><option [value]="1000">1000</option>
      </select>
      <span class="page-info">Page {{ page }} of {{ totalPages }} ({{ total }} records)</span>
      <button class="btn btn-sm btn-secondary" [disabled]="page <= 1" (click)="page = page - 1; loadSizes()">‹</button>
      <button class="btn btn-sm btn-secondary" [disabled]="page >= totalPages" (click)="page = page + 1; loadSizes()">›</button>
    </div>

    <div class="master-table-wrap">
      <table class="master-table">
        <thead>
          <tr>
            <th style="width:50px">#</th>
            <th (click)="toggleSort('size_label')">Size Label <span *ngIf="sortBy==='size_label'">{{sortDir==='ASC'?'▲':'▼'}}</span></th>
            <th style="width:150px">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let size of sizes; let i = index">
            <td>{{ (page-1)*limit + i + 1 }}</td>
            <td><strong>{{ size.size_label }}</strong></td>
            <td>
              <button class="btn btn-secondary btn-sm" (click)="onEdit(size)">Edit</button>
              <button class="btn btn-danger btn-sm" (click)="onDelete(size)">Delete</button>
            </td>
          </tr>
          <tr *ngIf="!sizes.length"><td colspan="3" class="empty-row">No sizes found</td></tr>
        </tbody>
      </table>
    </div>
  `,
  styles: [`
    .master-header { background: var(--surface); border: 2px solid var(--border-dark); border-radius: 4px; padding: 16px 20px; margin-bottom: 12px; }
    .master-title { font-family: 'IBM Plex Mono', monospace; font-size: 18px; font-weight: 600; color: var(--accent); letter-spacing: 2px; text-transform: uppercase; }
    .master-toolbar { display: flex; gap: 12px; align-items: center; margin-bottom: 12px; flex-wrap: wrap; }
    .master-search-input { border: 1.5px solid var(--border); border-radius: 3px; padding: 7px 12px; font-size: 13px; width: 280px; background: var(--surface); }
    .master-search-input:focus { outline: none; border-color: var(--accent); }
    .master-pagination { display: flex; gap: 10px; align-items: center; margin-bottom: 10px; flex-wrap: wrap; }
    .page-select { border: 1.5px solid var(--border); border-radius: 3px; padding: 4px 8px; font-size: 12px; }
    .page-info { font-size: 12px; color: var(--text-muted); }
    .master-table-wrap { background: var(--surface); border: 2px solid var(--border-dark); border-radius: 4px; overflow-x: auto; }
    .master-table { width: 100%; border-collapse: collapse; font-size: 13px; }
    .master-table thead th { background: var(--header-bg); color: var(--header-text); padding: 10px 12px; font-family: 'IBM Plex Mono', monospace; font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; cursor: pointer; white-space: nowrap; }
    .master-table tbody td { padding: 8px 12px; border-bottom: 1px solid var(--border); }
    .master-table tbody tr:nth-child(even) { background: var(--row-alt); }
    .master-table tbody tr:hover { background: #eef5e6; }
    .empty-row { text-align: center; color: var(--text-muted); padding: 24px !important; }
    .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center; padding: 20px; }
    .modal-box { background: white; border-radius: 6px; width: 100%; max-width: 400px; box-shadow: 0 8px 40px rgba(0,0,0,0.3); }
    .modal-head { display: flex; justify-content: space-between; align-items: center; padding: 14px 20px; border-bottom: 2px solid var(--border); }
    .modal-head h3 { font-family: 'IBM Plex Mono', monospace; font-size: 15px; color: var(--accent); }
    .modal-close { font-size: 22px; cursor: pointer; color: #888; }
    .modal-body { padding: 16px 20px; }
    .form-group { margin-bottom: 12px; }
    .form-group label { display: block; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; color: var(--text-muted); margin-bottom: 4px; }
    .form-input { width: 100%; border: 1.5px solid var(--border); border-radius: 3px; padding: 8px 10px; font-size: 13px; }
    .form-input:focus { outline: none; border-color: var(--accent); }
    .modal-foot { display: flex; gap: 8px; justify-content: flex-end; padding: 12px 20px; border-top: 2px solid var(--border); }
    @media (max-width: 768px) { .master-search-input { width: 100%; } .master-toolbar { flex-direction: column; align-items: stretch; } }
  `]
})
export class SizeMasterComponent implements OnInit {
  sizes: Size[] = [];
  searchText = '';
  page = 1;
  limit = 1000;
  total = 0;
  totalPages = 1;
  sortBy = 'size_label';
  sortDir = 'ASC';
  showForm = false;
  editSize: Partial<Size> = { size_label: '' };

  constructor(private sizeService: SizeService, private toast: ToastService) {}

  ngOnInit() { this.loadSizes(); }

  loadSizes() {
    this.sizeService.getAll({ page: this.page, limit: this.limit, search: this.searchText, sortBy: this.sortBy, sortDir: this.sortDir })
      .subscribe(res => { this.sizes = res.data; this.total = res.pagination.total; this.totalPages = res.pagination.totalPages; });
  }

  toggleSort(col: string) {
    if (this.sortBy === col) this.sortDir = this.sortDir === 'ASC' ? 'DESC' : 'ASC';
    else { this.sortBy = col; this.sortDir = 'ASC'; }
    this.loadSizes();
  }

  onEdit(size: Size) { this.editSize = { ...size }; this.showForm = true; }

  saveSize() {
    if (!this.editSize.size_label?.trim()) return;
    const obs = this.editSize.id
      ? this.sizeService.update(this.editSize.id, this.editSize)
      : this.sizeService.create(this.editSize);
    obs.subscribe({
      next: () => { this.toast.show(this.editSize.id ? 'Size updated' : 'Size created', 'success'); this.showForm = false; this.loadSizes(); },
      error: (err) => { this.toast.show(err.error?.error || 'Error saving size', 'error'); }
    });
  }

  onDelete(size: Size) {
    if (!confirm(`Delete size "${size.size_label}"?`)) return;
    this.sizeService.delete(size.id!).subscribe({
      next: () => { this.toast.show('Size deleted', 'success'); this.loadSizes(); },
      error: (err) => { this.toast.show(err.error?.error || 'Cannot delete size', 'error'); }
    });
  }
}
