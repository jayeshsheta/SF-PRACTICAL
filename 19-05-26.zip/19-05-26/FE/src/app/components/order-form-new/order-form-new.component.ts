import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink, ActivatedRoute, Router } from '@angular/router';
import { OrderService } from '../../services/order.service';
import { PartyService } from '../../services/party.service';
import { DesignService } from '../../services/design.service';
import { ItemService } from '../../services/item.service';
import { SizeService } from '../../services/size.service';
import { CategoryService } from '../../services/category.service';
import { ToastService } from '../../services/toast.service';
import { Order, OrderDesign, Party, Design, Item, DesignFile } from '../../models/order.model';
import { environment } from '../../../environments/environment';
import { Subject, debounceTime } from 'rxjs';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-order-form',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="header-card">
      <div class="header-title">🧵 {{ isEdit ? 'Edit' : 'New' }} Order</div>
      <div class="meta-grid">
        <div class="meta-field">
          <label>Party — પાર્ટી</label>
          <div class="party-search-wrap">
            <input type="text" [(ngModel)]="partySearchText" (input)="onPartySearch()"
                   (focus)="showPartyDropdown = true" (keydown)="onPartyKeydown($event)"
                   placeholder="Search party..."
                   [class.invalid]="submitted && !order.party_id" class="form-input">
            <div class="dropdown-list" *ngIf="showPartyDropdown && filteredParties.length">
              <div class="dropdown-item" *ngFor="let p of filteredParties; let pi = index"
                   [class.active]="pi === activePartyIndex" (mousedown)="selectParty(p)">
                <strong>{{ p.name }}</strong>
                <span *ngIf="p.contact" class="dd-sub">{{ p.contact }}</span>
              </div>
            </div>
          </div>
          <span class="selected-tag" *ngIf="selectedParty">✓ {{ selectedParty.name }}</span>
          <span class="error" *ngIf="submitted && !order.party_id">Required</span>
        </div>
        <div class="meta-field">
          <label>Date — તારીખ</label>
          <input type="date" [(ngModel)]="order.order_date" class="form-input"
                 [class.invalid]="submitted && !order.order_date">
          <span class="error" *ngIf="submitted && !order.order_date">Required</span>
        </div>
      </div>
    </div>

    <!-- Add Design search -->
    <div class="design-add-section">
      <div class="design-search-wrap">
        <input type="text" [(ngModel)]="designSearchText" (input)="onDesignSearch()"
               (focus)="showDesignDropdown = true" (keydown)="onDesignKeydown($event)"
               placeholder="🔍 Search design by D.No, item, color..."
               class="design-search-input">
        <div class="dropdown-list dropdown-wide" *ngIf="showDesignDropdown && filteredDesigns.length">
          <div class="dropdown-item design-dd-item" *ngFor="let d of filteredDesigns; let di = index"
               [class.active]="di === activeDesignIndex" (mousedown)="addDesignToOrder(d)">
            <strong>{{ d.design_number }}</strong>
            <span class="dd-sub">{{ d.item_name }}</span>
            <span class="dd-sub" *ngIf="d.color">{{ d.color }}</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Loading -->
    <div class="loading-overlay" *ngIf="loading || saving">
      <div class="spinner"></div>
      <div class="loading-text">{{ saving ? 'Saving...' : 'Loading...' }}</div>
    </div>

    <!-- Order Designs Table -->
    <div class="table-wrap" *ngIf="order.designs.length">
      <div class="table-filter-bar">
        <input type="text" [(ngModel)]="designFilterText" placeholder="🔍 Filter by D.No..."
               class="design-filter-input">
        <span class="filter-count" *ngIf="designFilterText">{{ filteredOrderDesigns.length }} / {{ order.designs.length }}</span>
      </div>
      <table>
        <thead>
          <tr>
            <th style="width:40px">#</th>
            <th>Item</th>
            <th>D.No</th>
            <th>Sudharo</th>
            <th>Stitch</th>
            <th>Rate</th>
            <th>Fabric</th>
            <th>Collar</th>
            <th>Back</th>
            <th>Front</th>
            <th>Sleeve</th>
            <th>Kohinoor</th>
            <th>Lachka</th>
            <th>Net</th>
            <th>Velvet</th>
            <th>Less</th>
            <th>Kapda</th>
            <th>Color</th>
            <th>F.Rate</th>
            <th>Sizes</th>
            <th>Categories</th>
            <th>Files</th>
            <th>OK</th>
            <th style="width:40px"></th>
          </tr>
        </thead>
        <tbody>
          <ng-container *ngFor="let od of filteredOrderDesigns; let i = index">
            <tr>
              <td class="td-num">{{ i + 1 }}</td>
              <td><input *ngIf="od.is_custom" type="text" [(ngModel)]="od.custom_values!.item_name" class="inline-input" placeholder="Item"><span *ngIf="!od.is_custom">{{ od.item_name }}</span></td>
              <td><strong>{{ od.design_number }}</strong></td>
              <td><input *ngIf="od.is_custom" type="text" [(ngModel)]="od.custom_values!.sudharo" class="inline-input"><span *ngIf="!od.is_custom">{{ od.sudharo || '—' }}</span></td>
              <td><input *ngIf="od.is_custom" type="text" [(ngModel)]="od.custom_values!.stitch" class="inline-input"><span *ngIf="!od.is_custom">{{ od.stitch || '—' }}</span></td>
              <td><input *ngIf="od.is_custom" type="text" [(ngModel)]="od.custom_values!.rate_bhav" class="inline-input"><span *ngIf="!od.is_custom">{{ od.rate_bhav || '—' }}</span></td>
              <td><input *ngIf="od.is_custom" type="text" [(ngModel)]="od.custom_values!.kapda" class="inline-input"><span *ngIf="!od.is_custom">{{ od.kapda || '—' }}</span></td>
              <td class="td-bool"><input *ngIf="od.is_custom" type="checkbox" [(ngModel)]="od.custom_values!.collar"><span *ngIf="!od.is_custom">{{ od.collar ? '✓' : '' }}</span></td>
              <td class="td-bool"><input *ngIf="od.is_custom" type="checkbox" [(ngModel)]="od.custom_values!.back_fabric"><span *ngIf="!od.is_custom">{{ od.back_fabric ? '✓' : '' }}</span></td>
              <td class="td-bool"><input *ngIf="od.is_custom" type="checkbox" [(ngModel)]="od.custom_values!.front"><span *ngIf="!od.is_custom">{{ od.front ? '✓' : '' }}</span></td>
              <td class="td-bool"><input *ngIf="od.is_custom" type="checkbox" [(ngModel)]="od.custom_values!.sleeve"><span *ngIf="!od.is_custom">{{ od.sleeve ? '✓' : '' }}</span></td>
              <td class="td-bool"><input *ngIf="od.is_custom" type="checkbox" [(ngModel)]="od.custom_values!.kohinoor"><span *ngIf="!od.is_custom">{{ od.kohinoor ? '✓' : '' }}</span></td>
              <td class="td-bool"><input *ngIf="od.is_custom" type="checkbox" [(ngModel)]="od.custom_values!.lachka"><span *ngIf="!od.is_custom">{{ od.lachka ? '✓' : '' }}</span></td>
              <td class="td-bool"><input *ngIf="od.is_custom" type="checkbox" [(ngModel)]="od.custom_values!.net"><span *ngIf="!od.is_custom">{{ od.net ? '✓' : '' }}</span></td>
              <td class="td-bool"><input *ngIf="od.is_custom" type="checkbox" [(ngModel)]="od.custom_values!.velvet"><span *ngIf="!od.is_custom">{{ od.velvet ? '✓' : '' }}</span></td>
              <td class="td-bool"><input *ngIf="od.is_custom" type="checkbox" [(ngModel)]="od.custom_values!.less"><span *ngIf="!od.is_custom">{{ od.less ? '✓' : '' }}</span></td>
              <td>{{ od.kapda || '—' }}</td>
              <td>{{ od.color || '—' }}</td>
              <td><input *ngIf="od.is_custom" type="text" [(ngModel)]="od.custom_values!.fabric_rate" class="inline-input"><span *ngIf="!od.is_custom">{{ od.fabric_rate || '—' }}</span></td>
              <td class="td-sizes">
                <button class="btn-size-toggle" (click)="toggleSizes(i)">
                  📐 {{ getSizeSummary(od) }}
                </button>
              </td>
              <td class="td-sizes">
                <button class="btn-size-toggle" (click)="toggleCategories(i)">
                  🏷️ {{ getCategorySummary(od) }}
                </button>
              </td>
              <td class="td-files">
                <div class="file-thumbs" *ngIf="od.files?.length">
                  <ng-container *ngFor="let f of od.files">
                    <img *ngIf="isImage(f.file_path)" [src]="getFileUrl(f.file_path)" class="mini-thumb"
                         (click)="openImage(f)" (mouseenter)="showTooltip($event, f)" (mouseleave)="hideTooltip()"
                         [title]="f.original_name">
                    <span *ngIf="!isImage(f.file_path)" class="pdf-badge" (click)="openPdf(f)" [title]="f.original_name">📄</span>
                  </ng-container>
                </div>
                <span *ngIf="!od.files?.length">—</span>
              </td>
              <td><input type="checkbox" [(ngModel)]="od.ok_status"></td>
              <td>
                <button class="btn-icon-custom" [class.active]="od.is_custom" (click)="toggleCustom(od)" title="Custom values">🔄</button>
                <button class="btn-icon-remove" (click)="removeDesign(i)">✕</button>
              </td>
            </tr>
            <!-- Size expansion row -->
            <tr *ngIf="expandedSizeIndex === i" class="size-row">
              <td colspan="24" class="size-cell">
                <div class="size-editor">
                  <span class="size-label-tag">📐 Sizes:</span>
                  <div class="size-entries">
                    <div class="size-entry" *ngFor="let s of od.sizes; let si = index">
                      <select [(ngModel)]="s.size_label" class="size-input">
                        <option value="" disabled>Select size</option>
                        <option *ngFor="let sz of allSizes" [value]="sz">{{ sz }}</option>
                      </select>
                      <input type="number" [(ngModel)]="s.quantity" placeholder="Qty" class="size-qty-input" min="0">
                      <button class="btn-size-remove" (click)="removeSizeEntry(od, si)">✕</button>
                    </div>
                  </div>
                  <button class="btn btn-sm btn-secondary" (click)="addSizeEntry(od)">+ Add Size</button>
                </div>
              </td>
            </tr>
            <!-- Category expansion row -->
            <tr *ngIf="expandedCategoryIndex === i" class="size-row">
              <td colspan="24" class="size-cell">
                <div class="size-editor">
                  <span class="size-label-tag">🏷️ Categories:</span>
                  <div class="size-entries">
                    <div class="size-entry" *ngFor="let c of od.categories; let ci = index">
                      <select [(ngModel)]="c.category_name" class="size-input">
                        <option value="" disabled>Select category</option>
                        <option *ngFor="let cat of allCategories" [value]="cat">{{ cat }}</option>
                      </select>
                      <input type="number" [(ngModel)]="c.quantity" placeholder="Qty" class="size-qty-input" min="0">
                      <button class="btn-size-remove" (click)="removeCategoryEntry(od, ci)">✕</button>
                    </div>
                  </div>
                  <button class="btn btn-sm btn-secondary" (click)="addCategoryEntry(od)">+ Add Category</button>
                </div>
              </td>
            </tr>
            <!-- Custom files row -->
            <tr *ngIf="od.is_custom" class="size-row">
              <td colspan="24" class="size-cell">
                <div class="custom-files-section">
                  <span class="size-label-tag">📎 Custom Files (max 3):</span>
                  <div class="custom-file-list">
                    <div class="custom-file-item" *ngFor="let cf of od.custom_values?.custom_files || []; let fi = index">
                      <img *ngIf="isImage(cf.name || cf.file_path || '')" [src]="cf.preview || getFileUrl(cf.file_path)" class="mini-thumb">
                      <span *ngIf="!isImage(cf.name || cf.file_path || '')" class="pdf-badge">📄</span>
                      <span class="cf-name">{{ cf.name || cf.original_name || 'File ' + (fi+1) }}</span>
                      <button class="btn-size-remove" (click)="removeCustomFile(od, fi)">✕</button>
                    </div>
                  </div>
                  <input type="file" *ngIf="(od.custom_values?.custom_files || []).length < 3"
                         (change)="onCustomFileSelect($event, od)" accept="image/*,.pdf"
                         class="custom-file-input">
                </div>
              </td>
            </tr>
          </ng-container>
        </tbody>
      </table>
    </div>

    <div class="empty-state" *ngIf="!order.designs.length && !loading">
      <p>No designs added yet. Use the search above to add designs to this order.</p>
    </div>

    <!-- Toolbar -->
    <div class="toolbar">
      <p class="summary-left">{{ okCount }} completed out of {{ order.designs.length }} designs</p>
      <a routerLink="/orders" class="btn btn-secondary">← Back</a>
      <button class="btn btn-primary" (click)="save()" [disabled]="saving">
        {{ saving ? 'Saving...' : (isEdit ? '💾 Update' : '💾 Save') }}
      </button>
    </div>

    <!-- Image popup -->
    <div class="img-popup-overlay" *ngIf="popupSrc" (click)="popupSrc = null">
      <img [src]="popupSrc" (click)="$event.stopPropagation()">
    </div>

    <!-- PDF popup -->
    <div class="pdf-popup-overlay" *ngIf="pdfSrc" (click)="pdfSrc = null">
      <div class="pdf-popup" (click)="$event.stopPropagation()">
        <button class="pdf-popup-close" (click)="pdfSrc = null">✕</button>
        <iframe [src]="pdfSrc" width="100%" height="100%"></iframe>
      </div>
    </div>

    <!-- Image hover tooltip -->
    <div class="img-tooltip" [class.visible]="tooltipVisible"
         [style.left.px]="tooltipX" [style.top.px]="tooltipY">
      <img [src]="tooltipSrc" alt="">
    </div>
  `,
  styleUrls: ['./order-form-new.component.scss']
})
export class OrderFormComponent implements OnInit {
  order: Order = { party_id: 0, order_date: new Date().toISOString().split('T')[0], designs: [] };
  isEdit = false;
  orderId: number | null = null;
  submitted = false;
  saving = false;
  loading = false;
  expandedSizeIndex: number | null = null;
  expandedCategoryIndex: number | null = null;

  // Party
  allParties: Party[] = [];
  filteredParties: Party[] = [];
  partySearchText = '';
  showPartyDropdown = false;
  selectedParty: Party | null = null;
  activePartyIndex = -1;

  // Design
  allDesigns: Design[] = [];
  filteredDesigns: Design[] = [];
  designSearchText = '';
  showDesignDropdown = false;
  designSearch$ = new Subject<string>();
  activeDesignIndex = -1;

  popupSrc: string | null = null;
  pdfSrc: any = null;

  // Tooltip
  tooltipVisible = false;
  tooltipSrc = '';
  tooltipX = 0;
  tooltipY = 0;

  // Size master
  allSizes: string[] = [];

  // Category master
  allCategories: string[] = [];

  // D.No filter
  designFilterText = '';

  // Items list for custom item selection
  allItems: string[] = [];

  constructor(
    private orderService: OrderService,
    private partyService: PartyService,
    private designService: DesignService,
    private sizeService: SizeService,
    private categoryService: CategoryService,
    private toast: ToastService,
    private route: ActivatedRoute,
    private router: Router,
    private sanitizer: DomSanitizer
  ) {}

  ngOnInit() {
    this.loadParties();
    this.loadDesigns();
    this.loadSizes();
    this.loadCategories();

    this.designSearch$.pipe(debounceTime(300)).subscribe(text => {
      this.filteredDesigns = this.allDesigns.filter(d =>
        d.design_number.toLowerCase().includes(text.toLowerCase()) ||
        (d.item_name || '').toLowerCase().includes(text.toLowerCase()) ||
        (d.color || '').toLowerCase().includes(text.toLowerCase()) ||
        (d.kapda || '').toLowerCase().includes(text.toLowerCase())
      ).slice(0, 20);
    });

    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEdit = true;
      this.orderId = +id;
      this.loading = true;
      this.orderService.getById(this.orderId).subscribe(order => {
        this.order = order;
        this.partySearchText = order.party_name || '';
        this.selectedParty = { name: order.party_name || '', address: order.party_address || '', contact: order.party_contact || '', id: order.party_id } as Party;
        this.loading = false;
      });
    }
  }

  loadParties() {
    this.partyService.getAll({ limit: 1000 }).subscribe(res => {
      this.allParties = res.data;
      this.filteredParties = res.data;
    });
  }

  loadDesigns() {
    this.designService.getAll({ limit: 1000 }).subscribe(res => {
      this.allDesigns = res.data;
    });
  }

  loadSizes() {
    this.sizeService.getAll({ limit: 1000 }).subscribe(res => {
      this.allSizes = res.data.map(s => s.size_label);
    });
  }

  loadCategories() {
    this.categoryService.getAll({ limit: 1000 }).subscribe(res => {
      this.allCategories = res.data.map(c => c.category_name);
    });
  }

  onPartySearch() {
    const t = this.partySearchText.toLowerCase();
    this.filteredParties = this.allParties.filter(p =>
      p.name.toLowerCase().includes(t) || (p.contact || '').toLowerCase().includes(t)
    ).slice(0, 15);
    this.showPartyDropdown = true;
    this.activePartyIndex = -1;
  }

  selectParty(p: Party) {
    this.selectedParty = p;
    this.order.party_id = p.id!;
    this.partySearchText = p.name;
    this.showPartyDropdown = false;
  }

  onDesignSearch() {
    this.showDesignDropdown = true;
    this.activeDesignIndex = -1;
    this.designSearch$.next(this.designSearchText);
  }

  onPartyKeydown(event: KeyboardEvent) {
    if (!this.showPartyDropdown || !this.filteredParties.length) return;
    if (event.key === 'ArrowDown') { event.preventDefault(); this.activePartyIndex = Math.min(this.activePartyIndex + 1, this.filteredParties.length - 1); }
    else if (event.key === 'ArrowUp') { event.preventDefault(); this.activePartyIndex = Math.max(this.activePartyIndex - 1, 0); }
    else if (event.key === 'Enter' && this.activePartyIndex >= 0) { event.preventDefault(); this.selectParty(this.filteredParties[this.activePartyIndex]); }
    else if (event.key === 'Escape') { this.showPartyDropdown = false; }
  }

  onDesignKeydown(event: KeyboardEvent) {
    if (!this.showDesignDropdown || !this.filteredDesigns.length) return;
    if (event.key === 'ArrowDown') { event.preventDefault(); this.activeDesignIndex = Math.min(this.activeDesignIndex + 1, this.filteredDesigns.length - 1); }
    else if (event.key === 'ArrowUp') { event.preventDefault(); this.activeDesignIndex = Math.max(this.activeDesignIndex - 1, 0); }
    else if (event.key === 'Enter' && this.activeDesignIndex >= 0) { event.preventDefault(); this.addDesignToOrder(this.filteredDesigns[this.activeDesignIndex]); }
    else if (event.key === 'Escape') { this.showDesignDropdown = false; }
  }

  addDesignToOrder(d: Design) {
    // Duplicate check
    const existing = this.order.designs.filter(x => x.design_id === d.id);
    if (existing.length > 0) {
      if (!confirm(`Design "${d.design_number}" is already added (${existing.length}x). Add again?`)) {
        this.designSearchText = '';
        this.showDesignDropdown = false;
        return;
      }
    }
    const od: OrderDesign = {
      design_id: d.id!,
      row_num: this.order.designs.length + 1,
      ok_status: false,
      design_number: d.design_number,
      item_name: d.item_name,
      sudharo: d.sudharo,
      stitch: d.stitch,
      rate_bhav: d.rate_bhav,
      sleeve: d.sleeve,
      collar: d.collar,
      back_fabric: d.back_fabric,
      front: d.front,
      kohinoor: d.kohinoor,
      lachka: d.lachka,
      net: d.net,
      velvet: d.velvet,
      less: d.less,
      fabric_rate: d.fabric_rate,
      kapda: d.kapda,
      piece: d.piece,
      color: d.color,
      remark: d.remark,
      files: d.files || [],
      sizes: [],
      categories: [],
    };
    this.order.designs.push(od);
    this.designSearchText = '';
    this.showDesignDropdown = false;
  }

  toggleCustom(od: any) {
    od.is_custom = !od.is_custom;
    if (od.is_custom) {
      // Reset all values (blank) except design_number; user fills custom values
      od.custom_values = {
        item_name: od.item_name || '', sudharo: '', stitch: '', rate_bhav: '',
        kapda: '', fabric_rate: '', piece: '',
        collar: false, back_fabric: false, front: false,
        sleeve: false, kohinoor: false, lachka: false,
        net: false, velvet: false, less: false, remark: '',
        custom_files: od.custom_values?.custom_files || []
      };
    }
  }

  removeDesign(i: number) {
    this.order.designs.splice(i, 1);
    this.order.designs.forEach((d, idx) => d.row_num = idx + 1);
    if (this.expandedSizeIndex === i) this.expandedSizeIndex = null;
  }

  toggleSizes(i: number) {
    this.expandedSizeIndex = this.expandedSizeIndex === i ? null : i;
  }

  addSizeEntry(od: any) {
    if (!od.sizes) od.sizes = [];
    od.sizes.push({ size_label: '', quantity: 0 });
  }

  removeSizeEntry(od: any, si: number) {
    od.sizes.splice(si, 1);
  }

  getSizeSummary(od: any): string {
    if (!od.sizes || od.sizes.length === 0) return '0 pcs';
    const total = od.sizes.reduce((sum: number, s: any) => sum + (s.quantity || 0), 0);
    return `${od.sizes.length} sizes / ${total} pcs`;
  }

  toggleCategories(i: number) {
    this.expandedCategoryIndex = this.expandedCategoryIndex === i ? null : i;
  }

  addCategoryEntry(od: any) {
    if (!od.categories) od.categories = [];
    od.categories.push({ category_name: '', quantity: 0 });
  }

  removeCategoryEntry(od: any, ci: number) {
    od.categories.splice(ci, 1);
  }

  getCategorySummary(od: any): string {
    if (!od.categories || od.categories.length === 0) return '0 pcs';
    const total = od.categories.reduce((sum: number, c: any) => sum + (c.quantity || 0), 0);
    return `${od.categories.length} cat / ${total} pcs`;
  }

  get okCount(): number {
    return this.order.designs.filter(d => d.ok_status).length;
  }

  get filteredOrderDesigns(): any[] {
    if (!this.designFilterText) return this.order.designs;
    const f = this.designFilterText.toLowerCase();
    return this.order.designs.filter(d =>
      (d.design_number || '').toLowerCase().includes(f) ||
      (d.item_name || '').toLowerCase().includes(f)
    );
  }

  getFileUrl(filePath: string): string {
    const clean = filePath.replace(/^\/uploads\//, '');
    return `${environment.apiUrl}/uploads/${clean}`;
  }

  isImage(filePath: string): boolean {
    return /\.(jpg|jpeg|png|gif|webp|bmp)$/i.test(filePath);
  }

  openImage(f: DesignFile) {
    this.popupSrc = this.getFileUrl(f.file_path);
  }

  openPdf(f: DesignFile) {
    this.pdfSrc = this.sanitizer.bypassSecurityTrustResourceUrl(this.getFileUrl(f.file_path));
  }

  showTooltip(event: MouseEvent, f: DesignFile) {
    this.tooltipSrc = this.getFileUrl(f.file_path);
    this.tooltipX = event.clientX + 12;
    this.tooltipY = event.clientY + 12;
    this.tooltipVisible = true;
  }

  hideTooltip() {
    this.tooltipVisible = false;
  }

  onCustomFileSelect(event: any, od: any) {
    const file = event.target.files[0];
    if (!file) return;
    if (!od.custom_values.custom_files) od.custom_values.custom_files = [];
    if (od.custom_values.custom_files.length >= 3) return;
    const reader = new FileReader();
    reader.onload = () => {
      od.custom_values.custom_files.push({ name: file.name, file, preview: reader.result as string });
    };
    if (file.type.startsWith('image/')) reader.readAsDataURL(file);
    else od.custom_values.custom_files.push({ name: file.name, file, preview: null });
    event.target.value = '';
  }

  removeCustomFile(od: any, fi: number) {
    if (!confirm('Delete this custom file?')) return;
    od.custom_values.custom_files.splice(fi, 1);
  }

  save() {
    this.submitted = true;
    if (!this.order.party_id || !this.order.order_date) {
      this.toast.show('Please fill required fields', 'error');
      return;
    }
    this.saving = true;
    const payload = {
      party_id: this.order.party_id,
      order_date: this.order.order_date,
      designs: this.order.designs.map(d => ({
        design_id: d.design_id,
        row_num: d.row_num,
        ok_status: d.ok_status,
        is_custom: d.is_custom || false,
        custom_values: d.is_custom ? d.custom_values : null,
        sizes: (d.sizes || []).filter(s => s.size_label && s.quantity > 0),
        categories: (d.categories || []).filter(c => c.category_name && c.quantity > 0)
      }))
    };

    const obs = this.isEdit
      ? this.orderService.update(this.orderId!, payload)
      : this.orderService.create(payload);

    obs.subscribe({
      next: () => {
        this.toast.show(this.isEdit ? 'Order updated' : 'Order created', 'success');
        this.saving = false;
        this.router.navigate(['/orders']);
      },
      error: (err) => {
        this.toast.show(err.error?.error || 'Error saving', 'error');
        this.saving = false;
      }
    });
  }
}
