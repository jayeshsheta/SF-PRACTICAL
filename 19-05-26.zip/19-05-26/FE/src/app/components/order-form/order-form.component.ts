import { Component, OnInit, ViewChild, ElementRef, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { OrderService } from '../../services/order.service';
import { ToastService } from '../../services/toast.service';
import { Order, OrderItem } from '../../models/order.model';
import { ImagePopupComponent } from '../image-popup/image-popup.component';
import { ImportPreviewComponent } from '../import-preview/import-preview.component';
import { environment } from '../../../environments/environment';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-order-form',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, ImagePopupComponent, ImportPreviewComponent],
  templateUrl: './order-form.component.html',
  styleUrls: ['./order-form.component.scss'],
})
export class OrderFormComponent implements OnInit {
  order: Order = {
    party_name: '',
    order_date: new Date().toISOString().split('T')[0],
    items: [],
  };
  isEdit = false;
  orderId: number | null = null;
  submitted = false;
  saving = false;
  loading = false;
  private savedOnce = false;

  // Image popup
  popupImageSrc: string | null = null;
  popupPdfSrc: SafeResourceUrl | null = null;
  // Import preview
  showImportPreview = false;
  importPreviewData: any[] = [];

  // Local image previews: key = `rowIdx-slot`
  localImagePreviews: { [key: string]: string } = {};
  localImageFiles: { [key: string]: File } = {};
  localPdfNames: { [key: string]: string } = {};

  // Tooltip
  tooltipVisible = false;
  tooltipSrc = '';
  tooltipX = 0;
  tooltipY = 0;

  // Text tooltip for remark/sudharo
  textTooltipVisible = false;
  textTooltipContent = '';
  textTooltipX = 0;
  textTooltipY = 0;

  // Column search/filter
  filterColumn = '';
  filterValue = '';
  filterColumns = [
    { key: 'item_name', label: 'Item Name' },
    { key: 'design_number', label: 'D.No' },
    { key: 'sudharo', label: 'Sudharo' },
    { key: 'stitch', label: 'Stitch' },
    { key: 'rate_bhav', label: 'Rate/Bhav' },
    { key: 'fabric_rate', label: 'Fabric Rate' },
    { key: 'kapda', label: 'Kapda' },
    { key: 'remark', label: 'Remark' },
    { key: 'ok_status', label: 'OK Status' },
    { key: 'sleeve', label: 'Sleeve' },
    { key: 'collar', label: 'Collar' },
    { key: 'back_fabric', label: 'Back' },
    { key: 'front', label: 'Front' },
    { key: 'kohinoor', label: 'Kohinoor' },
    { key: 'lachka', label: 'Lachka' },
    { key: 'net', label: 'Net' },
    { key: 'Men', label: 'Men' },
    { key: 'Kids', label: 'Kids' },
    { key: 'Velvet', label: 'Velvet' },

  ];
  isBooleanFilter = false;
  filterBoolValue = false;

  // Navigation columns (for keyboard nav)
  navColumns = [
    'item_name', 'design_number', 'sudharo', 'stitch', 'rate_bhav',
    'sleeve', 'collar', 'back_fabric', 'front', 'kohinoor', 'lachka', 'net', 'velvet',
    'kapda', 'piece', 'fabric_rate', 'ok_status', 'remark', 'isForMen', 'isForKids'
  ];


  // NEW: track IDs of images removed by user (delete on final save)
  deletedImageIds: number[] = [];

  @ViewChild('fileImportInput') fileImportInput!: ElementRef<HTMLInputElement>;

  constructor(
    private orderService: OrderService,
    private route: ActivatedRoute,
    private router: Router,
    private toast: ToastService,
    private sanitizer: DomSanitizer
  ) { }

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEdit = true;
      this.orderId = +id;
      this.loading = true;
      this.orderService.getById(this.orderId).subscribe({
        next: (data) => {
          this.order = data;
          if (this.order.order_date) {
            this.order.order_date = new Date(this.order.order_date).toISOString().split('T')[0];
          }
          if (!this.order.items?.length) this.addRows(10);
          this.loading = false;
        },
        error: () => {
          this.toast.error('Failed to load order');
          this.loading = false;
          this.router.navigate(['/orders']);
        },
      });
    } else {
      this.addRows(20);
    }
  }

  hasUnsavedChanges(): boolean {
    if (this.savedOnce) return false;
    return !!(this.order.party_name?.trim()) || this.order.items.some(item =>
      item.item_name || item.design_number || item.sudharo || item.stitch ||
      item.rate_bhav || item.fabric_rate || item.ok_status
    );
  }

  // Keyboard navigation
  //  @HostListener('document:keydown', ['$event'])
  //   handleKeyboard(event: KeyboardEvent) {
  //     if (event.key === 'Escape') {
  //       event.preventDefault();
  //       if (!this.hasUnsavedChanges() || confirm('You have unsaved changes. Are you sure you want to leave?')) {
  //         this.savedOnce = true; // skip guard
  //         this.router.navigate(['/orders']);
  //       }
  //       return;
  //     }

  //     const target = event.target as HTMLElement;
  //     const cell = target.closest('td');
  //     if (!cell) return;
  //     const row = cell.closest('tr');
  //     if (!row) return;
  //     const tbody = row.closest('tbody');
  //     if (!tbody) return;

  //     const rowIdx = Array.from(tbody.children).indexOf(row);
  //     const colIdx = Array.from(row.children).indexOf(cell);

  //     let newRow = rowIdx;
  //     let newCol = colIdx;

  //     if (event.key === 'ArrowUp') {
  //       event.preventDefault();
  //       newRow = Math.max(0, rowIdx - 1);
  //     } else if (event.key === 'ArrowDown') {
  //       event.preventDefault();
  //       newRow = Math.min(tbody.children.length - 1, rowIdx + 1);
  //     } else if (event.key === 'ArrowLeft' && !this.isTextInput(target)) {
  //       event.preventDefault();
  //       newCol = Math.max(1, colIdx - 1);
  //     } else if (event.key === 'ArrowRight' && !this.isTextInput(target)) {
  //       event.preventDefault();
  //       newCol = Math.min(row.children.length - 2, colIdx + 1);
  //     } else if (event.key === 'Enter' || event.key === 'Tab') {
  //       event.preventDefault();
  //       newCol = colIdx + 1;
  //       // Skip row number (col 0) and remove button (last col)
  //       if (newCol >= row.children.length - 1) {
  //         newCol = 1;
  //         newRow = Math.min(tbody.children.length - 1, rowIdx + 1);
  //       }
  //     } else {
  //       return;
  //     }

  //     const newRowEl = tbody.children[newRow] as HTMLElement;
  //     if (!newRowEl) return;
  //     const newCellEl = newRowEl.children[newCol] as HTMLElement;
  //     if (!newCellEl) return;

  //     const focusable = newCellEl.querySelector('input, select, button') as HTMLElement;
  //     if (focusable) focusable.focus();
  //   }

  @HostListener('document:keydown', ['$event'])
  handleKeyboard(event: KeyboardEvent) {
    if (event.key === 'Escape') {
      event.preventDefault();
      if (!this.hasUnsavedChanges() || confirm('You have unsaved changes. Are you sure you want to leave?')) {
        this.savedOnce = true; // skip guard
        this.router.navigate(['/orders']);
      }
      return;
    }

    const target = event.target as HTMLElement;
    const cell = target.closest('td');
    if (!cell) return;
    const row = cell.closest('tr');
    if (!row) return;
    const tbody = row.closest('tbody');
    if (!tbody) return;

    const rowIdx = Array.from(tbody.children).indexOf(row);
    const colIdx = Array.from(row.children).indexOf(cell);

    let newRow = rowIdx;
    let newCol = colIdx;

    // Shift+Tab -> previous cell (wrap to previous row last editable)
    if (event.key === 'Tab' && event.shiftKey) {
      event.preventDefault();
      newCol = colIdx - 1;
      if (newCol < 1) { // wrap to previous row
        newRow = Math.max(0, rowIdx - 1);
        const prevRowEl = tbody.children[newRow] as HTMLElement;
        newCol = Math.max(1, prevRowEl.children.length - 2); // last editable cell (before remove button)
      }
    } else if (event.key === 'ArrowUp') {
      event.preventDefault();
      newRow = Math.max(0, rowIdx - 1);
    } else if (event.key === 'ArrowDown') {
      event.preventDefault();
      newRow = Math.min(tbody.children.length - 1, rowIdx + 1);
    } else if (event.key === 'ArrowLeft' && !this.isTextInput(target)) {
      event.preventDefault();
      newCol = Math.max(1, colIdx - 1);
    } else if (event.key === 'ArrowRight' && !this.isTextInput(target)) {
      event.preventDefault();
      newCol = Math.min(row.children.length - 2, colIdx + 1);
    } else if ((event.key === 'Enter') || (event.key === 'Tab' && !event.shiftKey)) {
      event.preventDefault();
      newCol = colIdx + 1;
      // Skip row number (col 0) and remove button (last col)
      if (newCol >= row.children.length - 1) {
        newCol = 1;
        newRow = Math.min(tbody.children.length - 1, rowIdx + 1);
      }
    } else {
      return;
    }

    const newRowEl = tbody.children[newRow] as HTMLElement;
    if (!newRowEl) return;
    const newCellEl = newRowEl.children[newCol] as HTMLElement;
    if (!newCellEl) return;

    const focusable = newCellEl.querySelector('input, select, button') as HTMLElement;
    if (focusable) focusable.focus();
  }

  private isTextInput(el: HTMLElement): boolean {
    if (el.tagName === 'INPUT') {
      const type = (el as HTMLInputElement).type;
      return type === 'text' || type === 'number';
    }
    return false;
  }

  // Filter
  onFilterColumnChange() {
    const boolCols = ['ok_status', 'sleeve', 'collar', 'back_fabric', 'front', 'kohinoor', 'lachka', 'net', 'velvet', 'isForMen', 'isForKids'];
    this.isBooleanFilter = boolCols.includes(this.filterColumn);
    this.filterValue = '';
    this.filterBoolValue = false;
  }

  get filteredItems(): OrderItem[] {
    if (!this.filterColumn) return this.order.items;
    const boolCols = ['ok_status', 'sleeve', 'collar', 'back_fabric', 'front', 'kohinoor', 'lachka', 'net', 'velvet', 'isForMen', 'isForKids'];

    if (boolCols.includes(this.filterColumn)) {
      return this.order.items.filter(item => (item as any)[this.filterColumn] === this.filterBoolValue);
    }

    if (!this.filterValue.trim()) return this.order.items;
    const val = this.filterValue.toLowerCase().trim();
    return this.order.items.filter(item => {
      const field = (item as any)[this.filterColumn];
      if (field == null) return false;
      return String(field).toLowerCase().includes(val);
    });
  }

  clearFilter() {
    this.filterColumn = '';
    this.filterValue = '';
    this.filterBoolValue = false;
    this.isBooleanFilter = false;
  }

  // Text tooltip for sudharo/remark
  showTextTooltip(event: MouseEvent, text: string) {
    if (!text || !text.trim()) return;
    this.textTooltipContent = text;
    this.textTooltipX = event.clientX + 10;
    this.textTooltipY = event.clientY - 30;
    this.textTooltipVisible = true;
  }

  moveTextTooltip(event: MouseEvent) {
    this.textTooltipX = event.clientX + 10;
    this.textTooltipY = event.clientY - 30;
  }

  hideTextTooltip() {
    this.textTooltipVisible = false;
  }

  createEmptyItem(rowNum: number): OrderItem {
    return {
      row_num: rowNum,
      item_name: '',
      design_number: '',
      sudharo: '',
      stitch: null,
      rate_bhav: null,
      sleeve: false,
      collar: false,
      back_fabric: false,
      front: false,
      kohinoor: false,
      lachka: false,
      net: false,
      velvet: false,
      fabric_rate: null,
      ok_status: false,
      images: [],
      less: false,
      color: '',
      isForMen: false,
      isForKids: false

    };
  }

  addRows(count: number) {
    const start = this.order.items.length;
    for (let i = 0; i < count; i++) {
      this.order.items.push(this.createEmptyItem(start + i + 1));
    }
  }

  removeRow(index: number) {
    if (!confirm('Are you sure you want to delete this row?')) return;
    this.order.items.splice(index, 1);
    this.order.items.forEach((item, i) => (item.row_num = i + 1));
  }

  get isFormValid(): boolean {
    return !!(this.order.party_name?.trim() && this.order.order_date);
  }

  // --- Image/PDF handling ---
  onImageSelect(event: Event, rowIdx: number, slot: number) {
    const input = event.target as HTMLInputElement;
    if (!input.files?.length) return;
    const file = input.files[0];

    // if (slot === 0) {
    //   // First slot accepts PDF or image
    //   if (!file.type.startsWith('image/') && file.type !== 'application/pdf') {
    //     alert('First slot accepts image or PDF only');
    //     return;
    //   }
    // } else {
    //   if (!file.type.startsWith('image/')) {
    //     alert('This slot accepts images only');
    //     return;
    //   }
    // }

    // if (file.size > 10 * 1024 * 1024) {
    //   alert('File must be less than 10MB');
    //   return;
    // }

    const key = `${rowIdx}-${slot}`;
    this.localImageFiles[key] = file;

    if (file.type === 'application/pdf') {
      this.localPdfNames[key] = file.name;
      this.localImagePreviews[key] = 'pdf';
    } else {
      delete this.localPdfNames[key];
      const reader = new FileReader();
      reader.onload = (e) => {
        this.localImagePreviews[key] = e.target!.result as string;
      };
      reader.readAsDataURL(file);
    }
    input.value = '';
  }

  isPdf(rowIdx: number, slot: number): boolean {
    const key = `${rowIdx}-${slot}`;
    if (this.localPdfNames[key]) return true;
    const item = this.order.items[rowIdx];
    const img = item?.images?.find((i) => i.slot === slot);
    if (img && img.file_path.toLowerCase().endsWith('.pdf')) return true;
    return false;
  }

  getPdfName(rowIdx: number, slot: number): string {
    const key = `${rowIdx}-${slot}`;
    if (this.localPdfNames[key]) return this.localPdfNames[key];
    const item = this.order.items[rowIdx];
    const img = item?.images?.find((i) => i.slot === slot);
    return img?.original_name || 'document.pdf';
  }

  // removeLocalImage(rowIdx: number, slot: number) {
  //   const key = `${rowIdx}-${slot}`;
  //   delete this.localImagePreviews[key];
  //   delete this.localImageFiles[key];
  //   delete this.localPdfNames[key];

  //   const item = this.order.items[rowIdx];
  //   if (item?.images?.length) {
  //     const img = item.images.find((i) => i.slot === slot);
  //     if (img && img.id) {
  //       this.orderService.deleteImage(img.id).subscribe({
  //         next: () => {
  //           item.images = item.images!.filter((i) => i.id !== img.id);
  //           this.toast.success('File removed');
  //         },
  //         error: () => this.toast.error('Failed to remove file'),
  //       });
  //     }
  //   }
  // }

  removeLocalImage(rowIdx: number, slot: number) {
    const key = `${rowIdx}-${slot}`;

    // Always clear any local-only preview/file immediately
    delete this.localImagePreviews[key];
    delete this.localPdfNames[key];

    if (this.localImageFiles[key]) {
      // local file not yet uploaded — just remove it
      delete this.localImageFiles[key];
      return;
    }

    // If image exists on server, mark for deletion but don't call API now
    const item = this.order.items[rowIdx];
    if (!item?.images?.length) return;

    const img = item.images.find((i: any) => i.slot === slot);
    if (!img) return;

    // Mark for deletion (only if it has an id)
    if (img.id) this.deletedImageIds.push(img.id);

    // Remove from UI so user sees it gone, actual DB/file deletion happens on save
    item.images = item.images.filter((i: any) => i.slot !== slot);
  }

  getImageSrc(rowIdx: number, slot: number): string | null {
    const key = `${rowIdx}-${slot}`;
    if (this.localImagePreviews[key]) {
      if (this.localImagePreviews[key] === 'pdf') return 'pdf';
      return this.localImagePreviews[key];
    }
    const item = this.order.items[rowIdx];
    const img = item?.images?.find((i) => i.slot === slot);
    if (img) return `${environment.apiUrl}/uploads/${img.file_path}`;
    return null;
  }

  hasImage(rowIdx: number, slot: number): boolean {
    return !!this.getImageSrc(rowIdx, slot);
  }

  openPopup(rowIdx: number, slot: number) {
    if (this.isPdf(rowIdx, slot)) {
      const key = `${rowIdx}-${slot}`;
      if (this.localImageFiles[key]) {
        const url = URL.createObjectURL(this.localImageFiles[key]);
        this.popupPdfSrc = url;
      } else {
        const item = this.order.items[rowIdx];
        const img = item?.images?.find((i) => i.slot === slot);
        if (img) this.popupPdfSrc = this.sanitizer.bypassSecurityTrustResourceUrl(`${environment.apiUrl}/uploads/${img.file_path}`);
      }
    } else {
      const src = this.getImageSrc(rowIdx, slot);
      if (src && src !== 'pdf') this.popupImageSrc = src;
    }
  }

  closePopup() {
    this.popupImageSrc = null;
    this.popupPdfSrc = null;
  }

  showTooltip(event: MouseEvent, rowIdx: number, slot: number) {
    if (this.isPdf(rowIdx, slot)) return;
    const src = this.getImageSrc(rowIdx, slot);
    if (!src || src === 'pdf') return;
    this.tooltipSrc = src;
    this.tooltipX = event.clientX + 16;
    this.tooltipY = event.clientY - 75;
    this.tooltipVisible = true;
  }

  moveTooltip(event: MouseEvent) {
    this.tooltipX = event.clientX + 16;
    this.tooltipY = event.clientY - 75;
    if (this.tooltipX + 145 > window.innerWidth) this.tooltipX = event.clientX - 150;
    if (this.tooltipY < 8) this.tooltipY = 8;
  }

  hideTooltip() {
    this.tooltipVisible = false;
  }

  // --- Import ---
  triggerImport() {
    this.fileImportInput?.nativeElement?.click();
  }

  onImportFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (!input.files?.length) return;
    const file = input.files[0];
    const ext = file.name.split('.').pop()?.toLowerCase();

    if (ext === 'csv') {
      this.parseCSV(file);
    } else if (ext === 'xlsx' || ext === 'xls') {
      this.parseExcel(file);
    } else {
      alert('Please select a CSV or Excel file');
    }
    input.value = '';
  }

  parseCSV(file: File) {
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target!.result as string;
      const lines = text.split('\n').map((l) => l.trim()).filter((l) => l);
      if (lines.length < 2) return;

      const headers = this.parseCSVLine(lines[0]);
      const rows: any[] = [];

      for (let i = 1; i < lines.length; i++) {
        const values = this.parseCSVLine(lines[i]);
        const row: any = {};
        headers.forEach((h, idx) => {
          row[h.trim()] = values[idx]?.trim() || '';
        });
        rows.push(row);
      }

      this.importPreviewData = rows;
      this.showImportPreview = true;
    };
    reader.readAsText(file);
  }

  parseCSVLine(line: string): string[] {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;
    for (const ch of line) {
      if (ch === '"') {
        inQuotes = !inQuotes;
      } else if (ch === ',' && !inQuotes) {
        result.push(current);
        current = '';
      } else {
        current += ch;
      }
    }
    result.push(current);
    return result;
  }

  async parseExcel(file: File) {
    const XLSX = await import('xlsx');
    const reader = new FileReader();
    reader.onload = (e) => {
      const data = new Uint8Array(e.target!.result as ArrayBuffer);
      const wb = XLSX.read(data, { type: 'array' });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const rows: any[] = XLSX.utils.sheet_to_json(ws, { defval: '' });
      this.importPreviewData = rows;
      this.showImportPreview = true;
    };
    reader.readAsArrayBuffer(file);
  }

  onImportConfirm(rows: any[]) {
    this.showImportPreview = false;
    const columnMap: { [key: string]: string } = {
      'item name': 'item_name', 'item_name': 'item_name', 'itemname': 'item_name',
      'd.no': 'design_number', 'd.no.': 'design_number', 'dno': 'design_number',
      'design_number': 'design_number', 'design number': 'design_number',
      'sudharo': 'sudharo', 'stitch': 'stitch',
      'rate/bhav': 'rate_bhav', 'rate / bhav': 'rate_bhav', 'rate_bhav': 'rate_bhav',
      'rate': 'rate_bhav', 'bhav': 'rate_bhav',
      'sleeve': 'sleeve', 'slive': 'sleeve', 'collar': 'collar', 'kolar': 'collar',
      'back': 'back_fabric', 'bacek': 'back_fabric', 'back_fabric': 'back_fabric',
      'front': 'front', 'kohinoor': 'kohinoor', 'kohinur': 'kohinoor',
      'lachka': 'lachka', 'lachko': 'lachka', 'net': 'net', 'velvet': 'velvet',
      'fabric rate': 'fabric_rate', 'fabric_rate': 'fabric_rate', 'febric rate': 'fabric_rate',
      'ok': 'ok_status',
      'M': 'Men', 'K': 'Kids'
    };

    const numericFields = new Set(['rate_bhav', 'stitch', 'fabric_rate']);
    const booleanFields = new Set(['sleeve', 'collar', 'back_fabric', 'front', 'kohinoor', 'lachka', 'net', 'velvet', 'ok_status', 'isForMen', 'isForKids']);

    const items: OrderItem[] = rows.map((row, idx) => {
      const item = this.createEmptyItem(idx + 1);
      for (const [rawKey, value] of Object.entries(row)) {
        const key = rawKey.toLowerCase().trim();
        const mapped = columnMap[key];
        if (!mapped) continue;
        if (key.startsWith('img')) continue;
        if (booleanFields.has(mapped)) {
          (item as any)[mapped] = String(value).toLowerCase() === 'yes' || value === '1' || value === true;
        } else if (numericFields.has(mapped)) {
          const num = parseFloat(String(value));
          (item as any)[mapped] = isNaN(num) ? null : num;
        } else {
          (item as any)[mapped] = String(value);
        }
      }
      return item;
    });

    this.order.items = items;
    this.addRows(5);
  }

  onImportCancel() {
    this.showImportPreview = false;
    this.importPreviewData = [];
  }

  // --- Save ---
  save() {
    this.submitted = true;
    if (!this.isFormValid) {
      this.toast.warning('Please fill required fields');
      return;
    }

    const filledItems = this.order.items.filter((item) => {
      return item.item_name || item.design_number || item.sudharo || item.stitch ||
        item.rate_bhav || item.sleeve || item.collar || item.back_fabric ||
        item.front || item.kohinoor || item.lachka || item.net || item.less ||
        item.color || item.velvet || item.fabric_rate || item.ok_status ||
        item.isForMen || item.isForKids;
    });

    const payload: Order = {
      party_name: this.order.party_name,
      order_date: this.order.order_date,
      items: filledItems.map((item, i) => ({ ...item, row_num: i + 1 })),
    };

    this.saving = true;

    const obs = this.isEdit
      ? this.orderService.update(this.orderId!, payload)
      : this.orderService.create(payload);

    obs.subscribe({
      next: (res) => {
        const orderId = this.isEdit ? this.orderId! : res.id;
        this.uploadAllImages(orderId, filledItems).then(() => {
          this.saving = false;
          this.savedOnce = true;
          this.toast.success(this.isEdit ? 'Order updated successfully!' : 'Order created successfully!');
          this.router.navigate(['/orders']);
        }).catch(() => {
          this.saving = false;
          this.savedOnce = true;
          this.toast.warning('Order saved but some files failed to upload');
          this.router.navigate(['/orders']);
        });
      },
      error: (err) => {
        this.saving = false;
        this.toast.error('Failed to save order: ' + (err.error?.error || err.message));
      },
    });
  }

  // async uploadAllImages(orderId: number, filledItems: OrderItem[]) {
  //   const savedOrder: any = await this.orderService.getById(orderId).toPromise();
  //   const savedItems = savedOrder?.items || [];

  //   const uploadPromises: Promise<any>[] = [];

  //   for (const key of Object.keys(this.localImageFiles)) {
  //     const [rowIdxStr, slotStr] = key.split('-');
  //     const rowIdx = parseInt(rowIdxStr, 10);
  //     const slot = parseInt(slotStr, 10);

  //     const filledPos = this.order.items.filter((item, idx) => {
  //       if (idx > rowIdx) return false;
  //       return item.item_name || item.design_number || item.sudharo || item.stitch ||
  //         item.rate_bhav || item.sleeve || item.collar || item.back_fabric ||
  //         item.front || item.kohinoor || item.lachka || item.net ||
  //         item.velvet || item.fabric_rate || item.ok_status;
  //     }).length - 1;

  //     if (filledPos >= 0 && filledPos < savedItems.length) {
  //       const itemId = savedItems[filledPos].id;
  //       const file = this.localImageFiles[key];
  //       uploadPromises.push(
  //         this.orderService.uploadImages(orderId, itemId, [file], slot).toPromise()
  //       );
  //     }
  //   }

  //   if (uploadPromises.length) {
  //     await Promise.all(uploadPromises);
  //   }
  // }

  async uploadAllImages(orderId: number, filledItems: OrderItem[]) {
    const savedOrder: any = await this.orderService.getById(orderId).toPromise();
    const savedItems = savedOrder?.items || [];

    const uploadPromises: Promise<any>[] = [];

    for (const key of Object.keys(this.localImageFiles)) {
      const [rowIdxStr, slotStr] = key.split('-');
      const rowIdx = parseInt(rowIdxStr, 10);
      const slot = parseInt(slotStr, 10);

      const filledPos = this.order.items.filter((item, idx) => {
        if (idx > rowIdx) return false;
        return item.item_name || item.design_number || item.sudharo || item.stitch ||
          item.rate_bhav || item.sleeve || item.collar || item.back_fabric ||
          item.front || item.kohinoor || item.lachka || item.net ||
          item.velvet || item.fabric_rate || item.ok_status;
      }).length - 1;

      if (filledPos >= 0 && filledPos < savedItems.length) {
        const itemId = savedItems[filledPos].id;
        const file = this.localImageFiles[key];
        uploadPromises.push(
          this.orderService.uploadImages(orderId, itemId, [file], slot).toPromise()
        );
      }
    }

    if (uploadPromises.length) {
      await Promise.all(uploadPromises);
    }

    // AFTER uploads complete, perform deletions that user queued earlier
    if (this.deletedImageIds.length) {
      const deletePromises = this.deletedImageIds.map(id =>
        this.orderService.deleteImage(id).toPromise().catch(err => {
          // swallow but log / notify per-file failure
          console.error('Failed to delete image id', id, err);
          this.toast.error('Some files could not be removed');
        })
      );
      await Promise.all(deletePromises);
      this.deletedImageIds = [];
    }
  }

  // resetForm() {
  //   if (!confirm('Reset all data?')) return;
  //   this.order = {
  //     party_name: '',
  //     order_date: new Date().toISOString().split('T')[0],
  //     items: [],
  //   };
  //   this.localImagePreviews = {};
  //   this.localImageFiles = {};
  //   this.localPdfNames = {};
  //   this.submitted = false;
  //   this.addRows(20);
  // }

  resetForm() {
    if (!confirm('Reset all data?')) return;
    this.order = {
      party_name: '',
      order_date: new Date().toISOString().split('T')[0],
      items: [],
    };
    this.localImagePreviews = {};
    this.localImageFiles = {};
    this.localPdfNames = {};
    this.deletedImageIds = [];
    this.submitted = false;
    this.addRows(20);
  }


  get summary() {
    // Use the currently displayed items (filteredItems)
    const items = this.filteredItems || [];
    const isFilled = (item: OrderItem) => {
      return !!(
        item.item_name ||
        item.design_number ||
        item.sudharo ||
        item.stitch ||
        item.rate_bhav ||
        item.fabric_rate ||
        item.color ||
        item.ok_status
      );
    };

    const total = items.filter(isFilled).length;
    let completed = 0;

    items.forEach(item => {
      if (!isFilled(item)) return;

      // find original index in full order.items so localImageFiles keys match
      const origIdx = this.order.items.indexOf(item);

      const hasServerImage = Array.isArray(item.images) && item.images.length > 0;
      const hasLocalImage = Object.keys(this.localImageFiles).some(k => k.startsWith(`${origIdx}-`));

      if (item.ok_status && (hasServerImage || hasLocalImage)) completed++;
    });

    return { total, completed };
  }

  moveToGayatri() {
    const selected = this.order.items.filter(item => item.selected && item.id);
    if (!selected.length) {
      this.toast.warning('Please select at least one row using the checkbox');
      return;
    }
    if (!confirm(`Move ${selected.length} selected item(s) to Gayatri Collection?`)) return;

    const ids = selected.map(item => item.id!);
    this.orderService.markGayatriCollection(ids, true).subscribe({
      next: () => {
        this.toast.success(`${ids.length} item(s) moved to Gayatri Collection`);
        // Uncheck all
        this.order.items.forEach(item => item.selected = false);
      },
      error: () => this.toast.error('Failed to move items')
    });
  }

}