import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink, Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ToastService } from '../../services/toast.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="auth-container">
      <div class="auth-card">
        <div class="auth-header">
          <span class="auth-logo">📦</span>
          <h1>Inventory</h1>
          <p>Order Management System</p>
        </div>

        <form (ngSubmit)="onSubmit()" class="auth-form">
          <h2>{{ isRegister ? 'Create Account' : 'Sign In' }}</h2>

          <div class="form-group" *ngIf="isRegister">
            <label>Full Name</label>
            <input type="text" [(ngModel)]="name" name="name" placeholder="Enter your name"
                   [class.invalid]="submitted && isRegister && !name.trim()">
            <span class="error" *ngIf="submitted && isRegister && !name.trim()">Name is required</span>
          </div>

          <div class="form-group">
            <label>Email</label>
            <input type="email" [(ngModel)]="email" name="email" placeholder="Enter your email"
                   [class.invalid]="submitted && !email.trim()">
            <span class="error" *ngIf="submitted && !email.trim()">Email is required</span>
          </div>

          <div class="form-group">
            <label>Password</label>
            <input [type]="showPassword ? 'text' : 'password'" [(ngModel)]="password" name="password"
                   placeholder="Enter your password"
                   [class.invalid]="submitted && !password">
            <button type="button" class="toggle-pw" (click)="showPassword = !showPassword">
              {{ showPassword ? '🙈' : '👁️' }}
            </button>
            <span class="error" *ngIf="submitted && !password">Password is required</span>
            <span class="error" *ngIf="submitted && isRegister && password && password.length < 6">Min 6 characters</span>
          </div>

          <div class="form-group" *ngIf="isRegister">
            <label>Confirm Password</label>
            <input [type]="showPassword ? 'text' : 'password'" [(ngModel)]="confirmPassword" name="confirmPassword"
                   placeholder="Confirm your password"
                   [class.invalid]="submitted && isRegister && password !== confirmPassword">
            <span class="error" *ngIf="submitted && isRegister && password !== confirmPassword">Passwords don't match</span>
          </div>

          <button type="submit" class="btn btn-primary btn-full" [disabled]="loading">
            <span class="spinner-sm" *ngIf="loading"></span>
            {{ loading ? 'Please wait...' : (isRegister ? 'Create Account' : 'Sign In') }}
          </button>
        </form>

        <div class="auth-footer">
          <p *ngIf="!isRegister">
            Don't have an account? <a (click)="toggleMode()" class="auth-link">Register</a>
          </p>
          <p *ngIf="isRegister">
            Already have an account? <a (click)="toggleMode()" class="auth-link">Sign In</a>
          </p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .auth-container {
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 80vh;
    }
    .auth-card {
      background: var(--surface, #fff);
      border: 2px solid var(--border-dark, #ccc);
      border-radius: 12px;
      padding: 40px 36px;
      max-width: 420px;
      width: 100%;
      box-shadow: 0 8px 32px rgba(0,0,0,0.08);
    }
    .auth-header {
      text-align: center;
      margin-bottom: 28px;
    }
    .auth-logo {
      font-size: 48px;
      display: block;
      margin-bottom: 8px;
    }
    .auth-header h1 {
      font-family: 'IBM Plex Mono', monospace;
      font-size: 28px;
      font-weight: 700;
      color: var(--accent, #2563eb);
      letter-spacing: 4px;
      margin: 0;
    }
    .auth-header p {
      color: var(--text-muted, #6b7280);
      font-size: 14px;
      margin: 4px 0 0;
    }
    .auth-form h2 {
      font-size: 20px;
      font-weight: 600;
      margin: 0 0 20px;
      color: var(--text, #1f2937);
    }
    .form-group {
      margin-bottom: 16px;
      position: relative;
    }
    .form-group label {
      display: block;
      font-size: 13px;
      font-weight: 600;
      color: var(--text-muted, #6b7280);
      margin-bottom: 6px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .form-group input {
      width: 100%;
      padding: 10px 14px;
      border: 2px solid var(--border, #d1d5db);
      border-radius: 8px;
      font-size: 15px;
      transition: border-color 0.2s;
      box-sizing: border-box;
      background: var(--bg, #f9fafb);
    }
    .form-group input:focus {
      outline: none;
      border-color: var(--accent, #2563eb);
    }
    .form-group input.invalid {
      border-color: #ef4444;
    }
    .toggle-pw {
      position: absolute;
      right: 12px;
      top: 34px;
      background: none;
      border: none;
      cursor: pointer;
      font-size: 18px;
      padding: 0;
    }
    .error {
      color: #ef4444;
      font-size: 12px;
      margin-top: 4px;
      display: block;
    }
    .btn-full {
      width: 100%;
      padding: 12px;
      font-size: 16px;
      font-weight: 600;
      border-radius: 8px;
      margin-top: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
    }
    .spinner-sm {
      width: 18px; height: 18px;
      border: 2px solid rgba(255,255,255,0.3);
      border-top: 2px solid #fff;
      border-radius: 50%;
      animation: spin 0.6s linear infinite;
      display: inline-block;
    }
    @keyframes spin { to { transform: rotate(360deg); } }
    .auth-footer {
      text-align: center;
      margin-top: 20px;
      font-size: 14px;
      color: var(--text-muted, #6b7280);
    }
    .auth-link {
      color: var(--accent, #2563eb);
      cursor: pointer;
      font-weight: 600;
      text-decoration: underline;
    }
    @media (max-width: 480px) {
      .auth-card { padding: 28px 20px; margin: 0 12px; }
    }
  `],
})
export class LoginComponent {
  isRegister = false;
  name = '';
  email = '';
  password = '';
  confirmPassword = '';
  showPassword = false;
  submitted = false;
  loading = false;

  constructor(
    private authService: AuthService,
    private toast: ToastService,
    private router: Router
  ) {}

  toggleMode() {
    this.isRegister = !this.isRegister;
    this.submitted = false;
    this.name = '';
    this.email = '';
    this.password = '';
    this.confirmPassword = '';
  }

  onSubmit() {
    this.submitted = true;

    if (!this.email.trim() || !this.password) return;
    if (this.isRegister) {
      if (!this.name.trim()) return;
      if (this.password.length < 6) return;
      if (this.password !== this.confirmPassword) return;
    }

    this.loading = true;

    if (this.isRegister) {
      this.authService.register(this.name, this.email, this.password).subscribe({
        next: (res) => {
          this.loading = false;
          if (res.pending) {
            this.toast.info('Registration successful! Your account is pending admin approval.');
            this.toggleMode(); // Switch back to login form
          } else {
            this.toast.success('Admin account created successfully!');
            this.router.navigate(['/orders']);
          }
        },
        error: (err) => {
          this.loading = false;
          this.toast.error(err.error?.error || 'Registration failed');
        },
      });
    } else {
      this.authService.login(this.email, this.password).subscribe({
        next: () => {
          this.loading = false;
          this.toast.success('Welcome back!');
          this.router.navigate(['/orders']);
        },
        error: (err) => {
          this.loading = false;
          this.toast.error(err.error?.error || 'Login failed');
        },
      });
    }
  }
}
