import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

declare var pdfMake: any;

@Component({
  selector: 'app-reports',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="report-header">
      <div class="report-title">📄 Reports</div>
    </div>

    <div class="report-tabs">
      <button [class.active]="activeTab === 'design'" (click)="activeTab = 'design'">Design-wise Orders</button>
      <button [class.active]="activeTab === 'party'" (click)="activeTab = 'party'">Party-wise Orders</button>
    </div>

    <!-- Design-wise -->
    <div *ngIf="activeTab === 'design'" class="report-section">
      <div class="report-actions">
        <button class="btn btn-primary btn-sm" (click)="downloadDesignPdf()">📥 Download PDF</button>
      </div>
      <table class="report-table">
        <thead>
          <tr><th>#</th><th>D.No</th><th>Item</th><th>Color</th><th>Orders</th><th>Parties</th></tr>
        </thead>
        <tbody>
          <tr *ngFor="let r of designReport; let i = index">
            <td>{{ i+1 }}</td>
            <td><strong>{{ r.design_number }}</strong></td>
            <td>{{ r.item_name }}</td>
            <td>{{ r.color || '—' }}</td>
            <td>{{ r.order_count }}</td>
            <td>{{ r.party_names }}</td>
          </tr>
          <tr *ngIf="!designReport.length"><td colspan="6" class="empty">No data</td></tr>
        </tbody>
      </table>
    </div>

    <!-- Party-wise -->
    <div *ngIf="activeTab === 'party'" class="report-section">
      <div class="report-actions">
        <button class="btn btn-primary btn-sm" (click)="downloadPartyPdf()">📥 Download PDF</button>
      </div>
      <table class="report-table">
        <thead>
          <tr><th>#</th><th>Party</th><th>City</th><th>Broker</th><th>Orders</th><th>Designs</th><th>Completed</th></tr>
        </thead>
        <tbody>
          <tr *ngFor="let r of partyReport; let i = index">
            <td>{{ i+1 }}</td>
            <td><strong>{{ r.party_name }}</strong></td>
            <td>{{ r.city || '—' }}</td>
            <td>{{ r.broker || '—' }}</td>
            <td>{{ r.order_count }}</td>
            <td>{{ r.total_designs }}</td>
            <td>{{ r.completed }}</td>
          </tr>
          <tr *ngIf="!partyReport.length"><td colspan="7" class="empty">No data</td></tr>
        </tbody>
      </table>
    </div>
  `,
  styles: [`
    .report-header { background: var(--surface); border: 2px solid var(--border-dark); border-radius: 4px; padding: 16px 20px; margin-bottom: 12px; }
    .report-title { font-family: 'IBM Plex Mono', monospace; font-size: 18px; font-weight: 600; color: var(--accent); letter-spacing: 2px; text-transform: uppercase; }
    .report-tabs { display: flex; gap: 8px; margin-bottom: 14px; }
    .report-tabs button { padding: 8px 16px; border: 2px solid var(--border); border-radius: 4px; background: var(--surface); cursor: pointer; font-size: 13px; font-weight: 600; }
    .report-tabs button.active { background: var(--accent); color: white; border-color: var(--accent); }
    .report-section { background: var(--surface); border: 2px solid var(--border-dark); border-radius: 4px; overflow-x: auto; }
    .report-actions { padding: 12px 16px; border-bottom: 1px solid var(--border); }
    .report-table { width: 100%; border-collapse: collapse; font-size: 13px; }
    .report-table thead th { background: var(--header-bg); color: var(--header-text); padding: 10px 12px; font-size: 11px; text-transform: uppercase; }
    .report-table tbody td { padding: 8px 12px; border-bottom: 1px solid var(--border); }
    .report-table tbody tr:nth-child(even) { background: var(--row-alt); }
    .empty { text-align: center; padding: 20px; color: var(--text-muted); }
  `]
})
export class ReportsComponent implements OnInit {
  activeTab = 'design';
  designReport: any[] = [];
  partyReport: any[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.http.get<any[]>(`${environment.apiUrl}/api/reports/design-wise`).subscribe(d => this.designReport = d);
    this.http.get<any[]>(`${environment.apiUrl}/api/reports/party-wise`).subscribe(d => this.partyReport = d);
  }

  downloadDesignPdf() {
    const body = this.designReport.map((r, i) => [i+1, r.design_number, r.item_name, r.color || '—', r.order_count, r.party_names || '']);
    const dd = {
      content: [
        { text: 'Design-wise Orders Report', style: 'header' },
        { text: `Generated: ${new Date().toLocaleDateString()}`, margin: [0, 0, 0, 10] },
        {
          table: {
            headerRows: 1,
            widths: [25, 60, 80, 60, 40, '*'],
            body: [['#', 'D.No', 'Item', 'Color', 'Orders', 'Parties'], ...body]
          }
        }
      ],
      styles: { header: { fontSize: 16, bold: true, margin: [0, 0, 0, 10] } }
    };
    pdfMake.createPdf(dd).download('design-wise-report.pdf');
  }

  downloadPartyPdf() {
    const body = this.partyReport.map((r, i) => [i+1, r.party_name, r.city || '—', r.broker || '—', r.order_count, r.total_designs, r.completed]);
    const dd = {
      content: [
        { text: 'Party-wise Orders Report', style: 'header' },
        { text: `Generated: ${new Date().toLocaleDateString()}`, margin: [0, 0, 0, 10] },
        {
          table: {
            headerRows: 1,
            widths: [25, '*', 60, 60, 45, 50, 55],
            body: [['#', 'Party', 'City', 'Broker', 'Orders', 'Designs', 'Done'], ...body]
          }
        }
      ],
      styles: { header: { fontSize: 16, bold: true, margin: [0, 0, 0, 10] } }
    };
    pdfMake.createPdf(dd).download('party-wise-report.pdf');
  }
}
