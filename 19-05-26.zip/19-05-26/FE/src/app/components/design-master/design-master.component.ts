import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { DesignService } from '../../services/design.service';
import { ItemService } from '../../services/item.service';
import { ToastService } from '../../services/toast.service';
import { Design, Item, DesignFile } from '../../models/order.model';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-design-master',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="master-header">
      <div class="master-title">🎨 Design Master</div>
    </div>

    <div class="master-toolbar">
      <input type="text" [(ngModel)]="searchText" (input)="loadDesigns()"
             placeholder="Search designs..." class="master-search-input">
      <select [(ngModel)]="filterItemId" (change)="loadDesigns()" class="filter-select">
        <option [ngValue]="null">All Items</option>
        <option *ngFor="let item of allItems" [ngValue]="item.id">{{ item.item_name }}</option>
      </select>
      <select [(ngModel)]="orderFilter" (change)="loadDesigns()" class="filter-select">
        <option value="">All</option>
        <option value="in_order">In Order</option>
        <option value="not_in_order">Not In Order</option>
      </select>
      <button class="btn btn-primary btn-sm" (click)="openNewForm()">+ Add Design</button>
    </div>

    <!-- Pagination -->
    <div class="master-pagination">
      <select [(ngModel)]="limit" (change)="loadDesigns()" class="page-select">
        <option [value]="10">10</option><option [value]="20">20</option><option [value]="50">50</option>
        <option [value]="100">100</option><option [value]="1000">1000</option>
      </select>
      <span class="page-info">Page {{ page }} of {{ totalPages }} ({{ total }} records)</span>
      <button class="btn btn-sm btn-secondary" [disabled]="page <= 1" (click)="page = page - 1; loadDesigns()">‹</button>
      <button class="btn btn-sm btn-secondary" [disabled]="page >= totalPages" (click)="page = page + 1; loadDesigns()">›</button>
      <div class="legend">
        <span class="legend-item"><span class="status-dot not-in-order"></span> Not in any order</span>
        <span class="legend-item"><span class="status-dot in-order"></span> In order</span>
      </div>
    </div>

    <!-- Table -->
    <div class="master-table-wrap">
      <table class="master-table">
        <thead>
          <tr>
            <th style="width:40px">#</th>
            <th style="width:30px"></th>
            <th (click)="toggleSort('item_name')">Item</th>
            <th (click)="toggleSort('design_number')">D.No</th>
            <th>Sudharo</th>
            <th>Stitch</th>
            <th>Rate</th>
            <th>F.Rate</th>
            <th>Fabric</th>
            <th>Color</th>
            <th>Files</th>
            <th>In Orders</th>
            <th style="width:120px">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let d of designs; let i = index">
            <td>{{ (page-1)*limit + i + 1 }}</td>
            <td class="td-status"><span class="status-dot" [class.in-order]="d.in_order" [class.not-in-order]="!d.in_order"></span></td>
            <td>{{ d.item_name }}</td>
            <td><strong>{{ d.design_number }}</strong></td>
            <td>{{ d.sudharo || '—' }}</td>
            <td>{{ d.stitch || '—' }}</td>
            <td>{{ d.rate_bhav || '—' }}</td>
            <td>{{ d.fabric_rate || '—' }}</td>
            <td>{{ d.kapda || '—' }}</td>
            <td>{{ d.color || '—' }}</td>
            <td>{{ d.files?.length || 0 }}</td>
            <td class="td-order-count">
              <span class="order-count-badge" *ngIf="d.order_count > 0" (click)="showDesignOrders(d)">{{ d.order_count }}</span>
              <span *ngIf="!d.order_count">0</span>
            </td>
            <td>
              <button class="btn btn-secondary btn-sm" (click)="onEdit(d)">Edit</button>
              <button class="btn btn-danger btn-sm" (click)="onDelete(d)">Del</button>
            </td>
          </tr>
          <tr *ngIf="!designs.length"><td colspan="13" class="empty-row">No designs found</td></tr>
        </tbody>
      </table>
    </div>

    <!-- Form Modal -->
    <div class="modal-overlay" *ngIf="showForm" (click)="showForm = false">
      <div class="modal-box modal-wide" (click)="$event.stopPropagation()">
        <div class="modal-head">
          <h3>{{ editDesign.id ? 'Edit' : 'New' }} Design</h3>
          <span class="modal-close" (click)="showForm = false">×</span>
        </div>
        <div class="modal-body">
          <div class="form-grid">
            <div class="form-group">
              <label>Item *</label>
              <select [(ngModel)]="editDesign.item_id" class="form-input">
                <option [ngValue]="null">Select Item</option>
                <option *ngFor="let item of allItems" [ngValue]="item.id">{{ item.item_name }}</option>
              </select>
            </div>
            <div class="form-group">
              <label>Design Number *</label>
              <input type="text" [(ngModel)]="editDesign.design_number" class="form-input">
            </div>
            <div class="form-group">
              <label>Sudharo</label>
              <input type="text" [(ngModel)]="editDesign.sudharo" class="form-input">
            </div>
            <div class="form-group">
              <label>Stitch</label>
              <input type="number" [(ngModel)]="editDesign.stitch" class="form-input">
            </div>
            <div class="form-group">
              <label>Rate / Bhav</label>
              <input type="number" [(ngModel)]="editDesign.rate_bhav" class="form-input">
            </div>
            <div class="form-group">
              <label>Fabric Rate</label>
              <input type="number" [(ngModel)]="editDesign.fabric_rate" class="form-input">
            </div>
            <div class="form-group">
              <label>Kapda</label>
              <input type="text" [(ngModel)]="editDesign.kapda" class="form-input">
            </div>
            <div class="form-group">
              <label>Piece</label>
              <input type="number" [(ngModel)]="editDesign.piece" class="form-input">
            </div>
            <div class="form-group">
              <label>Color</label>
              <input type="text" [(ngModel)]="editDesign.color" class="form-input">
            </div>
            <div class="form-group">
              <label>Remark</label>
              <input type="text" [(ngModel)]="editDesign.remark" class="form-input">
            </div>
          </div>

          <div class="checkbox-row">
            <label><input type="checkbox" [(ngModel)]="editDesign.sleeve"> Sleeve</label>
            <label><input type="checkbox" [(ngModel)]="editDesign.collar"> Collar</label>
            <label><input type="checkbox" [(ngModel)]="editDesign.back_fabric"> Back</label>
            <label><input type="checkbox" [(ngModel)]="editDesign.front"> Front</label>
            <label><input type="checkbox" [(ngModel)]="editDesign.kohinoor"> Kohinoor</label>
            <label><input type="checkbox" [(ngModel)]="editDesign.lachka"> Lachka</label>
            <label><input type="checkbox" [(ngModel)]="editDesign.net"> Net</label>
            <label><input type="checkbox" [(ngModel)]="editDesign.velvet"> Velvet</label>
            <label><input type="checkbox" [(ngModel)]="editDesign.less"> Less</label>
          </div>

          <!-- File uploads -->
          <div class="file-section">
            <label class="section-label">Files (max 4)</label>
            <div class="file-slots">
              <div class="file-slot" *ngFor="let slot of [0,1,2,3]">
                <div *ngIf="getFileForSlot(slot) as f" class="file-thumb">
                  <img *ngIf="isImage(f.file_path)" [src]="getFileUrl(f.file_path)" alt=""
                       (click)="previewFile(f)">
                  <span *ngIf="!isImage(f.file_path)" class="pdf-icon" (click)="previewFile(f)"
                        [title]="f.original_name">📄</span>
                  <button class="file-remove" (click)="removeFile(f)">✕</button>
                </div>
                <label *ngIf="!getFileForSlot(slot)" class="file-upload-btn">
                  + Slot {{ slot + 1 }}
                  <input type="file" accept="image/*,.pdf" (change)="onFileSelect($event, slot)" hidden>
                </label>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-foot">
          <button class="btn btn-secondary btn-sm" (click)="showForm = false">Cancel</button>
          <button class="btn btn-primary btn-sm" (click)="saveDesign()"
                  [disabled]="!editDesign.item_id || !editDesign.design_number?.trim()">
            {{ editDesign.id ? 'Update' : 'Save' }}
          </button>
        </div>
      </div>
    </div>

    <!-- Image preview popup -->
    <div class="img-popup-overlay" *ngIf="previewImageSrc" (click)="previewImageSrc = null">
      <img [src]="previewImageSrc" (click)="$event.stopPropagation()">
    </div>

    <!-- PDF preview popup -->
    <div class="pdf-popup-overlay" *ngIf="previewPdfSrc" (click)="previewPdfSrc = null">
      <div class="pdf-popup" (click)="$event.stopPropagation()">
        <button class="pdf-popup-close" (click)="previewPdfSrc = null">✕</button>
        <iframe [src]="previewPdfSrc" width="100%" height="100%"></iframe>
      </div>
    </div>

    <!-- Orders popup for design -->
    <div class="modal-overlay" *ngIf="showOrdersPopup" (click)="showOrdersPopup = false">
      <div class="modal-box" (click)="$event.stopPropagation()">
        <div class="modal-head">
          <h3>Orders for {{ selectedDesignNumber }}</h3>
          <span class="modal-close" (click)="showOrdersPopup = false">×</span>
        </div>
        <div class="modal-body">
          <table class="popup-table" *ngIf="designOrders.length">
            <thead><tr><th>Party</th><th>Date</th><th>City</th><th>Status</th></tr></thead>
            <tbody>
              <tr *ngFor="let o of designOrders">
                <td>{{ o.party_name }}</td>
                <td>{{ o.order_date | date:'dd/MM/yyyy' }}</td>
                <td>{{ o.city || '—' }}</td>
                <td>{{ o.ok_status ? '✅' : '⏳' }}</td>
              </tr>
            </tbody>
          </table>
          <p *ngIf="!designOrders.length">No orders found</p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .master-header { background: var(--surface); border: 2px solid var(--border-dark); border-radius: 4px; padding: 16px 20px; margin-bottom: 12px; }
    .master-title { font-family: 'IBM Plex Mono', monospace; font-size: 18px; font-weight: 600; color: var(--accent); letter-spacing: 2px; text-transform: uppercase; }
    .master-toolbar { display: flex; gap: 12px; align-items: center; margin-bottom: 12px; flex-wrap: wrap; }
    .master-search-input { border: 1.5px solid var(--border); border-radius: 3px; padding: 7px 12px; font-size: 13px; width: 250px; background: var(--surface); }
    .master-search-input:focus { outline: none; border-color: var(--accent); }
    .filter-select { border: 1.5px solid var(--border); border-radius: 3px; padding: 7px 10px; font-size: 13px; background: var(--surface); }
    .master-pagination { display: flex; gap: 10px; align-items: center; margin-bottom: 10px; flex-wrap: wrap; }
    .page-select { border: 1.5px solid var(--border); border-radius: 3px; padding: 4px 8px; font-size: 12px; }
    .page-info { font-size: 12px; color: var(--text-muted); }
    .legend { display: flex; gap: 12px; align-items: center; margin-left: auto; }
    .legend-item { display: flex; align-items: center; gap: 4px; font-size: 11px; color: var(--text-muted); }
    .status-dot { width: 10px; height: 10px; border-radius: 50%; display: inline-block; }
    .status-dot.not-in-order { background: #2e7d32; }
    .status-dot.in-order { background: #c62828; }
    .td-status { text-align: center; width: 30px; }
    .master-table-wrap { background: var(--surface); border: 2px solid var(--border-dark); border-radius: 4px; overflow-x: auto; }
    .master-table { width: 100%; border-collapse: collapse; font-size: 12px; }
    .master-table thead th { background: var(--header-bg); color: var(--header-text); padding: 8px 10px; font-family: 'IBM Plex Mono', monospace; font-size: 10px; text-transform: uppercase; letter-spacing: 0.5px; cursor: pointer; white-space: nowrap; }
    .master-table tbody td { padding: 7px 10px; border-bottom: 1px solid var(--border); white-space: nowrap; }
    .master-table tbody tr:nth-child(even) { background: var(--row-alt); }
    .master-table tbody tr:hover { background: #eef5e6; }
    .empty-row { text-align: center; color: var(--text-muted); padding: 24px !important; }
    .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center; padding: 20px; }
    .modal-box { background: white; border-radius: 6px; width: 100%; max-width: 480px; box-shadow: 0 8px 40px rgba(0,0,0,0.3); max-height: 90vh; overflow-y: auto; }
    .modal-wide { max-width: 700px; }
    .modal-head { display: flex; justify-content: space-between; align-items: center; padding: 14px 20px; border-bottom: 2px solid var(--border); position: sticky; top: 0; background: white; z-index: 1; }
    .modal-head h3 { font-family: 'IBM Plex Mono', monospace; font-size: 15px; color: var(--accent); }
    .modal-close { font-size: 22px; cursor: pointer; color: #888; }
    .modal-body { padding: 16px 20px; }
    .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
    .form-group { margin-bottom: 0; }
    .form-group label { display: block; font-size: 10px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; color: var(--text-muted); margin-bottom: 3px; }
    .form-input { width: 100%; border: 1.5px solid var(--border); border-radius: 3px; padding: 7px 9px; font-size: 13px; }
    .form-input:focus { outline: none; border-color: var(--accent); }
    .checkbox-row { display: flex; flex-wrap: wrap; gap: 12px; margin: 14px 0; padding: 10px; background: var(--row-alt); border-radius: 4px; }
    .checkbox-row label { font-size: 12px; display: flex; align-items: center; gap: 4px; cursor: pointer; }
    .file-section { margin-top: 14px; }
    .section-label { font-size: 10px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; color: var(--text-muted); margin-bottom: 6px; display: block; }
    .file-slots { display: flex; gap: 10px; flex-wrap: wrap; }
    .file-slot { width: 80px; height: 80px; border: 2px dashed var(--border); border-radius: 4px; display: flex; align-items: center; justify-content: center; position: relative; }
    .file-thumb { width: 100%; height: 100%; position: relative; }
    .file-thumb img { width: 100%; height: 100%; object-fit: cover; border-radius: 3px; cursor: pointer; }
    .file-remove { position: absolute; top: -6px; right: -6px; width: 18px; height: 18px; border-radius: 50%; background: var(--danger); color: white; font-size: 10px; border: none; cursor: pointer; display: flex; align-items: center; justify-content: center; }
    .file-upload-btn { font-size: 11px; color: var(--text-muted); cursor: pointer; text-align: center; }
    .pdf-icon { font-size: 24px; cursor: pointer; }
    .img-popup-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.8); z-index: 3000; display: flex; align-items: center; justify-content: center; cursor: pointer; }
    .img-popup-overlay img { max-width: 90vw; max-height: 90vh; border-radius: 6px; }
    .pdf-popup-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.7); z-index: 3000; display: flex; align-items: center; justify-content: center; cursor: pointer; }
    .pdf-popup { width: 90vw; height: 85vh; background: white; border-radius: 6px; position: relative; overflow: hidden; }
    .pdf-popup iframe { border: none; }
    .pdf-popup-close { position: absolute; top: 8px; right: 12px; z-index: 10; background: var(--danger); color: white; border: none; border-radius: 50%; width: 28px; height: 28px; font-size: 16px; cursor: pointer; display: flex; align-items: center; justify-content: center; }
    .modal-foot { display: flex; gap: 8px; justify-content: flex-end; padding: 12px 20px; border-top: 2px solid var(--border); position: sticky; bottom: 0; background: white; }
    @media (max-width: 768px) {
      .master-toolbar { flex-direction: column; align-items: stretch; }
      .master-search-input { width: 100%; }
      .form-grid { grid-template-columns: 1fr; }
      .pdf-popup { width: 95vw; height: 80vh; }
    }
    .td-order-count { text-align: center; }
    .order-count-badge { background: var(--accent); color: white; border-radius: 10px; padding: 2px 8px; font-size: 11px; cursor: pointer; font-weight: 600; }
    .order-count-badge:hover { background: #1e3810; }
    .popup-table { width: 100%; border-collapse: collapse; font-size: 13px; }
    .popup-table thead th { background: var(--header-bg); color: var(--header-text); padding: 8px 10px; font-size: 11px; text-transform: uppercase; }
    .popup-table tbody td { padding: 7px 10px; border-bottom: 1px solid var(--border); }
  `]
})
export class DesignMasterComponent implements OnInit {
  designs: Design[] = [];
  allItems: Item[] = [];
  searchText = '';
  filterItemId: number | null = null;
  orderFilter = '';
  page = 1;
  limit = 1000;
  total = 0;
  totalPages = 1;
  sortBy = 'created_at';
  sortDir = 'DESC';
  showForm = false;
  editDesign: Partial<Design> & { files?: DesignFile[] } = this.emptyDesign();
  previewImageSrc: string | null = null;
  previewPdfSrc: SafeResourceUrl | null = null;
  showOrdersPopup = false;
  designOrders: any[] = [];
  selectedDesignNumber = '';

  constructor(private designService: DesignService, private itemService: ItemService, private toast: ToastService, private sanitizer: DomSanitizer, private http: HttpClient) {}

  ngOnInit() {
    this.loadItems();
    this.loadDesigns();
  }

  loadItems() {
    this.itemService.getAll({ limit: 1000 }).subscribe(res => this.allItems = res.data);
  }

  loadDesigns() {
    const params: any = { page: this.page, limit: this.limit, search: this.searchText, sortBy: this.sortBy, sortDir: this.sortDir };
    if (this.filterItemId) params.item_id = this.filterItemId;
    if (this.orderFilter) params.order_filter = this.orderFilter;
    this.designService.getAll(params).subscribe(res => {
      this.designs = res.data;
      this.total = res.pagination.total;
      this.totalPages = res.pagination.totalPages;
    });
  }

  toggleSort(col: string) {
    if (this.sortBy === col) this.sortDir = this.sortDir === 'ASC' ? 'DESC' : 'ASC';
    else { this.sortBy = col; this.sortDir = 'ASC'; }
    this.loadDesigns();
  }

  emptyDesign(): Partial<Design> {
    return {
      item_id: undefined as any, design_number: '', sudharo: '', stitch: null, rate_bhav: null,
      sleeve: false, collar: false, back_fabric: false, front: false, kohinoor: false,
      lachka: false, net: false, velvet: false, less: false, fabric_rate: null,
      kapda: '', piece: null, color: '', remark: '', files: []
    };
  }

  openNewForm() { this.editDesign = this.emptyDesign(); this.showForm = true; }

  onEdit(d: Design) { this.editDesign = { ...d, files: d.files ? [...d.files] : [] }; this.showForm = true; }

  saveDesign() {
    if (!this.editDesign.item_id || !this.editDesign.design_number?.trim()) return;
    const obs = this.editDesign.id
      ? this.designService.update(this.editDesign.id, this.editDesign)
      : this.designService.create(this.editDesign);
    obs.subscribe(res => {
      this.toast.show(this.editDesign.id ? 'Design updated' : 'Design created', 'success');
      this.showForm = false;
      this.loadDesigns();
    });
  }

  onDelete(d: Design) {
    if (!confirm(`Deactivate design "${d.design_number}"?`)) return;
    this.designService.delete(d.id!).subscribe(() => { this.toast.show('Design deactivated', 'success'); this.loadDesigns(); });
  }

  getFileForSlot(slot: number): DesignFile | undefined {
    return this.editDesign.files?.find(f => f.slot === slot);
  }

  getFileUrl(filePath: string): string {
    const clean = filePath.replace(/^\/uploads\//, '');
    return `${environment.apiUrl}/uploads/${clean}`;
  }

  isImage(filePath: string): boolean {
    return /\.(jpg|jpeg|png|gif|webp|bmp)$/i.test(filePath);
  }

  onFileSelect(event: Event, slot: number) {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (!file || !this.editDesign.id) return;
    this.designService.uploadFiles(this.editDesign.id, [file], slot).subscribe(res => {
      if (!this.editDesign.files) this.editDesign.files = [];
      this.editDesign.files = this.editDesign.files.filter(f => f.slot !== slot);
      this.editDesign.files.push(...res.files);
      this.toast.show('File uploaded', 'success');
    });
  }

  removeFile(f: DesignFile) {
    if (!f.id) return;
    this.designService.deleteFile(f.id).subscribe(() => {
      this.editDesign.files = this.editDesign.files?.filter(x => x.id !== f.id);
      this.toast.show('File removed', 'success');
    });
  }

  previewFile(f: DesignFile) {
    const url = this.getFileUrl(f.file_path);
    if (this.isImage(f.file_path)) {
      this.previewImageSrc = url;
    } else {
      this.previewPdfSrc = this.sanitizer.bypassSecurityTrustResourceUrl(url);
    }
  }

  showDesignOrders(d: Design) {
    this.selectedDesignNumber = d.design_number;
    this.http.get<any[]>(`${environment.apiUrl}/api/reports/design/${d.id}/orders`).subscribe(rows => {
      this.designOrders = rows;
      this.showOrdersPopup = true;
    });
  }
}
