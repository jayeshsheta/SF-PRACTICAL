import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToastService } from '../../services/toast.service';

@Component({
  selector: 'app-toast',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="toast-container">
      <div *ngFor="let toast of toastService.toasts"
           class="toast-item"
           [ngClass]="'toast-' + toast.type"
           (click)="toastService.remove(toast.id)">
        <span class="toast-icon">
          <ng-container [ngSwitch]="toast.type">
            <span *ngSwitchCase="'success'">✅</span>
            <span *ngSwitchCase="'error'">❌</span>
            <span *ngSwitchCase="'warning'">⚠️</span>
            <span *ngSwitchDefault>ℹ️</span>
          </ng-container>
        </span>
        <span class="toast-msg">{{ toast.message }}</span>
        <button class="toast-close" (click)="toastService.remove(toast.id); $event.stopPropagation()">✕</button>
      </div>
    </div>
  `,
  styles: [`
    .toast-container {
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 10000;
      display: flex;
      flex-direction: column;
      gap: 8px;
      max-width: 400px;
    }
    .toast-item {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 12px 16px;
      border-radius: 10px;
      color: #fff;
      font-size: 14px;
      font-weight: 500;
      box-shadow: 0 4px 20px rgba(0,0,0,0.18);
      cursor: pointer;
      animation: slideIn 0.3s ease;
      min-width: 260px;
    }
    .toast-success { background: linear-gradient(135deg, #22c55e, #16a34a); }
    .toast-error { background: linear-gradient(135deg, #ef4444, #dc2626); }
    .toast-warning { background: linear-gradient(135deg, #f59e0b, #d97706); }
    .toast-info { background: linear-gradient(135deg, #3b82f6, #2563eb); }
    .toast-icon { font-size: 18px; }
    .toast-msg { flex: 1; }
    .toast-close {
      background: none; border: none; color: rgba(255,255,255,0.7);
      font-size: 16px; cursor: pointer; padding: 0 2px;
    }
    .toast-close:hover { color: #fff; }
    @keyframes slideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
  `]
})
export class ToastComponent {
  constructor(public toastService: ToastService) {}
}
