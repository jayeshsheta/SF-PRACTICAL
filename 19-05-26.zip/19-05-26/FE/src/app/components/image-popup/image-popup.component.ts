import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-image-popup',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="lightbox" (click)="close.emit()">
      <span class="lightbox-close">×</span>
      <img [src]="src" alt="Design" (click)="$event.stopPropagation()">
    </div>
  `,
  styles: [`
    .lightbox {
      position: fixed;
      inset: 0;
      background: rgba(0,0,0,0.84);
      z-index: 1000;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      animation: fadeIn 0.2s ease;
    }
    .lightbox img {
      max-width: 90vw;
      max-height: 88vh;
      border-radius: 4px;
      box-shadow: 0 8px 40px rgba(0,0,0,0.6);
      border: 3px solid white;
      cursor: default;
    }
    .lightbox-close {
      position: fixed;
      top: 20px;
      right: 24px;
      color: white;
      font-size: 32px;
      cursor: pointer;
      font-weight: 300;
    }
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
  `],
})
export class ImagePopupComponent {
  @Input() src!: string;
  @Output() close = new EventEmitter<void>();
}
